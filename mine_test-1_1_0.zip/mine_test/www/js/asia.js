// Initialize your app
var myApp = new Framework7(
    {
        pushState: true,
    });
// Export selectors engine
var $$ = Dom7;
// Add views
var mainView = myApp.addView('.view-main', {
    // Because we want to use dynamic navbar, we need to enable it for this view:
    dynamicNavbar: true
});
var adminView = myApp.addView('.view-admin', {
    domCache: true
});
$$('.view-admin').hide();
$$('.view-otp').hide();
$$('.admin_footer').hide();
var project_info=[];
var image_name=[];
var image_order;
var server_status=false;
var ratify_image_name=[];
var ratify_image_order;
var upload_image_function_status=false;
//variable-for-file
var app_data={};
app_data.menu = {};
app_data.user_info = {};
app_data.user_location = {};
app_data.dealer_location = {};
app_data.depo_location = {};
app_data.painter_info = {};
app_data.consultant_info = {};
app_data.contact_person_info = {};
app_data.project_nature = {};
app_data.painting_type = {};
app_data.project_category = {};
app_data.project_segment = {};
app_data.project_sub_segment = {};
app_data.project_status = {};
app_data.possible_users_info = {};
app_data.level_mapping = {};
app_data.lead_source = {};
app_data.project_detail_info = {};
app_data.sales_order_list_info = {};
app_data.products = {};
app_data.product_category = {};
app_data.project_competitors = {};
app_data.rating_status = {};
app_data.progoti_details = {};
var jsEncode = {
    encode: function (s, k) {
        var enc = "";
        var str = "";
        // make sure that input is string
        str = s.toString();
        for (var i = 0; i < s.length; i++) {
            // create block
            var a = s.charCodeAt(i);
            // bitwise XOR
            var b = a ^ k;
            enc = enc + String.fromCharCode(b);
        }
        return enc;
    }
};
function saveJSON(){
    window.resolveLocalFileSystemURL("file:///storage/emulated/0/AsianPaint/data/life.json", gotFileEntry, wfail);
    function gotFileEntry(fileEntry) {fileEntry.createWriter(gotFileWriter, wfail);}
    function gotFileWriter(writer) {
        var encrptDT = jsEncode.encode(JSON.stringify(app_data),'123');
        writer.write(encrptDT);
    }
    function wfail(error) {alert('Error in writing file. Error:-'+error.code);}
};
function ready_the_blank_file(u,p,otp_status_submit)
{
    if(empty_file_data())
    {
        var path = "file:///storage/emulated/0/AsianPaint/";
        window.resolveLocalFileSystemURL(path, function folderExists(dirEntry){
            ready_json_file(u,p,otp_status_submit);
        }, function folderDoesNotExists(){
            var path = "file:///storage/emulated/0/";
            window.resolveLocalFileSystemURL(path, function (DirEntry) {
                DirEntry.getDirectory("AsianPaint", { create: true, exclusive: false }, function succ(dir)
                {
                    ready_json_file(u,p,otp_status_submit);
                }, function fl(){alert('Directory Failed');});
            });
        });
    }
}
function ready_json_file(u,p,otp_status_submit)
{
    var path = "file:///storage/emulated/0/AsianPaint/";
    window.resolveLocalFileSystemURL(path, function (dirEntry) {
        dirEntry.getDirectory("Data", { create: true, exclusive: false }, function succ(dirEntry)
        {
            var file_content = jsEncode.encode(JSON.stringify(app_data),'123');
            var file_path="file:///storage/emulated/0/AsianPaint/Data";
            window.resolveLocalFileSystemURL(file_path, function(dir) {
                dir.getFile('life.json', {create:true}, function(fileEntry) {
                    // The file has been succesfully created. Use fileEntry to read the content or delete the file
                    fileEntry.createWriter(function (fileWriter) {
                        fileWriter.onwriteend = function(){
                            //alert('File Write End');
                            login_request(u,p,otp_status_submit);
                        };
                        fileWriter.onerror = function (e) {
                            alert("Failed file write: " + e.toString());
                        };
                        fileWriter.write(file_content);
                    });
                });
            });

        }, function fl(){alert('Directory Failed');});
    });
}
function read_file() {
    window.resolveLocalFileSystemURL("file:///storage/emulated/0/AsianPaint/data/life.json", gotFile, file_fail);
    function gotFile(fileEntry) {
        fileEntry.file(function(file) {
            var reader = new FileReader();
            reader.onloadend = function(e) {
                try {
                    var dt = jsEncode.encode(this.result,'123');
                    app_data = JSON.parse(dt);
                }
                catch(e){
                    return alert('Corrupted file found!');
                };
            }
            reader.readAsText(file);
        });
    }
    function file_fail(e) {
        alert("File Missing!");
    }
}

document.addEventListener("resume", function resumeCallback() {
    //do something
}, false);
var base_url = "https://www.apecbuddy.com/asian_paints/";
// var base_url = "http://103.36.103.73/asian_paints/";
$$('.popup').on('open', function () {
    //$$('body').addClass('with-popup');
});
// $$('.popup').on('opened', function () {
//     $$(this).find('input[name="title"]').focus();
// });
$$('.popup').on('close', function () {
    // $$('body').removeClass('with-popup');
    //$$(this).find('input[name="title"]').blur().val('');
});
function addCommas(nStr)
{
    nStr += '';
    var x = nStr.split('.');
    var x1 = x[0];
    var x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    var X = x1 + x2;
    return X;
}
var today = new Date();
var cdate = today.toDateString();
var ctime = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
var date = today.toISOString().slice(0, 10);
function get_today_date() {
    var date = new Date();
    var all_months = [ "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December" ];
    var this_month = all_months[date.getMonth()];
    var this_date=date.getDate();
    var this_year=date.getFullYear();
    var today_date_in_log=this_month+' '+this_date+', '+this_year;
    return today_date_in_log;
}
function getdate(){
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    if(s<10){
        s = "0"+s;
    }
    if (m < 10) {
        m = "0" + m;
    }
    var time = h+":"+m+":"+s;
    $$('#clock_time').html(time);
    setTimeout(function(){getdate()}, 500);
}
//menu
function user_nav(c) {
    $$('.u_hide').hide();
    $$('.' + c).show();
    $$('.navbar').hide();
    $$('.'+c+'-nav').show();
}
$$(document).on('click', '.cbutton', function (e) {
    var cls = $$(this).data('class');
    user_nav(cls);
});
jQuery(document).ready(function(){
    if (window.localStorage["username"] != undefined && window.localStorage["password"] != undefined) {
        if (window.localStorage["username"] != '' && window.localStorage["password"] != '') {
            $$('.uname').val(window.localStorage["username"]);
            $$('.pass').val(window.localStorage["password"]);
            handleLogin();
        }
    }
});
jQuery(document).ready(function(){
    $$('.login_btn').on('click', function () {
        $$('.u_info').html('');
        $$('.p_info').html('');
        $$('.w_info').html('');

        if ($$('.uname').val() == '') {
            $$('.u_info').html('Please Insert Username.');
        } else if ($$('.pass').val() == '') {
            $$('.p_info').html('Please Insert Password.');
        } else {
            handleLogin();
        }
    });
});
document.addEventListener("deviceready", onDeviceReady, false);
function onDeviceReady() {
    document.addEventListener("backbutton", onBackKeyDown, false); //Listen to the User clicking on the back button
}
function onBackKeyDown(e) {
    e.preventDefault();
    navigator.notification.confirm("Are you sure you want to exit ?", onConfirm, "Confirmation", "Yes,No");
    // Prompt the user with the choice
}
function onConfirm(button) {
    if(button==1){//If User selected No, then we just do nothing
        navigator.app.exitApp();// Otherwise we quit the app.
    }else{
        return;
    }
}
function onLoggedOut(button) {
    if(button==1){//If User selected No, then we just do nothing
        logout();
    }else{
        return;
    }
}
function alertDismissed() {
    return false;
}
function showAlert(msg,title,button_name) {
    navigator.notification.alert(msg,alertDismissed,title,button_name);
}
// touch events
/*
var detectTap;
$$(document).on('touchstart', function(event) {
    event.stopPropagation();
    detectTap = true; //detects all touch events
});
$$(document).on('touchmove', function(event) {
    event.stopPropagation();
    detectTap = false; //Excludes the scroll events from touch events
});
$$(document).on('click touchend', function(event) {
    event.stopPropagation();
    if (event.type == "click") detectTap = true; //detects click events
    if (detectTap){
        alert('Touch with click');
    }
});
*/
function create_menu(menu) {
    var user_info = app_data.user_info;
    var menu_all = menu;
    var parent_css='';
    var another_parent_css='';
    var html = '';
    var expand_status='';
    $$.each(menu_all.parent, function( index, value ) {
        expand_status=0;
        another_parent_css='';
        if(typeof menu_all.child[index] !== "undefined"){
            expand_status=1;
            another_parent_css='<i style="" class="material-icons">arrow_drop_down_circle</i>';
        }
        html += '<li class="accordion-item menu_list">' +
            '<a href="#" class="item-content item-link">'+
            '<div class="item-inner">'+
            '<div data-expand="'+expand_status+'" data-class="'+value.data_class+'" class="item-title parent_menu menu '+value.data_class+'">'+
            '<div class="row">'+
            '<div class="col-15">'+value.icon+'</div>'+
            '<div class="col-65" style="margin-top: -5px;font-size: 13px;">'+value.menu_name+'</div>'+
            '<div class="col-20" style="margin-top: 1px;">'+another_parent_css+'</div>'+
            '</div>'+
            '</div>'+
            '</div>'+
            '</a>';
        if(typeof menu_all.child[index] !== "undefined")
        {
            $$.each(menu_all.child[index], function( c_index, c_value ) {
                html+='<div style="background-color: #52143D !important;" class="accordion-item-content child_menu_div">' +
                    '<div class="block child_menu menu '+c_value.data_class+'" data-class="'+c_value.data_class+'">' +
                    '<p class="p_child_menu" style="font-size: 13px;">'+c_value.icon+' '+c_value.menu_name+'</p>' +
                    '</div>' +
                    '</div>';
            });
        }
        else
        {
            html+='<div style="" class="accordion-item-content">' +
                '</div>';
        }
        html += '</li>';
    });
    $$('.user_name_show').html(user_info.name);
    $$('.user_level_show').html(user_info.user_level_name);
    $$('.menu_container').html(html);
    $$('.menu').on('click', function () {
        menu_action($$(this).attr('data-class'),Number($$(this).attr('data-expand')));
    });
}
//connection check
function checkConnection() {
    //return true;
    var networkState = navigator.connection.type;
    var states = {};
    states[Connection.UNKNOWN]  = 1;
    states[Connection.ETHERNET] = 2;
    states[Connection.WIFI]     = 3;
    states[Connection.CELL_2G]  = 4;
    states[Connection.CELL_3G]  = 5;
    states[Connection.CELL_4G]  = 6;
    states[Connection.CELL]     = 7;
    states[Connection.NONE]     = 8;
    if((states[networkState]==1) || (states[networkState]==8))
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

//check file exists or not START
// function check_file_exist_or_not(path){
//     // path is the full absolute path to the file.
//     window.resolveLocalFileSystemURL(path, getFileExists, getFileNotExists);
// }
// function getFileExists(fileEntry){
//     alert('exists');
// }
// function getFileNotExists(){
//     alert('File Not Exists');
// }
//check file exists or not END


// check file exists or not with data START
function check_file_and_data_for_auto_login(path)
{
    window.resolveLocalFileSystemURL(path, gotFile, file_fail);
    function gotFile(fileEntry) {
        fileEntry.file(function(file) {
            var reader = new FileReader();
            reader.onloadend = function(e) {
                try {
                    var dt = jsEncode.encode(this.result,'123');
                    app_data = JSON.parse(dt);
                    var otp_status_submit='verified';
                    var u = $$('.uname').val();
                    var p = $$('.pass').val();
                    login_request(u,p,otp_status_submit);
                }
                catch(e){
                    myApp.hideIndicator();
                    alert('Corrupted file found!');
                    logout();
                    return;
                };
            }
            reader.readAsText(file);
        });
    }
    function file_fail(e) {
        myApp.hideIndicator();
        logout();
        alert("File Missing!");
    }
}
//check file exists or not with data END

//login check
function handleLogin() {
    myApp.showIndicator();
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    //disable the button so we can't resubmit while we wait
    var u = $$('.uname').val();
    var p = $$('.pass').val();
    var otp_status_submit='';
    if (u != '' && p != '') {
        if(typeof window.localStorage["otp_status"]!=='undefined' && window.localStorage["otp_status"]==1)
        {
            otp_status_submit='verified';
            check_file_and_data_for_auto_login('file:///storage/emulated/0/AsianPaint/data/life.json');
        }
        else
        {
            ready_the_blank_file(u,p,otp_status_submit);
        }
    } else {
        alert('Try Again');
    }
    return false;
}
function login_request(u,p,otp_status_submit)
{
    var url = base_url+"app/app_login";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:'',username:u,password:p,otp_status:otp_status_submit,new_data:new_data},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status == "success")
            {
                window.localStorage["username"] = u;
                window.localStorage["password"] = p;
                app_data.user_info = response.user_info;
                window.localStorage["today_date"]=response.today_date;
                if(response.attendance_configure_status==1)
                {
                    window.localStorage["check_in_addr"]='';
                    window.localStorage["check_in_lat"]='';
                    window.localStorage["check_in_long"]='';
                    window.localStorage["check_out_addr"]='';
                    window.localStorage["check_out_lat"]='';
                    window.localStorage["check_out_long"]='';
                    $$('.attendance-in-time').html('N/A');
                    $$('.attendance-out-time').html('N/A');
                    $$('#check-in-addr').html('N/A');
                    $$('#check-out-addr').html('N/A');
                    $$('#check_in_time').html('');
                    $$('#check_out_time').html('');
                    window.localStorage["attendance_configure_status"]=1;
                    window.localStorage["check_in_time"]=response.check_in_time;
                    window.localStorage["check_out_time"]=response.check_out_time;
                    window.localStorage["check_in_date_time"]=response.check_in_date_time;
                    window.localStorage["check_out_date_time"]=response.check_out_date_time;
                    if(response.check_in_time!='')
                    {
                        $$('.attendance-in-time').html(response.check_in_time);
                        $$('#check-in-addr').html(response.check_in_addr);
                        $$('#check_in_time').html(response.check_in_time);
                        window.localStorage["check_in_addr"]=response.check_in_addr;
                        window.localStorage["check_in_lat"]=response.check_in_lat;
                        window.localStorage["check_in_long"]=response.check_in_long;
                        $$('.check_in_for_attendance').attr('disabled','disabled');
                        $$('.check_out_for_attendance').removeAttr('disabled');
                    }
                    else
                    {
                        $$('.check_in_for_attendance').removeAttr('disabled');
                        $$('.check_out_for_attendance').attr('disabled','disabled');
                    }
                    if(response.check_out_time!='')
                    {
                        $$('.attendance-out-time').html(response.check_out_time);
                        $$('#check-out-addr').html(response.check_out_addr);
                        $$('#check_out_time').html(response.check_out_time);
                        window.localStorage["check_out_addr"]=response.check_out_addr;
                        window.localStorage["check_out_lat"]=response.check_out_lat;
                        window.localStorage["check_out_long"]=response.check_out_long;
                        $$('.check_in_for_attendance').attr('disabled','disabled');
                        $$('.check_out_for_attendance').attr('disabled','disabled');
                    }
                }
                else
                {
                    window.localStorage["attendance_configure_status"]=0;
                }
                if(response.user_info.user_level=='APEC')
                {
                    window.localStorage["new_project_number_today"]=response.new_project;
                    window.localStorage["new_painter_number_today"]=response.new_painter;
                    window.localStorage["new_followup_project_all_number_today"]=response.new_follow_project_active;
                    window.localStorage["new_followup_project_com_number_today"]=response.new_follow_project_complete;
                    window.localStorage["new_followup_painter_all_number_today"]=response.new_follow_painter_active;
                    window.localStorage["new_followup_painter_com_number_today"]=response.new_follow_painter_complete;
                }
                else
                {
                    window.localStorage["new_project_number_today"]=0;
                    window.localStorage["new_painter_number_today"]=0;
                    window.localStorage["new_followup_project_all_number_today"]=0;
                    window.localStorage["new_followup_project_com_number_today"]=0;
                    window.localStorage["new_followup_painter_all_number_today"]=0;
                    window.localStorage["new_followup_painter_com_number_today"]=0;
                }
                if(typeof window.localStorage["otp_status"]!=='undefined' && window.localStorage["otp_status"]==1)
                {
                    $$('.v_code_btn').attr('disabled','disabled');
                    create_menu(app_data.menu);
                    $$('.view-otp').hide();
                    $$('.view-main').hide();
                    $$('.admin_footer').show();
                    $$('.view-admin').show();
                    home_action('home');
                }
                else
                {
                    window.localStorage["code"] = response.code;
                    window.localStorage["token"] = response.token;
                    window.localStorage["otp_sent_status"] = response.otp_sent_status;
                    app_data.menu = response.menu;
                    app_data.user_location = response.user_location;
                    app_data.dealer_location = response.dealer_location;
                    app_data.depo_location = response.depo_location;
                    app_data.painter_info = response.painter_info;
                    app_data.consultant_info = response.consultant_info;
                    app_data.contact_person_info = response.contact_person_info;
                    app_data.project_nature = response.project_nature;
                    app_data.painting_type = response.painting_type;
                    app_data.project_category = response.project_category;
                    app_data.project_segment = response.project_segment;
                    app_data.project_sub_segment = response.project_sub_segment;
                    app_data.project_status = response.project_status;
                    app_data.possible_users_info = response.possible_users_info;
                    app_data.level_mapping = response.level_mapping;
                    app_data.lead_source = response.lead_source;
                    app_data.project_detail_info = response.project_detail_info;
                    app_data.products = response.products;
                    app_data.rating_status = response.rating_status;
                    app_data.progoti_details = response.progoti_details;
                    app_data.all_user_level_info = response.all_user_level_info;
                    app_data.product_category = response.product_category;
                    app_data.project_competitors = response.project_competitors;
                    $$('.popup-login').hide();
                    $$('.popup-overlay').removeClass('modal-overlay-visible');
                    $$('.view-main').hide();
                    $$('.view-admin').hide();
                    if(window.localStorage["otp_sent_status"]=='success')
                    {
                        $$('.v_code_btn').attr('disabled','disabled');
                        $$('#resend_div').hide();
                        $$('.v_code_btn').show();
                    }
                    else
                    {
                        $$('.v_code_btn').attr('disabled','disabled');
                        $$('.v_code_btn').hide();
                        $$('#resend_div').show();
                    }
                    $$('.view-otp').show();
                    $$('.p_admin').hide();
                    $$('.p_rtm').hide();
                }
                getdate();
                $$('#date_home_page').html(get_today_date());
                saveJSON();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                $$('.v_code_btn').attr('disabled','disabled');
                empty_data();
                if(empty_file_data())
                {
                    saveJSON();
                }
                $$('.view-main').show();
                $$('.view-admin').hide();
                $$('.w_info').show();
                $$('.w_info').html('The username or password you entered is incorrect.');
            }
        },
        error: function (e) {
            alert(JSON.stringify(e));
            alert('There was a problem connecting to the server.Please try again.');
            myApp.hideIndicator();
            $$('.view-main').show();
            $$('.view-admin').hide();
        },
        complete: function (e) {
            myApp.hideIndicator();
            if(!upload_image_function_status)
            {
                if(typeof window.localStorage["captured_pic"]=='undefined')
                {
                    refill_captured_picture();
                }
                else
                {
                    var imageArr = JSON.parse(window.localStorage["captured_pic"]);
                    if(imageArr.length > 0) {
                        uploadImageToServer();
                    }
                    else
                    {
                        refill_captured_picture();
                    }
                }
            }
        }
    });
}
function refill_captured_picture()
{
    if(typeof app_data.user_info!=="undefined" && app_data.user_info!='')
    {
        var user_info = app_data.user_info;
        var url=base_url+"app/refill_captured_picture";
        $$.ajax({
            url: url,
            type: "POST",
            datatype:'json',
            data: {user_id:user_info.user_id},
            cache: false,
            success: function(data){
                var pictures=[];
                var response = JSON.parse(data);
                $$.each(response.project, function (index, value) {
                    pictures.push({type :'project', name : value});
                });
                $$.each(response.invoice, function (index, value) {
                    pictures.push({type :'invoice', name : value});
                });
                $$.each(response.ratification, function (index, value) {
                    pictures.push({type :'ratification', name : value});
                });
                window.localStorage["captured_pic"] = JSON.stringify(pictures);
                uploadImageToServer();
            },
            error: function (e) {
                refill_captured_picture();
            }
        });
    }
}
$$('.v_code_btn').on("click", function (e) {
    var code = $$('.v_code_total').val();
    if(code!='')
    {
        if(code==window.localStorage["code"])
        {
            $$(".v_code").each(function(index,valu)
            {
                $$(this).val('');
            });
            create_menu(app_data.menu);
            window.localStorage["otp_status"] = 1;
            $$('.view-otp').hide();
            $$('.view-main').hide();
            $$('.view-admin').show();
            $$('.admin_footer').show();
            $$('.w_info').hide();
            $$('.w_info ').html('');
            home_action('home');
        }
        else
        {
            $$('.w_info').show();
            $$('.w_info ').html('The OTP you entered is incorrect. Please Try Again.');
        }
    }
    else
    {
        $$('.w_info').show();
        $$('.w_info ').html('The OTP you entered is incorrect. Please Try Again.');
    }
});
$$(".v_code").on("keypress keyup blur",function (event) {
    $$(this).val($$(this).val().replace(/[^\d].+/, ""));
    if ((event.which < 48 || event.which > 57)) {
        event.preventDefault();
    }
});
$$('.v_code').on('input', function(event) {
    var count=$$(this).val().length;
    var new_code='';
    var data_id;
    if(count>1)
    {
        count=count-1;
        data_id = Number($$(this).attr('data-id'));
        new_code=$$('#code_'+data_id).val().slice(0,-count);
        $$('#code_'+data_id).val(new_code);
    }
    else
    {
        var total_code='';
        $$(".v_code").each(function(index,valu)
        {
            new_code=$$(this).val();
            if(new_code!='' && typeof new_code!=="undefined")
            {
                total_code+=new_code;
            }
        });
        $$('.v_code_total').val(total_code);
    }
    data_id = Number($$(this).attr('data-id'));
    if(data_id<6 && count!=0)
    {
        data_id=data_id+1;
        $$("#code_"+data_id).focus();
    }
    if(Number($$('.v_code_total').val().length)==6)
    {
        $$('.v_code_btn').removeAttr('disabled');
    }
    else
    {
        $$('.v_code_btn').attr('disabled','disabled');
    }
});
$$('.a_home').on("click", function (e) {
    home_action('home')
});
$$('#resend_otp').on("click", function (e) {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    $$('#resend_div').hide();
    var user_info = app_data.user_info;
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    var url=base_url+"app/resend_otp";
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {user_id:user_info.user_id,new_data:new_data},
        //timeout: 15000,
        cache: false,
        success: function(data){
            var response= JSON.parse(data);
            if(response.status=='success')
            {
                $$('.v_code_btn').show();
                window.localStorage["code"] = response.code;
                window.localStorage["token"] = response.token;
            }
            else if(response.status=='unauthorized')
            {
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                $$('#resend_div').hide();
                $$('.v_code_btn').hide();
            }
        },
        error: function (e) {
            //alert(JSON.stringify(e));
            $$('#resend_div').hide();
            $$('.v_code_btn').show();
        }
    });
});
function empty_data() {
    $$('.v_code_total').val('');
    window.localStorage["today_date"]='';
    window.localStorage["username"]='';
    window.localStorage["password"]='';
    window.localStorage["code"]='';
    window.localStorage["otp_status"]=0;
    window.localStorage["otp_sent_status"]='';
    window.localStorage["attendance_configure_status"]='';
    window.localStorage["check_in_time"]='';
    window.localStorage["check_out_time"]='';
    window.localStorage["check_in_date_time"]='';
    window.localStorage["check_out_date_time"]='';
    window.localStorage["new_project_number_today"]='';
    window.localStorage["new_painter_number_today"]='';
    window.localStorage["token"]='';
    window.localStorage["check_in_addr"]='';
    window.localStorage["check_in_lat"]='';
    window.localStorage["check_in_long"]='';
    window.localStorage["check_out_addr"]='';
    window.localStorage["check_out_lat"]='';
    window.localStorage["check_out_long"]='';
    window.localStorage["new_followup_project_all_number_today"]='';
    window.localStorage["new_followup_project_com_number_today"]='';
    window.localStorage["new_followup_painter_all_number_today"]='';
    window.localStorage["new_followup_painter_com_number_today"]='';
}
function empty_file_data()
{
    app_data.menu = {};
    app_data.user_info = {};
    app_data.user_location = {};
    app_data.dealer_location = {};
    app_data.depo_location = {};
    app_data.painter_info = {};
    app_data.consultant_info = {};
    app_data.contact_person_info = {};
    app_data.project_nature = {};
    app_data.painting_type = {};
    app_data.project_category = {};
    app_data.project_segment = {};
    app_data.project_sub_segment = {};
    app_data.project_status = {};
    app_data.possible_users_info = {};
    app_data.level_mapping = {};
    app_data.lead_source = {};
    app_data.project_detail_info = {};
    app_data.sales_order_list_info = {};
    app_data.products = {};
    app_data.rating_status = {};
    app_data.progoti_details = {};
    app_data.product_category = {};
    app_data.project_competitors = {};
    return true;
}
$$('#next_button').on("click", function (e) {
    $$('.u_hide').hide();
    $$('.create_project_1').show();
    $$('.navbar').hide();
    $$('.create_project_1-nav').show();
});
$$('#next_button_2').on("click", function (e) {
    $$('.u_hide').hide();
    $$('.create_project_2').show();
    $$('.navbar').hide();
    $$('.create_project_2-nav').show();
});
$$('#back_project_1').on("click", function (e) {
    $$('.u_hide').hide();
    $$('.create_project').show();
    $$('.navbar').hide();
    $$('.create_project-nav').show();
});
$$('#back_project_2').on("click", function (e) {
    $$('.u_hide').hide();
    $$('.create_project_1').show();
    $$('.navbar').hide();
    $$('.create_project_1-nav').show();
});
function check_action_status()
{
    if(window.localStorage["attendance_configure_status"]==1)
    {
        if(window.localStorage["check_in_time"]=='')
        {
            alert('Check-In time missing!');
            return false;
        }
        else if(window.localStorage["check_in_time"]!='' && window.localStorage["check_out_time"]!='')
        {
            alert('You are already checked out for today. So you can not create project!');
            return false;
        }
        else
        {
            return true;
        }
    }
    else
    {
        return true;
    }
}
function menu_action(class_name,expand_status) {
    if(expand_status!=1)
    {
        myApp.closePanel();
        $$('.popup-overlay').removeClass('modal-overlay-visible');
        myApp.closeModal('.popover');
        if(class_name=='logout')
        {
            navigator.notification.confirm("Are you sure you want to logged out ?", onLoggedOut, "Confirmation", "Yes,No");
        }
        else if(class_name=='create_project')
        {
            if(check_action_status())
            {
                create_project(class_name);
            }
        }
        else if(class_name=='project_list')
        {
            project_list('project_list');
        }
        else if(class_name=='home')
        {
            home_action('home');
        }
        else if(class_name=='attendance')
        {
            attendance_action('attendance');
        }
        else if(class_name=='consultant')
        {
            consultant_list('consultant');
        }
        else if(class_name=='contact_person')
        {
            contact_person_list('contact_person');
        }
        else if(class_name=='painter_list')
        {
            painter_list('painter_list');
        }
        else if(class_name=='project_call')
        {
            show_project_call_summary('project_call');
        }
        else if(class_name=='painter_call')
        {
            show_painter_call_summary('painter_call');
        }
        else if(class_name=='create_sales')
        {
            if(check_action_status())
            {
                show_sales_create_page('create_sales');
            }
        }
        else if(class_name=='sales_list')
        {
            show_sales_order_list('sales_list');
        }
        else if(class_name=='invoice_submit')
        {
            if(check_action_status())
            {
                show_invoice_submit_page('invoice_submit');
            }
        }
        else if(class_name=='sales_ratification_list')
        {
            show_sales_ratification_list('sales_ratification_list');
        }
        else if(class_name=='create_painter')
        {
            if(check_action_status())
            {
                create_painter_function('create_painter');
            }
        }
        else
        {
            adminView.router.load({
                pageName: class_name+'-page'
            });
            user_nav(class_name);
        }
    }
}
function logout()
{
    empty_data();
    if(empty_file_data())
    {
        saveJSON();
    }
    $$('.view-admin').hide();
    $$('.admin_footer').hide();
    $$('.view-main').show();
    myApp.closePanel();
    $$('.popup-overlay').removeClass('modal-overlay-visible');
    myApp.closeModal('.popover');
}

function __timeOver() {
    empty_data();
    if(empty_file_data())
    {
        saveJSON();
    }
    alert('New Day Found! Please login Again');
    $$('.view-admin').hide();
    $$('.admin_footer').hide();
    $$('.view-main').show();
    myApp.closePanel();
    $$('.popup-overlay').removeClass('modal-overlay-visible');
    //myApp.closeModal('.popup');
    myApp.closeModal('.popover');
}
function __deprecated() {
    empty_data();
    if(empty_file_data())
    {
        saveJSON();
    }
    alert('Old Version Detected! Please find the updated version of this App.');
    $$('.view-admin').hide();
    $$('.admin_footer').hide();
    $$('.view-main').show();
    myApp.closePanel();
    $$('.popup-overlay').removeClass('modal-overlay-visible');
    //myApp.closeModal('.popup');
    myApp.closeModal('.popover');
}

function consultant_list(cls_name) {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    var url=base_url+"app/get_consultant_info";
    var user_info = app_data.user_info;
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    myApp.showIndicator();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],user_id:user_info.user_id,new_data:new_data},
        //timeout: 15000,
        cache: false,
        success: function(data){
            var response= JSON.parse(data);
            if(response.status=='success')
            {
                app_data.consultant_info=response.consultant_data;
                var html='';
                $$.each(response.consultant_data, function (index, values) {
                    html+='<div class="row consultant_list_div list_div consultant_list_'+values.id+'" data-id="'+values.id+'">' +
                        '<div class="col-70 list_div_part div_parent_list"><div class="div_child_list">' +
                        '<span style="font-weight: bold;color: black;letter-spacing: 0.5px;font-size: 12px;">'+values.consultant_name+'</span>' +
                        '<p style="font-size: 11px;">'+values.contact+'</p>' +
                        '</div></div>' +
                        '<div class="col-30 list_div_part list_div_part_status div_parent_list"><div class="div_child_list">' +
                        '<span style="color: grey;font-weight: bold;font-size: 11px;">Consultant</span>' +
                        '</div></div>' +
                        '</div>';
                    html += '<div class="row separator consultant_list_'+values.id+'"></div>';
                });
                $$('.consultant_container').html('');
                $$('.consultant_container').html(html);
                $$('.consultant_list_div').on('click', function () {
                    show_consultant_details($$(this).attr('data-id'));
                });
                saveJSON();
            }
            else if(response.status=='unauthorized')
            {
                alert('System Found Unauthorized Action!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Failed to retrieve data!');
            }
            myApp.hideIndicator();
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
    adminView.router.load({
        pageName: cls_name+'-page'
    });
    user_nav(cls_name);
}

function contact_person_list(cls_name) {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    var url=base_url+"app/get_contact_person";
    var user_info = app_data.user_info;
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    myApp.showIndicator();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],user_id:user_info.user_id,new_data:new_data},
        //timeout: 15000,
        cache: false,
        success: function(data){
            var response= JSON.parse(data);
            if(response.status=='success')
            {
                app_data.contact_person_info=response.contact_person_data;
                var html='';
                $$.each(response.contact_person_data, function (index, values) {
                    html+='<div class="row contact_person_list_div list_div contact_person_list_'+values.id+'" data-id="'+values.id+'">' +
                        '<div class="col-60 list_div_part div_parent_list"><div class="div_child_list">' +
                        '<span style="font-weight: bold;color: black;letter-spacing: 0.5px;font-size: 12px;">'+values.contact_person_name+'</span>' +
                        '<p style="font-size: 11px;">'+values.contact+'</p>' +
                        '</div></div>' +
                        '<div class="col-40 list_div_part list_div_part_status div_parent_list"><div class="div_child_list">' +
                        '<span style="color: grey;font-weight: bold;font-size: 11px;">Contact Person</span>' +
                        '</div></div>' +
                        '</div>';
                    html += '<div class="row separator contact_person_list_'+values.id+'"></div>';
                });
                $$('.contact_person_container').html('');
                $$('.contact_person_container').html(html);
                $$('.contact_person_list_div').on('click', function () {
                    show_contact_person_details($$(this).attr('data-id'));
                });
                saveJSON();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else if(response.status=='unauthorized')
            {
                alert('System Found Unauthorized Action!');
                logout();
            }
            else
            {
                alert('Failed to retrieve data!');
            }
            myApp.hideIndicator();
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
    adminView.router.load({
        pageName: cls_name+'-page'
    });
    user_nav(cls_name);
}
function create_painter_function(class_name) {
    $$('#form_painter_name').val('');
    $$('#form_painter_contact').val('');
    html='';
    var location=app_data.user_location;
    var progoti_details=app_data.progoti_details;
    var number_of_regions = 0;
    var number_of_areas = 0;
    var number_of_territories = 0;
    var number_of_clusters = 0;
    var phtml='';
    $$.each(progoti_details, function (index, pvalue) {
        phtml+='<option value="'+pvalue.id+'">'+pvalue.name+'</option>';
    });
    $$('.form_progoti_status').html(phtml);
    $$.each(location.region, function (region_id, r_value) {
        ++number_of_regions;
    });
    $$.each(location.area, function (area_id, a_value) {
        $$.each(a_value, function (i, v) {
            ++number_of_areas;
        });
    });
    $$.each(location.territory, function (territory_id, t_value) {
        $$.each(t_value, function (i, v) {
            ++number_of_territories;
        });
    });
    var cluster='';
    $$.each(location.cluster, function (cluster_id, c_value) {
        $$.each(c_value, function (i, v) {
            cluster=v.cluster_id;
            ++number_of_clusters;
        });
    });
    if(number_of_regions==1)
    {
        $$.each(location.region, function (index, value) {
            $$('.painter_region_label').html(value.region_code+' - '+value.region_name);
            $$('#painter_region').val(index);
        });
        $$('.painter_region_select').hide();
        $$('.painter_region_label').show();
    }
    else
    {
        var html = '';
        $$.each(location.region, function (index, value) {
            html+='<option value="'+value.region_id+'">'+value.region_code+' - '+value.region_name+'</option>';
        });
        $$('.painter_region_select').html(html);
        $$('.painter_region_label').hide();
        $$('.painter_multi_region_select').show();
        $$('.painter_multi_region_select_div').css('margin-top','-7px');
    }
    if(number_of_areas==1)
    {
        $$.each(location.area, function (area_id, a_value) {
            $$.each(a_value, function (i, v) {
                $$('.painter_area_label').html(v.area_code+' - '+v.area_name);
                $$('#painter_area').val(v.area_id);
            });
        });
        $$('.painter_area_select').hide();
        $$('.painter_area_label').show();
    }
    else
    {
        var html = '';
        $$.each(location.area, function (area_id, a_value) {
            $$.each(a_value, function (i, v) {
                html+='<option value="'+v.area_id+'">'+v.area_code+' - '+v.area_name+'</option>';
            });
        });
        $$('.painter_area_select').html(html);
        $$('.painter_area_label').hide();
        $$('.painter_multi_area_select').show();
        $$('.painter_multi_area_select_div').css('margin-top','-7px');
    }
    if(number_of_territories==1)
    {
        $$.each(location.territory, function (t_index, t_value) {
            $$.each(t_value, function (i, v) {
                $$('.painter_territory_label').html(v.territory_code+' - '+v.territory_name);
                $$('#painter_territory').val(v.territory_id);
            });
        });
        $$('.painter_territory_select').hide();
        $$('.painter_territory_label').show();
    }
    else
    {
        var html = '';
        $$.each(location.territory, function (territory_id, t_value) {
            $$.each(t_value, function (i, v) {
                html+='<option value="'+v.territory_id+'">'+v.territory_code+' - '+v.territory_name+'</option>';
            });
        });
        $$('.painter_territory_select').html(html);
        $$('.painter_territory_label').hide();
        $$('.painter_multi_territory_select').show();
        $$('.painter_multi_territory_select_div').css('margin-top','-7px');
    }
    if(number_of_clusters==1)
    {
        $$.each(location.cluster, function (cluster_id, c_value) {
            $$.each(c_value, function (i, v) {
                $$('.painter_cluster_label').html(v.cluster_code+' - '+v.cluster_name);
                $$('#painter_cluster').val(v.cluster_id);
            });
        });
        $$('.painter_cluster_select').hide();
        $$('.painter_cluster_label').show();
    }
    else
    {
        var html = '';
        $$.each(location.cluster, function (cluster_id, c_value) {
            $$.each(c_value, function (i, v) {
                html+='<option value="'+v.cluster_id+'">'+v.cluster_code+' - '+v.cluster_name+'</option>';
            });
        });
        $$('.painter_cluster_select').html(html);
        $$('.painter_cluster_label').hide();
        $$('.painter_multi_cluster_select').show();
        $$('.painter_multi_cluster_select_div').css('margin-top','-7px');
    }
    adminView.router.load({
        pageName: class_name+'-page'
    });
    user_nav(class_name);
}
$$('.painter_region_select').on('change', function () {
    var region_id = $$(this).val();
    if(region_id)
    {
        $$('#painter_region').val(region_id);
        var html=set_area_select(region_id);
        $$('.painter_area_select').html(html);
        $$('.painter_territory_select').html('');
        $$('.painter_cluster_select').html('');
    }
    else
    {
        $$('#painter_region').val('');
        $$('.painter_area_select').html('');
        $$('.painter_territory_select').html('');
        $$('.painter_cluster_select').html('');
    }
    $$('#painter_area').val('');
    $$('#painter_territory').val('');
    $$('#painter_cluster').val('');
});
$$('.painter_area_select').on('change', function () {
    var area_id = $$(this).val();
    if(area_id)
    {
        $$('#painter_area').val(area_id);
        var html = set_territory_select(area_id);
        $$('.painter_territory_select').html(html);
        $$('.painter_cluster_select').html('');
    }
    else
    {
        $$('#painter_area').val('');
        $$('.painter_territory_select').html('');
        $$('.painter_cluster_select').html('');
    }
    $$('#painter_territory').val('');
    $$('#painter_cluster').val('');
});
$$('.painter_territory_select').on('change', function () {
    var territory_id = $$(this).val();
    if(territory_id.length)
    {
        $$('#painter_territory').val(territory_id);
        var html = set_cluster_select(territory_id);
        $$('.painter_cluster_select').html(html);
    }
    else
    {
        $$('#painter_territory').val('');
        $$('.painter_cluster_select').html('');
    }
    $$('#painter_cluster').val('');
});
$$('.painter_cluster_select').on('change', function () {
    var cluster_id = $$(this).val();
    if(cluster_id)
    {
        $$('#painter_cluster').val(cluster_id);
    }
    else
    {
        $$('#painter_cluster').val('');
    }
});
function painter_list(cls_name) {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    var user_info = app_data.user_info;
    var url=base_url+"app/get_painter_list";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    myApp.showIndicator();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],user_id:user_info.user_id,new_data:new_data},
        //timeout: 15000,
        cache: false,
        success: function(data){
            var response= JSON.parse(data);
            if(response.status=='success')
            {
                app_data.painter_info=response.painter_list_data;
                var user_location = app_data.user_location;
                var cluster_name_with_id=[];
                $$.each(user_location.cluster, function (cluster_id, c_value) {
                    $$.each(c_value, function (i, v) {
                        var id=v.cluster_id;
                        cluster_name_with_id[id]=v.cluster_name;
                    });
                });
                var status_html='<option value="ALL">ALL</option>' +
                    '<option value="Registered">Registered</option>' +
                    '<option value="Unregistered">Unregistered</option>';
                var progoti_details=app_data.progoti_details;
                $$.each(progoti_details, function (index, value) {
                    status_html+='<option value="'+value.name+'">'+value.name+'</option>';
                });
                $$('#filter_painter_status').html(status_html);
                var html='';
                $$.each(response.painter_list_data, function (cluster_id, set_values) {
                    html+='<div class="cluster_wise_painter cluster_painter_'+cluster_id+'">'+
                        '<div class="row" style="height: 25px;">' +
                        '<div class="col-100 cluster_div_for_painter">'+cluster_name_with_id[cluster_id]+'</div>' +
                        '</div>' +
                        '</div>';
                    html+='<div class="painter_list_container">';
                    $$.each(set_values, function (index, value) {
                        var color_css='';
                        if(value.status=='Active'){
                            color_css='color:green;';
                        }
                        else
                        {
                            color_css='color:#881313;';
                        }
                        html+='<div class="row painter_list_div list_div painter_list_'+value.id+'" data-id="'+value.id+'">' +
                            '<div class="col-65 list_div_part div_parent_list"><div class="div_child_list">' +
                            '<span style="font-weight: bold;color: black;letter-spacing: 0.5px;font-size: 12px;">'+value.painter_name+'</span>' +
                            '<p style="font-size: 11px;">'+value.contact+'</p>' +
                            '</div></div>' +
                            '<div class="col-35 list_div_part list_div_part_status div_parent_list"><div class="div_child_list">' +
                            '<span style="color: grey;font-weight: bold;font-size: 11px;'+color_css+'">'+value.status+'</span>' +
                            '</div></div>' +
                            '</div>';
                        html += '<div class="row separator painter_list_'+value.id+'"></div>';
                    });
                    html+='</div>';
                });
                $$('.painter_list_container').html('');
                $$('.total_painter_list').html(html);
                $$('.painter_list_div').on('click', function () {
                    show_painter_details($$(this).attr('data-id'));
                });
                adminView.router.load({
                    pageName: cls_name+'-page'
                });
                user_nav(cls_name);
                saveJSON();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else if(response.status=='unauthorized')
            {
                alert('System Found Unauthorized Action!');
                logout();
            }
            else
            {
                alert('Failed to retrieve data!');
            }
            myApp.hideIndicator();
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
function show_painter_details(id) {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    $$('#goto_followup_painter').attr('data-painter-id','');
    $$('#goto_followup_painter').attr('data-cluster-id','');
    var user_info = app_data.user_info;
    var url=base_url+"app/get_specific_painter_details";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    myApp.showIndicator();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],user_id:user_info.user_id,painter_id:id,new_data:new_data},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status=='success')
            {
                var cluster_id='';
                $$('#goto_followup_painter').attr('data-painter-id',id);
                $$.each(response.painter_details, function (index, value) {
                    if(index==0)
                    {
                        cluster_id+=value.cluster_id;
                        $$('#painter_details_name').html(value.painter_name);
                        $$('#painter_details_contact').html(value.contact);
                        $$('#painter_details_status').html(value.status);
                        $$('#painter_details_progoti_status').html(value.progoti_status);
                    }
                    else
                    {
                        cluster_id+=','+value.cluster_id;
                    }
                });
                $$('#goto_followup_painter').attr('data-cluster-id',cluster_id);
                $$('.u_hide').hide();
                $$('.painter_details').show();
                $$('.navbar').hide();
                $$('.painter_details-nav').show();
            }
            else if(response.status=='unauthorized')
            {
                alert('System Found Unauthorized Action!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Failed to retrieve data!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}

$$('#goto_followup_painter').on('click',function () {
    var id=$$(this).attr('data-painter-id');
    var cluster_id=$$(this).attr('data-cluster-id');
    if(check_action_status())
    {
        painter_appointment_set(id,cluster_id);
    }
});
function show_consultant_details(id) {
    var consultant_info=app_data.consultant_info;
    $$.each(consultant_info, function (index, value) {
        if(value.id==id)
        {
            $$('#consultant_details_name').html(value.consultant_name);
            $$('#consultant_details_email').html(value.email);
            $$('#consultant_details_contact').html(value.contact);
            $$('#consultant_details_dob').html(value.dob);
            $$('#consultant_details_image').html(value.image_text);
        }
    });
    $$('.u_hide').hide();
    $$('.consultant_details').show();
    $$('.navbar').hide();
    $$('.consultant_details-nav').show();
}

function show_contact_person_details(id) {
    var contact_person_info=app_data.contact_person_info;
    $$.each(contact_person_info, function (index, value) {
        if(value.id==id)
        {
            $$('#contact_person_details_name').html(value.contact_person_name);
            $$('#contact_person_details_contact').html(value.contact);
            $$('#contact_person_details_image').html(value.image_text);
        }
    });
    $$('.u_hide').hide();
    $$('.contact_person_details').show();
    $$('.navbar').hide();
    $$('.contact_person_details-nav').show();
}

function project_list(class_name)
{
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    var user_info = app_data.user_info;
    var user_location = app_data.user_location;
    var cluster_name_with_id=[];
    $$.each(user_location.cluster, function (cluster_id, c_value) {
        $$.each(c_value, function (i, v) {
            var id=v.cluster_id;
            cluster_name_with_id[id]=v.cluster_name;
        });
    });
    var url=base_url+"app/get_project_info";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    myApp.showIndicator();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],user_id:user_info.user_id,user_level_id:user_info.user_level_id,new_data:new_data},
        //timeout: 15000,
        cache: false,
        success: function(data){
            var response= JSON.parse(data);
            if(response.status=='success')
            {
                app_data.project_detail_info=response.project_list;
                var project_status = app_data.project_status;
                var rating_status = app_data.rating_status;
                var painter_info = app_data.painter_info;
                var html = '<option value="ALL">ALL</option>';
                $$.each(rating_status, function (index, value) {
                    html += '<option value="'+value.name+'">'+value.name+'</option>';
                });
                $$.each(project_status, function (index, value) {
                    html += '<option value="'+value.name+'">'+value.name+'</option>';
                });
                var painter_name_with_id=[];
                $$.each(painter_info, function (cluster_id, set_value) {
                    $$.each(set_value, function (index, value) {
                        var id=value.id;
                        painter_name_with_id[id]=value.painter_name;
                    });
                });
                $$('#rating_select_div').html(html);
                var html='';
                $$.each(response.project_list, function (cluster_id, set_values) {
                    html+='<div class="cluster_wise_project cluster_project_'+cluster_id+'">'+
                        '<div class="row" style="height: 25px;">' +
                        '<div class="col-100 cluster_div_for_project">'+cluster_name_with_id[cluster_id]+'</div>' +
                        '</div>' +
                        '</div>';
                    html+='<div class="project_list_container">';
                    $$.each(set_values, function (index, value) {
                        html += '<div class="row project_list_div list_div project_list_'+value.id+'" data-id="'+value.id+'">';
                        if(value.list_status_type=='pre')
                        {
                            html += '<div class="col-20 list_div_part_rating div_parent_list" style="color:'+value.list_status_color+'">' +
                                '<div class="div_child_list">'+value.project_status+'</div>' +
                                '</div>';
                        }
                        else
                        {
                            html += '<div class="col-20 list_div_part_project_status div_parent_list">' +
                                '<div class="div_child_list">'+value.project_status+'</div>' +
                                '</div>';
                        }
                        html += '<div class="col-55 list_div_part div_parent_list"><div class="div_child_list">' +
                            '<span style="font-size: 12px;font-weight: bold;color: black;letter-spacing: 0.5px;">' + value.project_name + '</span>' +
                            '<p style="font-size: 12px;">' + value.project_address + ', ' + painter_name_with_id[value.painter_id] + '</p>' +
                            '</div></div>' +
                            '<div class="col-25 list_div_part list_div_part_status div_parent_list"><div class="div_child_list">' +
                            '<span style="color: grey;font-weight: bold;font-size: 10px;">' + value.date + '</span>' +
                            '</div></div>' +
                            '</div>';
                        html += '<div class="row separator project_list_'+value.id+'"></div>';
                    });
                    html+='</div>';
                });
                $$('.project_list_container').html('');
                $$('.total_project_list').html(html);
                $$('.project_list_div').on('click', function () {
                    show_project_details($$(this).attr('data-id'));
                });
                adminView.router.load({
                    pageName: class_name+'-page'
                });
                user_nav(class_name);
                saveJSON();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else if(response.status=='unauthorized')
            {
                alert('System Found Unauthorized Action!');
                logout();
            }
            else
            {
                alert('Failed to retrieve data!');
            }
            myApp.hideIndicator();
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
function show_project_details(id) {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    $$('#edit_project_span').hide();
    $$('#edit_project_span').attr('data-id','');
    $$('#project_img').html('');
    $$('#goto_followup_project').attr('data-project-id','');
    $$('#project_name_project_details').html('');
    $$('#created_date_project_details').html('');
    $$('#created_person_project_details').html('');
    $$('#project_address_project_details').html('');
    $$('#region_project_details').html('');
    $$('#area_project_details').html('');
    $$('#territory_project_details').html('');
    $$('#cluster_project_details').html('');
    $$('#depot_project_details').html('');
    $$('#lead_source_project_details').html('');
    $$('#client_name_project_details').html('');
    $$('#client_mobile_project_details').html('');
    $$('#goc_project_details').html('');
    $$('#navision_project_details').html('');
    $$('#consultant_project_details').html('');
    $$('#contact_person_project_details').html('');
    $$('#painter_project_details').html('');
    $$('#dealer_project_details').html('');
    $$('#nature_project_details').html('');
    $$('#painting_type_project_details').html('');
    $$('#project_category_project_details').html('');
    $$('#segment_project_details').html('');
    $$('#sub_segment_project_details').html('');
    $$('#rating_project_details').html('');
    $$('#start_date_project_details').html('');
    $$('#end_date_project_details').html('');
    $$('#interior_paintable_project_details').html('');
    $$('#exterior_paintable_project_details').html('');
    $$('#total_site_project_details').html('');
    $$('#total_value_project_details').html('');
    $$('#ap_value_project_details').html('');
    $$('#lost_competition_project_details').html('');
    $$('#loss_reason_project_details').html('');
    $$('#value_potential_lost_details').html('');
    $$('#remarks_project_details').html('');
    $$('#conversion_status_project_details').html('');
    $$('#interior_project_details').html('');
    $$('#exterior_project_details').html('');
    $$('#water_proofing_project_details').html('');
    $$('#others_project_details').html('');
    var dealer=[];
    var depot=[];
    var dealer_location = app_data.dealer_location;
    var depo_location = app_data.depo_location;
    var project_status=[];
    var project_status_info=app_data.project_status;
    $$.each(project_status_info, function (index, value) {
        var id=value.id;
        project_status[id]=value.name;
    });
    var project_sub_segment=[];
    var project_sub_segment_info=app_data.project_sub_segment;
    $$.each(project_sub_segment_info, function (index, value) {
        var id=value.id;
        project_sub_segment[id]=value.name;
    });
    var project_segment=[];
    var project_segment_info=app_data.project_segment;
    $$.each(project_segment_info, function (index, value) {
        var id=value.id;
        project_segment[id]=value.name;
    });
    var project_category=[];
    var project_category_info=app_data.project_category;
    $$.each(project_category_info, function (index, value) {
        var id=value.id;
        project_category[id]=value.name;
    });
    var painting_type=[];
    var painting_type_info=app_data.painting_type;
    $$.each(painting_type_info, function (index, value) {
        var id=value.id;
        painting_type[id]=value.name;
    });
    var consultant=[];
    var consultant_info=app_data.consultant_info;
    $$.each(consultant_info, function (index, value) {
        var id=value.id;
        consultant[id]=value.consultant_name;
    });
    var contact_person=[];
    var contact_person_info=app_data.contact_person_info;
    $$.each(contact_person_info, function (index, value) {
        var id=value.id;
        contact_person[id]=value.contact_person_name;
    });
    var painter=[];
    var painter_info=app_data.painter_info;
    $$.each(painter_info, function (cluster_id, set_value) {
        $$.each(set_value, function (index, value) {
            var id=value.id;
            painter[id]=value.painter_name;
        });
    });
    var project_nature=[];
    var project_nature_info=app_data.project_nature;
    $$.each(project_nature_info, function (index, value) {
        var id=value.id;
        project_nature[id]=value.name;
    });
    var lead_source=[];
    var lead_source_info=app_data.lead_source;
    $$.each(lead_source_info, function (index, value) {
        var id=value.id;
        lead_source[id]=value.name;
    });
    var project_competitors=[];
    var project_competitor_info=app_data.project_competitors;
    $$.each(project_competitor_info, function (index, value) {
        var id=value.id;
        project_competitors[id]=value.name;
    });
    var products=[];
    var product_info=app_data.products;
    $$.each(product_info, function (index, value) {
        var id=value.id;
        products[id]=value.product_name;
    });
    var user_info = app_data.user_info;
    var user_location = app_data.user_location;
    var region=[];
    var area=[];
    var territory=[];
    var cluster=[];
    $$.each(user_location.region, function (region_id, region_values) {
        $$.each(user_location.area[region_id], function (area_id, area_values) {
            $$.each(user_location.territory[area_id], function (territory_id, territory_values) {
                $$.each(user_location.cluster[territory_id], function (cluster_id, cluster_values) {
                    var cluster_id=cluster_id;
                    region[cluster_id]=region_values.region_name;
                    area[cluster_id]=area_values.area_name;
                    territory[cluster_id]=territory_values.territory_name;
                    cluster[cluster_id]=cluster_values.cluster_name;
                });
            });
        });
    });
    var url=base_url+"app/get_project_details";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    myApp.showIndicator();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],user_id:user_info.user_id,project_id:id,new_data:new_data},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            image_order=0;
            image_name=[];
            if(response.status=='success')
            {
                $$.each(depo_location.cluster[response.details.cluster_id], function (index, value) {
                    depot[value.depo_id]=value.depo_code;
                });
                $$.each(dealer_location.cluster[response.details.cluster_id], function (index, value) {
                    dealer[value.dealer_id]=value.dealer_name;
                });
                var image_arr = response.details.image_names.split(',');
                $$.each(image_arr, function (index, value) {
                    var inx=Number(index)+1;
                    if(index==0)
                    {
                        image_order=index;
                    }
                    image_name[inx]=value;
                    var path = "file:///storage/emulated/0/AsianPaint/" + value;
                    checkIfFileExistsproject(path);
                });
                $$('#project_name_project_details').html(response.details.project_name);
                $$('#created_date_project_details').html(response.details.date);
                $$('#created_person_project_details').html(response.details.created_person);
                $$('#project_address_project_details').html(response.details.project_address);
                $$('#region_project_details').html(region[response.details.cluster_id]);
                $$('#area_project_details').html(area[response.details.cluster_id]);
                $$('#territory_project_details').html(territory[response.details.cluster_id]);
                $$('#cluster_project_details').html(cluster[response.details.cluster_id]);
                $$('#depot_project_details').html(depot[response.details.depo_wise_unique_id]);
                $$('#lead_source_project_details').html(lead_source[response.details.lead_source]);
                $$('#client_name_project_details').html(response.details.billing_client_name);
                $$('#client_mobile_project_details').html(response.details.billing_client_contact);
                $$('#goc_project_details').html(response.details.goc);
                $$('#navision_project_details').html(response.details.navision_code);
                $$('#consultant_project_details').html(consultant[response.details.consultant_id]);
                $$('#contact_person_project_details').html(contact_person[response.details.contact_person_id]);
                $$('#painter_project_details').html(painter[response.details.painter_id]);
                $$('#dealer_project_details').html(dealer[response.details.dealer_id]);
                $$('#nature_project_details').html(project_nature[response.details.project_nature_id]);
                $$('#painting_type_project_details').html(painting_type[response.details.painting_type_id]);
                $$('#project_category_project_details').html(project_category[response.details.project_category_id]);
                $$('#segment_project_details').html(project_segment[response.details.project_segment_id]);
                $$('#sub_segment_project_details').html(project_sub_segment[response.details.project_sub_segment_id]);
                $$('#rating_project_details').html(project_status[response.details.project_status_id]);
                $$('#start_date_project_details').html(response.details.expected_start_date);
                $$('#end_date_project_details').html(response.details.expected_end_date);
                $$('#conversion_status_project_details').html(response.details.conversion);
                $$('#interior_project_details').html(products[response.details.in]);
                $$('#exterior_project_details').html(products[response.details.ex]);
                $$('#water_proofing_project_details').html(products[response.details.wp]);
                $$('#others_project_details').html(products[response.details.ot]);
                // $$('#time_frame_project_details').html('');
                $$('#interior_paintable_project_details').html(response.details.interior_paintable_area);
                $$('#exterior_paintable_project_details').html(response.details.exterior_paintable_area);
                $$('#total_site_project_details').html(response.details.total_site_potentials);
                $$('#total_value_project_details').html(response.details.total_potential_value);
                $$('#ap_value_project_details').html(response.details.ap_potential_value);
                $$('#lost_competition_project_details').html(project_competitors[response.details.competition_lost]);
                $$('#loss_reason_project_details').html(response.details.reason_of_loss);
                $$('#value_potential_lost_details').html(response.details.value_potential_lost);
                $$('#remarks_project_details').html(response.details.remarks);
                $$('#goto_followup_project').attr('data-project-id',id);
                adminView.router.load({
                    pageName: 'project_list-page'
                });
                user_nav('project_details');
                if(response.details.created_by==user_info.user_id)
                {
                    $$('#edit_project_span').attr('data-id',response.details.id);
                    $$('#edit_project_span').css('display','inline-flex');
                }
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else if(response.status=='unauthorized')
            {
                alert('System Found Unauthorized Action!');
                logout();
            }
            else
            {
                alert('Failed to retrieve data!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
$$('#edit_project_span').on('click',function () {
    if(check_action_status())
    {
        update_project($$(this).attr('data-id'));
    }
});
function checkIfFileExistsproject(path){
    // path is the full absolute path to the file.
    window.resolveLocalFileSystemURL(path, fileExistsproject, fileDoesNotExistproject);
}
function fileExistsproject(fileEntry){
    image_order=Number(image_order)+1;
    var imagePath = "file:///storage/emulated/0"+fileEntry.fullPath;
    $$('#project_img').append('<img src="'+imagePath+'" style="width: 85%;padding: 5px;">');
}
function fileDoesNotExistproject(){
    image_order=Number(image_order)+1;
    var live_image_path=base_url+'public/uploads/project/'+image_name[image_order];
    var pending_image_path=base_url+'public/uploads/pending_img.jpg';
    UrlExists(live_image_path, function(status) {
        if(status.status === 200)
        {
            $$('#project_img').append('<img src="'+live_image_path+'" style="width: 85%;padding: 5px;">');
        }
        else if(status.status === 404)
        {
            $$('#project_img').append('<img src="'+pending_image_path+'" style="width: 85%;padding: 5px;">');
        }
        else
        {
            $$('#project_img').append('<img src="'+pending_image_path+'" style="width: 85%;padding: 5px;">');
        }
    },1);
}
function UrlExists(url, cb, id){
    $$.ajax({
        url:      url,
        dataType: 'text',
        type:     'GET',
        complete:  function(xhr){
            if(typeof cb === 'function')
            {
                var response = {
                    status: xhr.status,
                    id: id
                };
                cb.apply(this, [response]);
            }
        }
    });
}
$$('#goto_followup_project').on('click',function () {
    var id=$$(this).attr('data-project-id');
    if(check_action_status())
    {
        project_appointment_set(id);
    }
});
function create_project(class_name)
{
    $$('.extra_painter_container').css('display','none');
    $$('.extra_painter_code').html('');
    $$('.extra_dealer_container').css('display','none');
    $$('.extra_dealer_code').html('');
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    $$('#capture_image_for_project_id').removeAttr('disabled');
    $$('.project_image_name_div').html('');
    $$('#capture_image_for_project_id').css('display','flex');
    $$('#image_count').val('');
    $$('.imgDiv').remove();
    var user_info = app_data.user_info;
    myApp.showIndicator();
    $$.ajax({
        url: base_url+'app/get_number_of_project',
        type: "POST",
        data: {user_id:user_info.user_id},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var project_id=user_info.user_name+'-'+data;
            $$('#proMap').css("height","auto");
            $$('#proMap').html('<button onclick="getProjectLocation();" class="btn btn-sm" style="font-size:10px;object-fit: cover;"><i class="material-icons">place</i></button>');
            $$('.project_create_date').val(window.localStorage["today_date"]);
            $$('#expected_end_date').val(window.localStorage["today_date"]);
            $$('#expected_start_date').val(window.localStorage["today_date"]);
            $$('#project_id').val(project_id);
            var lead_source = app_data.lead_source;
            var project_nature = app_data.project_nature;
            var painting_type = app_data.painting_type;
            var project_category = app_data.project_category;
            var project_segment = app_data.project_segment;
            var project_sub_segment = app_data.project_sub_segment;
            var project_status = app_data.project_status;
            var project_competitors = app_data.project_competitors;
            var products = app_data.products;
            var product_category = app_data.product_category;
            var interior_opt = '<option value="">Choose Product</option>';
            var exterior_opt = '<option value="">Choose Product</option>';
            var water_proofing_opt = '<option value="">Choose Product</option>';
            var others_opt = '<option value="">Choose Product</option>';
            $$.each(products, function (p_i, p_v) {
                $$.each(product_category, function (pc_i, pc_v) {
                    if(p_v.category_id==pc_v.id && pc_v.category_code=='IN')
                    {
                        interior_opt += '<option value="'+p_v.id+'">'+p_v.product_name+'</option>';
                    }
                    if(p_v.category_id==pc_v.id && pc_v.category_code=='EX')
                    {
                        exterior_opt += '<option value="'+p_v.id+'">'+p_v.product_name+'</option>';
                    }
                    if(p_v.category_id==pc_v.id && pc_v.category_code=='WP')
                    {
                        water_proofing_opt += '<option value="'+p_v.id+'">'+p_v.product_name+'</option>';
                    }
                    if(p_v.category_id==pc_v.id && pc_v.category_code=='OT')
                    {
                        others_opt += '<option value="'+p_v.id+'">'+p_v.product_name+'</option>';
                    }
                });
            });
            $$('.interior_opt').html(interior_opt);
            $$('.exterior_opt').html(exterior_opt);
            $$('.water_proofing_opt').html(water_proofing_opt);
            $$('.others_opt').html(others_opt);
            var html = '<option value="">Choose Lead Source</option>';
            $$.each(lead_source, function (index, value) {
                html += '<option value="'+value.id+'">'+value.name+'</option>';
            });
            $$('.lead_source').html(html);
            html='';
            html = '<option value="">Choose Nature</option>';
            $$.each(project_nature, function (index, value) {
                html += '<option value="'+value.id+'">'+value.name+'</option>';
            });
            $$('.project_nature').html(html);
            html='';
            html = '<option value="">Choose Type</option>';
            $$.each(painting_type, function (index, value) {
                html += '<option value="'+value.id+'">'+value.name+'</option>';
            });
            $$('.painting_type').html(html);
            html='';
            html = '<option value="">Choose Category</option>';
            $$.each(project_category, function (index, value) {
                html += '<option value="'+value.id+'">'+value.name+'</option>';
            });
            $$('.project_category').html(html);
            html='';
            html = '<option value="">Choose Segment</option>';
            $$.each(project_segment, function (index, value) {
                html += '<option value="'+value.id+'">'+value.name+'</option>';
            });
            $$('.project_segment').html(html);
            html='';
            html = '<option value="">Choose Sub Segment</option>';
            $$.each(project_sub_segment, function (index, value) {
                html += '<option value="'+value.id+'">'+value.name+'</option>';
            });
            $$('.project_sub_segment').html(html);
            html='';
            html = '<option value="">Choose Phase</option>';
            $$.each(project_status, function (index, value) {
                html += '<option value="'+value.id+'">'+value.name+'</option>';
            });
            $$('.project_status').html(html);
            html='';
            html = '<option value="">Choose Option</option>';
            $$.each(project_competitors, function (index, value) {
                html += '<option value="'+value.id+'">'+value.name+'</option>';
            });
            $$('.competition_lost').html(html);
            html='';
            var location=app_data.user_location;
            var number_of_regions = 0;
            var number_of_areas = 0;
            var number_of_territories = 0;
            var number_of_clusters = 0;
            $$.each(location.region, function (region_id, r_value) {
                ++number_of_regions;
            });
            $$.each(location.area, function (area_id, a_value) {
                $$.each(a_value, function (i, v) {
                    ++number_of_areas;
                });
            });
            $$.each(location.territory, function (territory_id, t_value) {
                $$.each(t_value, function (i, v) {
                    ++number_of_territories;
                });
            });
            var cluster='';
            $$.each(location.cluster, function (cluster_id, c_value) {
                $$.each(c_value, function (i, v) {
                    cluster=v.cluster_id;
                    ++number_of_clusters;
                });
            });
            if(number_of_regions==1)
            {
                $$.each(location.region, function (index, value) {
                    $$('.region_label').html(value.region_code+' - '+value.region_name);
                    $$('#project_region').val(index);
                });
                $$('.region_select').hide();
                $$('.region_label').show();
            }
            else
            {
                var html = '<option value="">Choose Region</option>';
                $$.each(location.region, function (index, value) {
                    html+='<option value="'+value.region_id+'">'+value.region_code+' - '+value.region_name+'</option>';
                });
                $$('.region_select').html(html);
                $$('.region_label').hide();
                $$('.region_select').show();
            }
            if(number_of_areas==1)
            {
                $$.each(location.area, function (area_id, a_value) {
                    $$.each(a_value, function (i, v) {
                        $$('.area_label').html(v.area_code+' - '+v.area_name);
                        $$('#project_area').val(v.area_id);
                    });
                });
                $$('.area_select').hide();
                $$('.area_label').show();
            }
            else
            {
                var html = '<option value="">Choose Area</option>';
                $$.each(location.area, function (area_id, a_value) {
                    $$.each(a_value, function (i, v) {
                        html+='<option value="'+v.area_id+'">'+v.area_code+' - '+v.area_name+'</option>';
                    });
                });
                $$('.area_select').html(html);
                $$('.area_label').hide();
                $$('.area_select').show();
            }
            if(number_of_territories==1)
            {
                $$.each(location.territory, function (t_index, t_value) {
                    $$.each(t_value, function (i, v) {
                        territory_code=v.territory_code;
                        $$('.territory_label').html(v.territory_code+' - '+v.territory_name);
                        $$('#project_territory').val(v.territory_id);
                    });
                });
                $$('.territory_select').hide();
                $$('.territory_label').show();
            }
            else
            {
                var html = '<option value="">Choose Terrritory</option>';
                $$.each(location.territory, function (territory_id, t_value) {
                    $$.each(t_value, function (i, v) {
                        html+='<option value="'+v.territory_id+'">'+v.territory_code+' - '+v.territory_name+'</option>';
                    });
                });
                $$('.territory_select').html(html);
                $$('.territory_label').hide();
                $$('.territory_select').show();
            }
            if(number_of_clusters==1)
            {
                var depo_location=app_data.depo_location;
                var html='<option>Choose Depot</option>';
                if((typeof depo_location.cluster!=="undefined") && (typeof depo_location.cluster[cluster]!=="undefined"))
                {
                    $$.each(depo_location.cluster[cluster], function (index, value) {
                        html+='<option value="'+value.depo_id+'">'+value.depo_code+'</option>';
                    });
                }
                $$('.depo_wise_unique_id').html(html);
                $$('.depo_wise_unique_id').show();
                $$.each(location.cluster, function (cluster_id, c_value) {
                    $$.each(c_value, function (i, v) {
                        cluster_code=v.cluster_code;
                        $$('.cluster_label').html(v.cluster_code+' - '+v.cluster_name);
                        $$('#project_cluster').val(v.cluster_id);
                    });
                });
                $$('#dealer_complete').show();
                $$('#painter_complete').show();
                $$('.cluster_select').hide();
                $$('.cluster_label').show();
            }
            else
            {
                var html = '<option value="">Choose Cluster</option>';
                $$.each(location.cluster, function (cluster_id, c_value) {
                    $$.each(c_value, function (i, v) {
                        html+='<option value="'+v.cluster_id+'">'+v.cluster_code+' - '+v.cluster_name+'</option>';
                    });
                });
                $$('.cluster_select').html(html);
                $$('.cluster_label').hide();
                $$('.cluster_select').show();
            }
            adminView.router.load({
                pageName: class_name+'-page'
            });
            user_nav(class_name);
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
$$('.region_select').on('change', function () {
    var region_id = $$(this).val();
    if(region_id)
    {
        $$('#project_region').val(region_id);
        var html=set_area_select(region_id);
        $$('.area_select').html(html);
        $$('.territory_select').html('<option value="">Choose Territory</option>');
        $$('.cluster_select').html('<option value="">Choose Cluster</option>');
    }
    else
    {
        $$('#project_region').val('');
        $$('.area_select').html('<option value="">Choose Area</option>');
        $$('.territory_select').html('<option value="">Choose Territory</option>');
        $$('.cluster_select').html('<option value="">Choose Cluster</option>');
    }
    $$('#dealer_complete').hide();
    $$('#painter_complete').hide();
    $$('#dealer_complete').val('');
    $$('#painter_complete').val('');
    $$('#project_area').val('');
    $$('#project_territory').val('');
    $$('#project_cluster').val('');
    $$('.dealer_ul').hide();
    $$('.painter_ul').hide();
    $$('#hidden_painter_id').val('');
    $$('#hidden_dealer_id').val('');
    $$('.extra_painter_container').css('display','none');
    $$('.extra_painter_code').html('');
    $$('.extra_dealer_container').css('display','none');
    $$('.extra_dealer_code').html('');
});
$$('.area_select').on('change', function () {
    var area_id = $$(this).val();
    if(area_id)
    {
        $$('#project_area').val(area_id);
        var html = set_territory_select(area_id);
        $$('.territory_select').html(html);
        $$('.cluster_select').html('<option value="">Choose Cluster</option>');
    }
    else
    {
        $$('#project_area').val('');
        $$('.territory_select').html('<option value="">Choose Territory</option>');
        $$('.cluster_select').html('<option value="">Choose Cluster</option>');
    }
    $$('#dealer_complete').hide();
    $$('#painter_complete').hide();
    $$('#dealer_complete').val('');
    $$('#painter_complete').val('');
    $$('#project_territory').val('');
    $$('#project_cluster').val('');
    $$('.dealer_ul').hide();
    $$('.painter_ul').hide();
    $$('#hidden_dealer_id').val('');
    $$('#hidden_painter_id').val('');
    $$('.extra_painter_container').css('display','none');
    $$('.extra_painter_code').html('');
    $$('.extra_dealer_container').css('display','none');
    $$('.extra_dealer_code').html('');
});
$$('.territory_select').on('change', function () {
    var territory_id = $$(this).val();
    if(territory_id)
    {
        $$('#project_territory').val(territory_id);
        var html = set_cluster_select(territory_id);
        $$('.cluster_select').html(html);
    }
    else
    {
        $$('#project_territory').val('');
        $$('.cluster_select').html('<option value="">Choose Cluster</option>');
    }
    $$('.depo_wise_unique_id').hide();
    $$('#painter_complete').hide();
    $$('#painter_complete').val('');
    $$('#dealer_complete').hide();
    $$('#dealer_complete').val('');
    $$('#project_cluster').val('');
    $$('.dealer_ul').hide();
    $$('.painter_ul').hide();
    $$('#hidden_painter_id').val('');
    $$('#hidden_dealer_id').val('');
    $$('.extra_painter_container').css('display','none');
    $$('.extra_painter_code').html('');
    $$('.extra_dealer_container').css('display','none');
    $$('.extra_dealer_code').html('');
});
$$('.cluster_select').on('change', function () {
    var cluster_id = $$(this).val();
    $$('#dealer_complete').val('');
    $$('#painter_complete').val('');
    $$('.extra_painter_container').css('display','none');
    $$('.extra_painter_code').html('');
    $$('.extra_dealer_container').css('display','none');
    $$('.extra_dealer_code').html('');
    if(cluster_id)
    {
        var depo_location=app_data.depo_location;
        var html='<option>Choose Depot</option>';
        $$.each(depo_location.cluster[cluster_id], function (index, value) {
            html+='<option value="'+value.depo_id+'">'+value.depo_code+'</option>';
        });
        $$('.depo_wise_unique_id').html(html);
        $$('#dealer_complete').show();
        $$('#painter_complete').show();
        $$('.depo_wise_unique_id').show();
        $$('#project_cluster').val(cluster_id);
    }
    else
    {
        $$('.depo_wise_unique_id').hide();
        $$('#dealer_complete').hide();
        $$('#painter_complete').hide();
        $$('#project_cluster').val('');
    }
    $$('.dealer_ul').hide();
    $$('.painter_ul').hide();
    $$('#hidden_painter_id').val('');
    $$('#hidden_dealer_id').val('');
});
function set_area_select(region_id)
{
    var location=app_data.user_location;
    var html = '';
    if(typeof region_id=='object')
    {
        $$.each(region_id, function (id, rg) {
            $$.each(location.area[rg], function (id, a_value) {
                html+='<option value="'+a_value.area_id+'">'+a_value.area_code+' - '+a_value.area_name+'</option>';
            });
        });
    }
    else
    {
        html = '<option value="">Choose Territory</option>';
        $$.each(location.territory[region_id], function (id, a_value) {
            html+='<option value="'+a_value.territory_id+'">'+a_value.territory_code+' - '+a_value.territory_name+'</option>';
        });
    }
    return html;
}
function set_territory_select(area_id)
{
    var location=app_data.user_location;
    var html = '';
    if(typeof area_id=='object')
    {
        $$.each(area_id, function (id, ar) {
            $$.each(location.territory[ar], function (id, a_value) {
                html+='<option value="'+a_value.territory_id+'">'+a_value.territory_code+' - '+a_value.territory_name+'</option>';
            });
        });
    }
    else
    {
        html = '<option value="">Choose Territory</option>';
        $$.each(location.territory[area_id], function (id, a_value) {
            html+='<option value="'+a_value.territory_id+'">'+a_value.territory_code+' - '+a_value.territory_name+'</option>';
        });
    }
    return html;
}
function set_cluster_select(territory_id)
{
    var location=app_data.user_location;
    var html = '';
    if(typeof territory_id=='object')
    {
        $$.each(territory_id, function (id, terri) {
            $$.each(location.cluster[terri], function (id, a_value) {
                html+='<option value="'+a_value.cluster_id+'">'+a_value.cluster_code+' - '+a_value.cluster_name+'</option>';
            });
        });
    }
    else
    {
        html = '<option value="">Choose Cluster</option>';
        $$.each(location.cluster[territory_id], function (id, a_value) {
            html+='<option value="'+a_value.cluster_id+'">'+a_value.cluster_code+' - '+a_value.cluster_name+'</option>';
        });
    }
    return html;
}
$$('#next_update').on("click", function (e) {
    $$('.u_hide').hide();
    $$('.update_project_1').show();
    $$('.navbar').hide();
    $$('.update_project_1-nav').show();
});
$$('#next_update_2').on("click", function (e) {
    $$('.u_hide').hide();
    $$('.update_project_2').show();
    $$('.navbar').hide();
    $$('.update_project_2-nav').show();
});
$$('#back_update').on("click", function (e) {
    show_project_details($$(this).attr('data-id'));
});
$$('#back_update_1').on("click", function (e) {
    $$('.u_hide').hide();
    $$('.update_project').show();
    $$('.navbar').hide();
    $$('.update_project-nav').show();
});
$$('#back_update_2').on("click", function (e) {
    $$('.u_hide').hide();
    $$('.update_project_1').show();
    $$('.navbar').hide();
    $$('.update_project_1-nav').show();
});
$$('#consultant_complete_update').on('input', function () {
    if($$(this).val()=='')
    {
        $$('.consultant_ul_update').hide();
        $$('#hidden_update_consultant_id').val('');
    }
    else
    {
        var string = $$(this).val().toLowerCase();
        var html='';
        var consultant_info=app_data.consultant_info;
        $$.each(consultant_info, function (index, value) {
            var str=value.name_number.toLowerCase();
            if(str.includes(string)){
                html+='<li class="consultant_li_update complete_input_li" data-id="'+value.id+'">'+value.name_number+'</li>';
            }
        });
        $$('.consultant_ul_update').html(html);
        $$('.consultant_ul_update').show();
    }
    $$('.consultant_li_update').on('click', function () {
        var li_text = $$(this).text();
        var data_id= $$(this).attr('data-id');
        $$('#consultant_complete_update').val(li_text);
        $$('.consultant_li_update').hide();
        $$('#hidden_update_consultant_id').val(data_id);
    });
});
$$('#contact_person_complete_update').on('input', function () {
    if($$(this).val()=='')
    {
        $$('.contact_person_ul_update').hide();
        $$('#hidden_update_contact_person_id').val('');
    }
    else
    {
        var string = $$(this).val().toLowerCase();
        var html='';
        var contact_person_info=app_data.contact_person_info;
        $$.each(contact_person_info, function (index, value) {
            var str=value.name_number.toLowerCase();
            if(str.includes(string)){
                html+='<li class="contact_person_li_update complete_input_li" data-id="'+value.id+'">'+value.name_number+'</li>';
            }
        });
        $$('.contact_person_ul_update').html(html);
        $$('.contact_person_ul_update').show();
    }
    $$('.contact_person_li_update').on('click', function () {
        var li_text = $$(this).text();
        var data_id= $$(this).attr('data-id');
        $$('#contact_person_complete_update').val(li_text);
        $$('.contact_person_ul_update').hide();
        $$('#hidden_update_contact_person_id').val(data_id);
    });
});
$$('#painter_complete_update').on('input', function () {
    if($$(this).val()=='')
    {
        $$('.extra_painter_update_container').css('display','none');
        $$('.extra_painter_update_code').html('');
        $$('.painter_ul_update').hide();
        $$('#hidden_update_painter_id').val('');
    }
    else
    {
        var cluster_id=$$('#project_cluster_id_update').val();
        var string = $$(this).val().toLowerCase();
        var html='';
        var painter_info=app_data.painter_info;
        $$.each(painter_info[cluster_id], function (index, value) {
            var str=value.name_number.toLowerCase();
            if(str.includes(string)){
                html+='<li class="painter_li_update complete_input_li" data-id="'+value.id+'" data-code="'+value.painter_code+'">'+value.name_number+'</li>';
            }
        });
        $$('.painter_ul_update').html(html);
        $$('.painter_ul_update').show();
    }
    $$('.painter_li_update').on('click', function () {
        var li_text = $$(this).text();
        var data_id= $$(this).attr('data-id');
        $$('#painter_complete_update').val(li_text);
        $$('.painter_ul_update').hide();
        $$('#hidden_update_painter_id').val(data_id);
        $$('.extra_painter_update_container').css('display','flex');
        $$('.extra_painter_update_code').html($$(this).attr('data-code'));
    });
});
$$('#dealer_complete_update').on('input', function () {
    if($$(this).val()=='')
    {
        $$('.extra_dealer_update_container').css('display','none');
        $$('.extra_dealer_update_code').html('');
        $$('.dealer_ul_update').hide();
        $$('#hidden_update_dealer_id').val('');
    }
    else
    {
        var cluster_id=$$('#project_cluster_id_update').val();
        var string = $$(this).val().toLowerCase();
        var html='';
        var dealer_location=app_data.dealer_location;
        $$.each(dealer_location.cluster[cluster_id], function (index, value) {
            var str=value.name_number.toLowerCase();
            if(str.includes(string)){
                html+='<li class="dealer_li_update complete_input_li" data-id="'+value.dealer_id+'" data-code="'+value.dealer_code+'">'+value.name_number+'</li>';
            }
        });
        $$('.dealer_ul_update').html(html);
        $$('.dealer_ul_update').show();
    }
    $$('.dealer_li_update').on('click', function () {
        var li_text = $$(this).text();
        var data_id= $$(this).attr('data-id');
        $$('#dealer_complete_update').val(li_text);
        $$('.dealer_ul_update').hide();
        $$('#hidden_update_dealer_id').val(data_id);
        $$('.extra_dealer_update_container').css('display','flex');
        $$('.extra_dealer_update_code').html($$(this).attr('data-code'));
    });
});
function update_project(project_id)
{
    $$('.extra_painter_update_container').css('display','none');
    $$('.extra_painter_update_code').html('');
    $$('.extra_dealer_update_container').css('display','none');
    $$('.extra_dealer_update_code').html('');
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    $$('#back_update').attr('data-id',project_id);
    var dealer_location=app_data.dealer_location;
    var depo_location=app_data.depo_location;
    var project_status=app_data.project_status;
    var project_sub_segment=app_data.project_sub_segment;
    var project_segment=app_data.project_segment;
    var project_category=app_data.project_category;
    var project_competitors=app_data.project_competitors;
    var painting_type=app_data.painting_type;
    var consultant=app_data.consultant_info;
    var contact_person=app_data.contact_person_info;
    var painter=app_data.painter_info;
    var project_nature=app_data.project_nature;
    var lead_source=app_data.lead_source;
    var user_info = app_data.user_info;
    var user_location = app_data.user_location;
    var products = app_data.products;
    var product_category = app_data.product_category;
    var region=[];
    var area=[];
    var territory=[];
    var cluster=[];
    $$.each(user_location.region, function (region_id, region_values) {
        $$.each(user_location.area[region_id], function (area_id, area_values) {
            $$.each(user_location.territory[area_id], function (territory_id, territory_values) {
                $$.each(user_location.cluster[territory_id], function (cluster_id, cluster_values) {
                    var cluster_id=cluster_id;
                    region[cluster_id]=region_values.region_name;
                    area[cluster_id]=area_values.area_name;
                    territory[cluster_id]=territory_values.territory_name;
                    cluster[cluster_id]=cluster_values.cluster_name;
                });
            });
        });
    });
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    var url=base_url+"app/get_project_details";
    myApp.showIndicator();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],user_id:user_info.user_id,project_id:project_id,new_data:new_data},
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status=='success')
            {
                $$('#painter_complete_update').css("display","flex");
                $$('#dealer_complete_update').css("display","flex");
                $$('#depo_wise_unique_id_update').css("display","flex");
                $$('#proMap_update').css("height","auto");
                $$('#proMap_update').html('<button onclick="getProjectLocationforEdit();" class="btn btn-sm" style="font-size:10px;object-fit: cover;"><i class="material-icons">place</i></button>');
                $$('#project_id_update').val(response.details.id);
                $$('#project_name_update').val(response.details.project_name);
                $$('#project_date_update').val(response.details.date);
                $$('#project_latitude_update').val(response.details.latitude);
                $$('#project_longitude_update').val(response.details.longitude);
                $$('#project_address_update').val(response.details.project_address);
                $$('#region_id_update').html(region[response.details.cluster_id]);
                $$('#area_id_update').html(area[response.details.cluster_id]);
                $$('#territory_id_update').html(territory[response.details.cluster_id]);
                $$('#cluster_id_update').html(cluster[response.details.cluster_id]);
                $$('#project_cluster_id_update').val(response.details.cluster_id);
                $$('#billing_client_name_update').val(response.details.billing_client_name);
                $$('#billing_client_contact_update').val(response.details.billing_client_contact);
                $$('#goc_update').val(response.details.goc);
                $$('#navision_code_update').val(response.details.navision_code);
                $$('#expected_start_date_update').val(response.details.expected_start_date);
                $$('#expected_end_date_update').val(response.details.expected_end_date);
                $$('#competition_lost_update').val(response.details.competition_lost);
                $$('#reason_of_loss_update').val(response.details.reason_of_loss);
                $$('#value_potential_lost_update').val(response.details.value_potential_lost);
                $$('#interior_paintable_area_update').val(addCommas(response.details.interior_paintable_area));
                $$('#exterior_paintable_area_update').val(addCommas(response.details.exterior_paintable_area));
                $$('#total_site_potentials_update').val(addCommas(response.details.total_site_potentials));
                $$('#total_potential_value_update').val(addCommas(response.details.total_potential_value));
                $$('#ap_potential_value_update').val(addCommas(response.details.ap_potential_value));
                $$('#remarks_update').val(response.details.remarks);
                if(response.details.conversion)
                {
                    $$('.conversion_status_update').val(response.details.conversion);
                }
                else
                {
                    $$('.conversion_status_update').val('');
                }
                var interior_opt = '<option value="">Choose Product</option>';
                var exterior_opt = '<option value="">Choose Product</option>';
                var water_proofing_opt = '<option value="">Choose Product</option>';
                var others_opt = '<option value="">Choose Product</option>';
                $$.each(products, function (p_i, p_v) {
                    $$.each(product_category, function (pc_i, pc_v) {
                        if(p_v.category_id==pc_v.id && pc_v.category_code=='IN')
                        {
                            if(response.details.in==p_v.id)
                            {
                                interior_opt += '<option value="'+p_v.id+'" selected="selected">'+p_v.product_name+'</option>';
                            }
                            else
                            {
                                interior_opt += '<option value="'+p_v.id+'">'+p_v.product_name+'</option>';
                            }
                        }
                        if(p_v.category_id==pc_v.id && pc_v.category_code=='EX')
                        {
                            if(response.details.ex==p_v.id)
                            {
                                exterior_opt += '<option value="'+p_v.id+'" selected="selected">'+p_v.product_name+'</option>';
                            }
                            else
                            {
                                exterior_opt += '<option value="'+p_v.id+'">'+p_v.product_name+'</option>';
                            }
                        }
                        if(p_v.category_id==pc_v.id && pc_v.category_code=='WP')
                        {
                            if(response.details.wp==p_v.id)
                            {
                                water_proofing_opt += '<option value="'+p_v.id+'" selected="selected">'+p_v.product_name+'</option>';
                            }
                            else
                            {
                                water_proofing_opt += '<option value="'+p_v.id+'">'+p_v.product_name+'</option>';
                            }
                        }
                        if(p_v.category_id==pc_v.id && pc_v.category_code=='OT')
                        {
                            if(response.details.ot==p_v.id)
                            {
                                others_opt += '<option value="'+p_v.id+'" selected="selected">'+p_v.product_name+'</option>';
                            }
                            else
                            {
                                others_opt += '<option value="'+p_v.id+'">'+p_v.product_name+'</option>';
                            }
                        }
                    });
                });
                $$('.interior_opt_update').html(interior_opt);
                $$('.exterior_opt_update').html(exterior_opt);
                $$('.water_proofing_opt_update').html(water_proofing_opt);
                $$('.others_opt_update').html(others_opt);
                var html = '<option value="">Choose Lead Source</option>';
                $$.each(lead_source, function (index, value) {
                    if(response.details.lead_source==value.id)
                    {
                        html += '<option value="'+value.id+'" selected="selected">'+value.name+'</option>';
                    }
                    else
                    {
                        html += '<option value="'+value.id+'">'+value.name+'</option>';
                    }
                });
                $$('#lead_source_update').html(html);
                html = '<option value="">Choose Option</option>';
                $$.each(project_competitors, function (index, value) {
                    if(response.details.competition_lost==value.id)
                    {
                        html += '<option value="'+value.id+'" selected="selected">'+value.name+'</option>';
                    }
                    else
                    {
                        html += '<option value="'+value.id+'">'+value.name+'</option>';
                    }
                });
                $$('.competition_lost_update').html(html);
                html = '<option value="">Choose Nature</option>';
                $$.each(project_nature, function (index, value) {
                    if(response.details.project_nature_id==value.id)
                    {
                        html += '<option value="'+value.id+'" selected="selected">'+value.name+'</option>';
                    }
                    else
                    {
                        html += '<option value="'+value.id+'">'+value.name+'</option>';
                    }
                });
                $$('#project_nature_id_update').html(html);
                html = '<option value="">Choose Type</option>';
                $$.each(painting_type, function (index, value) {
                    if(response.details.painting_type_id==value.id)
                    {
                        html += '<option value="'+value.id+'" selected="selected">'+value.name+'</option>';
                    }
                    else
                    {
                        html += '<option value="'+value.id+'">'+value.name+'</option>';
                    }
                });
                $$('#painting_type_id_update').html(html);
                html = '<option value="">Choose Category</option>';
                $$.each(project_category, function (index, value) {
                    if(response.details.project_category_id==value.id)
                    {
                        html += '<option value="'+value.id+'" selected="selected">'+value.name+'</option>';
                    }
                    else
                    {
                        html += '<option value="'+value.id+'">'+value.name+'</option>';
                    }
                });
                $$('#project_category_id_update').html(html);
                html = '<option value="">Choose Segment</option>';
                $$.each(project_segment, function (index, value) {
                    if(response.details.project_segment_id==value.id)
                    {
                        html += '<option value="'+value.id+'" selected="selected">'+value.name+'</option>';
                    }
                    else
                    {
                        html += '<option value="'+value.id+'">'+value.name+'</option>';
                    }
                });
                $$('#project_segment_id_update').html(html);
                html = '<option value="">Choose Sub Segment</option>';
                $$.each(project_sub_segment, function (index, value) {
                    if(response.details.project_sub_segment_id==value.id)
                    {
                        html += '<option value="'+value.id+'" selected="selected">'+value.name+'</option>';
                    }
                    else
                    {
                        html += '<option value="'+value.id+'">'+value.name+'</option>';
                    }
                });
                $$('#project_sub_segment_id_update').html(html);
                html = '<option value="">Choose Phase</option>';
                $$.each(project_status, function (index, value) {
                    if(response.details.project_status_id==value.id)
                    {
                        html += '<option value="'+value.id+'" selected="selected">'+value.name+'</option>';
                    }
                    else
                    {
                        html += '<option value="'+value.id+'">'+value.name+'</option>';
                    }
                });
                $$('#project_status_id_update').html(html);
                $$.each(dealer_location.cluster[response.details.cluster_id], function (index, value) {
                    if(value.dealer_id==response.details.dealer_id)
                    {
                        $$('#dealer_complete_update').val(value.name_number);
                        $$('.extra_dealer_update_container').css('display','flex');
                        $$('.extra_dealer_update_code').html(value.dealer_code);
                    }
                });
                html = '<option value="">Choose Depot</option>';
                $$.each(depo_location.cluster[response.details.cluster_id], function (index, value) {
                    if(response.details.depo_wise_unique_id==value.depo_id)
                    {
                        html += '<option value="'+value.depo_id+'" selected="selected">'+value.depo_code+'</option>';
                    }
                    else
                    {
                        html += '<option value="'+value.depo_id+'">'+value.depo_code+'</option>';
                    }
                });
                $$('#depo_wise_unique_id_update').html(html);
                $$('#hidden_update_painter_id').val(response.details.painter_id);
                $$('#hidden_update_dealer_id').val(response.details.dealer_id);
                $$('#hidden_update_consultant_id').val(response.details.consultant_id);
                $$('#hidden_update_contact_person_id').val(response.details.contact_person_id);
                $$.each(contact_person, function (index, value) {
                    if(value.id==response.details.contact_person_id)
                    {
                        $$('#contact_person_complete_update').val(value.name_number);
                    }
                });
                $$.each(consultant, function (index, value) {
                    if(value.id==response.details.consultant_id)
                    {
                        $$('#consultant_complete_update').val(value.name_number);
                    }
                });
                $$.each(painter[response.details.cluster_id], function (index, value) {
                    if(response.details.painter_id==value.id)
                    {
                        $$('#painter_complete_update').val(value.name_number);
                        $$('.extra_painter_update_container').css('display','flex');
                        $$('.extra_painter_update_code').html(value.painter_code);
                    }
                });
                adminView.router.load({
                    pageName: 'update_project-page'
                });
                user_nav('update_project');
            }
            else if(response.status=='unauthorized')
            {
                alert('System Found Unauthorized Action!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Failed to retrieve data!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
$$('#consultant_complete').on('input', function () {
    if($$(this).val()=='')
    {
        $$('.consultant_ul').hide();
        $$('#hidden_consultant_id').val('');
    }
    else
    {
        var string = $$(this).val().toLowerCase();
        var html='';
        var consultant_info=app_data.consultant_info;
        $$.each(consultant_info, function (index, value) {
            var str=value.name_number.toLowerCase();
            if(str.includes(string)){
                html+='<li class="consultant_li complete_input_li" data-id="'+value.id+'">'+value.name_number+'</li>';
            }
        });
        $$('.consultant_ul').html(html);
        $$('.consultant_ul').show();
    }
    $$('.consultant_li').on('click', function () {
        var li_text = $$(this).text();
        var data_id= $$(this).attr('data-id');
        $$('#consultant_complete').val(li_text);
        $$('.consultant_ul').hide();
        $$('#hidden_consultant_id').val(data_id);
    });
});
$$('#contact_person_complete').on('input', function () {
    if($$(this).val()=='')
    {
        $$('.contact_person_ul').hide();
        $$('#hidden_contact_person_id').val('');
    }
    else
    {
        var string = $$(this).val().toLowerCase();
        var html='';
        var contact_person_info=app_data.contact_person_info;
        $$.each(contact_person_info, function (index, value) {
            var str=value.name_number.toLowerCase();
            if(str.includes(string)){
                html+='<li class="contact_person_li complete_input_li" data-id="'+value.id+'">'+value.name_number+'</li>';
            }
        });
        $$('.contact_person_ul').html(html);
        $$('.contact_person_ul').show();
    }
    $$('.contact_person_li').on('click', function () {
        var li_text = $$(this).text();
        var data_id= $$(this).attr('data-id');
        $$('#contact_person_complete').val(li_text);
        $$('.contact_person_ul').hide();
        $$('#hidden_contact_person_id').val(data_id);
    });
});
$$('#painter_complete').on('input', function () {
    if($$(this).val()=='')
    {
        $$('.extra_painter_code').html('');
        $$('.extra_painter_container').css('display','none');
        $$('.painter_ul').hide();
        $$('#hidden_painter_id').val('');
    }
    else
    {
        var cluster_id=$$('#project_cluster').val();
        var string = $$(this).val().toLowerCase();
        var html='';
        var painter_info=app_data.painter_info;
        $$.each(painter_info[cluster_id], function (index, value) {
            var str=value.name_number.toLowerCase();
            if(str.includes(string)){
                html+='<li class="painter_li complete_input_li" data-id="'+value.id+'" data-code="'+value.painter_code+'">'+value.name_number+'</li>';
            }
        });
        $$('.painter_ul').html(html);
        $$('.painter_ul').show();
    }
    $$('.painter_li').on('click', function () {
        var li_text = $$(this).text();
        var data_id= $$(this).attr('data-id');
        $$('.extra_painter_code').html($$(this).attr('data-code'));
        $$('.extra_painter_container').css('display','flex');
        $$('#painter_complete').val(li_text);
        $$('.painter_ul').hide();
        $$('#hidden_painter_id').val(data_id);
    });
});
$$('#dealer_complete').on('input', function () {
    if($$(this).val()=='')
    {
        $$('.extra_dealer_container').css('display','none');
        $$('.extra_dealer_code').html('');
        $$('.dealer_ul').hide();
        $$('#hidden_dealer_id').val('');
    }
    else
    {
        var cluster_id=$$('#project_cluster').val();
        var string = $$(this).val().toLowerCase();
        var html='';
        var dealer_location=app_data.dealer_location;
        $$.each(dealer_location.cluster[cluster_id], function (index, value) {
            var str=value.name_number.toLowerCase();
            if(str.includes(string)){
                html+='<li class="dealer_li complete_input_li" data-id="'+value.dealer_id+'" data-code="'+value.dealer_code+'">'+value.name_number+'</li>';
            }
        });
        $$('.dealer_ul').html(html);
        $$('.dealer_ul').show();
    }
    $$('.dealer_li').on('click', function () {
        var li_text = $$(this).text();
        var data_id= $$(this).attr('data-id');
        $$('.extra_dealer_code').html($$(this).attr('data-code'));
        $$('.extra_dealer_container').css('display','flex');
        $$('#dealer_complete').val(li_text);
        $$('.dealer_ul').hide();
        $$('#hidden_dealer_id').val(data_id);
    });
});

$$('.project_pagination_link').on('click', function () {
    var data_id=$$(this).attr('data-id');
    var present_id='';
    var new_id='';
    var total_page_id=4;
    $$( ".project_pagination_link" ).each(function( index ) {
        if($$(this).hasClass('selected_pagination'))
        {
            present_id = Number($$(this).attr('data-id'));
        }
        $$(this).removeAttr('class','selected_pagination');
        $$(this).attr('class','page-link project_pagination_link regular_pagination');
    });
    if(isNaN(Number(data_id)))
    {
        if(data_id=='p')
        {
            if(present_id>1)
            {
                new_id=present_id-1;
                $$('#project_pagination_link_'+new_id).attr('class','page-link project_pagination_link selected_pagination')
            }
            else
            {
                $$('#project_pagination_link_'+present_id).attr('class','page-link project_pagination_link selected_pagination');
            }
        }
        else
        {
            if(total_page_id==present_id)
            {
                $$('#project_pagination_link_'+present_id).attr('class','page-link project_pagination_link selected_pagination');
            }
            else
            {
                new_id=present_id+1;
                $$('#project_pagination_link_'+new_id).attr('class','page-link project_pagination_link selected_pagination')
            }
        }
    }
    else
    {
        $$('#project_pagination_link_'+data_id).attr('class','page-link project_pagination_link selected_pagination');
    }
});
$$('.consultant_pagination_link').on('click', function () {
    var data_id=$$(this).attr('data-id');
    var present_id='';
    var new_id='';
    var total_page_id=4;
    $$( ".consultant_pagination_link" ).each(function( index ) {
        if($$(this).hasClass('selected_pagination'))
        {
            present_id = Number($$(this).attr('data-id'));
        }
        $$(this).removeAttr('class','selected_pagination');
        $$(this).attr('class','page-link consultant_pagination_link regular_pagination');
    });
    if(isNaN(Number(data_id)))
    {
        if(data_id=='p')
        {
            if(present_id>1)
            {
                new_id=present_id-1;
                $$('#consultant_pagination_link_'+new_id).attr('class','page-link consultant_pagination_link selected_pagination')
            }
            else
            {
                $$('#consultant_pagination_link_'+present_id).attr('class','page-link consultant_pagination_link selected_pagination');
            }
        }
        else
        {
            if(total_page_id==present_id)
            {
                $$('#consultant_pagination_link_'+present_id).attr('class','page-link consultant_pagination_link selected_pagination');
            }
            else
            {
                new_id=present_id+1;
                $$('#consultant_pagination_link_'+new_id).attr('class','page-link consultant_pagination_link selected_pagination')
            }
        }
    }
    else
    {
        $$('#consultant_pagination_link_'+data_id).attr('class','page-link consultant_pagination_link selected_pagination');
    }
});
$$('.painter_pagination_link').on('click', function () {
    var data_id=$$(this).attr('data-id');
    var present_id='';
    var new_id='';
    var total_page_id=4;
    $$( ".painter_pagination_link" ).each(function( index ) {
        if($$(this).hasClass('selected_pagination'))
        {
            present_id = Number($$(this).attr('data-id'));
        }
        $$(this).removeAttr('class','selected_pagination');
        $$(this).attr('class','page-link painter_pagination_link regular_pagination');
    });
    if(isNaN(Number(data_id)))
    {
        if(data_id=='p')
        {
            if(present_id>1)
            {
                new_id=present_id-1;
                $$('#painter_pagination_link_'+new_id).attr('class','page-link painter_pagination_link selected_pagination')
            }
            else
            {
                $$('#painter_pagination_link_'+present_id).attr('class','page-link painter_pagination_link selected_pagination');
            }
        }
        else
        {
            if(total_page_id==present_id)
            {
                $$('#painter_pagination_link_'+present_id).attr('class','page-link painter_pagination_link selected_pagination');
            }
            else
            {
                new_id=present_id+1;
                $$('#painter_pagination_link_'+new_id).attr('class','page-link painter_pagination_link selected_pagination')
            }
        }
    }
    else
    {
        $$('#painter_pagination_link_'+data_id).attr('class','page-link painter_pagination_link selected_pagination');
    }
});
$$('.contact_person_link').on('click', function () {
    var data_id=$$(this).attr('data-id');
    var present_id='';
    var new_id='';
    var total_page_id=4;
    $$( ".contact_person_link" ).each(function( index ) {
        if($$(this).hasClass('selected_pagination'))
        {
            present_id = Number($$(this).attr('data-id'));
        }
        $$(this).removeAttr('class','selected_pagination');
        $$(this).attr('class','page-link contact_person_link regular_pagination');
    });
    if(isNaN(Number(data_id)))
    {
        if(data_id=='p')
        {
            if(present_id>1)
            {
                new_id=present_id-1;
                $$('#contact_person_link_'+new_id).attr('class','page-link contact_person_link selected_pagination')
            }
            else
            {
                $$('#contact_person_link_'+present_id).attr('class','page-link contact_person_link selected_pagination');
            }
        }
        else
        {
            if(total_page_id==present_id)
            {
                $$('#contact_person_link_'+present_id).attr('class','page-link contact_person_link selected_pagination');
            }
            else
            {
                new_id=present_id+1;
                $$('#contact_person_link_'+new_id).attr('class','page-link contact_person_link selected_pagination')
            }
        }
    }
    else
    {
        $$('#contact_person_link_'+data_id).attr('class','page-link contact_person_link selected_pagination');
    }
});
$$('#project_details_back_button').on('click',function () {
    adminView.router.load({
        pageName: 'project_list-page'
    });
    user_nav('project_list');
});
$$('#delete_project').on('click',function () {
    if(confirm('Are you sure to remove this project?'))
    {
        alert('Project Deleted successfully!');
    }
});
$$('#create_consultant').on('click',function () {
    if(check_action_status())
    {
        $$('.u_hide').hide();
        $$('.create_consultant').show();
        $$('.navbar').hide();
        $$('.create_consultant-nav').show();
    }
});
$$('#create_project_button').on('click',function () {
    if(check_action_status())
    {
        create_project('create_project');
    }
});

$$('.consultant_back_button').on('click',function () {
    consultant_list('consultant');
});
$$('.painter_back_button').on('click',function () {
    painter_list('painter_list');
});
$$('.contact_person_back_button').on('click',function () {
    contact_person_list('contact_person');
});
$$('#create_contact_person').on('click',function () {
    if(check_action_status())
    {
        $$('.u_hide').hide();
        $$('.create_contact_person').show();
        $$('.navbar').hide();
        $$('.create_contact_person-nav').show();
    }
});
$$('#create_painter_button').on('click',function () {
    if(check_action_status())
    {
        create_painter_function('create_painter');
    }
});
$$('#submit_project').on('click',function () {
    if($$('.project_create_date').val()=='')
    {
        call_error_function('Please fill create date field');
    }
    else if($$('#project_region').val()=='')
    {
        call_error_function('Please fill region field');
    }
    else if($$('#project_area').val()=='')
    {
        call_error_function('Please fill area field');
    }
    else if($$('#project_territory').val()=='')
    {
        call_error_function('Please fill territory field');
    }
    else if($$('#project_cluster').val()=='')
    {
        call_error_function('Please fill cluster field');
    }
    else if($$('.depo_wise_unique_id').val()=='')
    {
        call_error_function('Please fill depot field');
    }
    else if($$('#project_name').val()=='')
    {
        call_error_function('Please fill project name field');
    }
    else if($$('#project_address_create').val()=='')
    {
        call_error_function('Please fill project address field');
    }
    else if($$('.lead_source').val()=='')
    {
        call_error_function('Please fill lead source field');
    }
    else if($$('#billing_client_name').val()=='')
    {
        call_error_function('Please fill client name field');
    }
    else if($$('#billing_client_contact').val()=='')
    {
        call_error_function('Please fill client contact field');
    }
    else if($$('#hidden_contact_person_id').val()=='')
    {
        call_error_function('Please fill contact person field');
    }
    else if($$('#hidden_painter_id').val()=='')
    {
        call_error_function('Please fill painter field');
    }
    else if($$('#hidden_dealer_id').val()=='')
    {
        call_error_function('Please fill dealer field');
    }
    else if($$('.project_nature').val()=='')
    {
        call_error_function('Please fill project nature field');
    }
    else if($$('.painting_type').val()=='')
    {
        call_error_function('Please fill painting type field');
    }
    else if($$('.project_category').val()=='')
    {
        call_error_function('Please fill project category field');
    }
    else if($$('.project_segment').val()=='')
    {
        call_error_function('Please fill project segment field');
    }
    else if($$('#interior_paintable_area').val()=='')
    {
        call_error_function('Please fill interior paintable area field');
    }
    else if($$('#exterior_paintable_area').val()=='')
    {
        call_error_function('Please fill exterior paintable area field');
    }
    else if($$('#total_potential_value').val()=='')
    {
        call_error_function('Please fill total potential value field');
    }
    else if($$('#ap_potential_value').val()=='')
    {
        call_error_function('Please fill ap potential value field');
    }
    else if($$('#project_status_id').val()=='')
    {
        call_error_function('Please fill current phase field');
    }
    else if($$('#expected_start_date').val()=='')
    {
        call_error_function('Please fill expected start date field');
    }
    else if($$('#expected_end_date').val()=='')
    {
        call_error_function('Please fill expected end date field');
    }
    else
    {
        var count_potential_products=0;
        $$(".potential_products").each(function(index,value)
        {
            if($$(this).val()!='')
            {
                count_potential_products++;
            }
        });
        if(!count_potential_products)
        {
            call_error_function('Please fill at least one product');
            return;
        }
        var project_date=Number($$('.project_create_date').val().replace(/-/g, ""));
        var expected_start_date=Number($$('#expected_start_date').val().replace(/-/g, ""));
        if(project_date>expected_start_date)
        {
            call_error_function('Expected date must be greater than project date!');
            return;
        }
        var expected_end_date=Number($$('#expected_end_date').val().replace(/-/g, ""));
        if(expected_start_date>expected_end_date)
        {
            call_error_function('Expected end date must be greater than start date!');
            return;
        }
        var contact=$$('#billing_client_contact').val();
        if(check_contact_number(contact))
        {
            var form_name_fields=[];
            var form_value_fields=[];
            var image_order_fields=[];
            var image_value_fields=[];
            $$(".project_create_form_fields").each(function(index,value)
            {
                form_name_fields.push($$(this).attr('name'));
                form_value_fields.push($$(this).val());
            });
            $$(".project_capture_image_names").each(function(index,value)
            {
                image_order_fields.push($$(this).attr('data-id'));
                image_value_fields.push($$(this).val());
            });
            if(image_value_fields.length)
            {
                save_project_info(form_name_fields,form_value_fields,image_order_fields,image_value_fields);
            }
            else
            {
                call_error_function('Project image missing!');
            }
        }
        else
        {
            call_error_function('Incorrect client contact number format');
        }
    }
});
$$('#update_project').on('click',function () {
    if($$('#project_id_update').val()=='')
    {
        call_error_function('Please fill create date field');
    }
    else if($$('#depo_wise_unique_id_update').val()=='')
    {
        call_error_function('Please fill depot field');
    }
    else if($$('#project_name_update').val()=='')
    {
        call_error_function('Please fill project name field');
    }
    else if($$('#project_address_update').val()=='')
    {
        call_error_function('Please fill project address field');
    }
    else if($$('#lead_source_update').val()=='')
    {
        call_error_function('Please fill lead source field');
    }
    else if($$('#billing_client_name_update').val()=='')
    {
        call_error_function('Please fill client name field');
    }
    else if($$('#billing_client_contact_update').val()=='')
    {
        call_error_function('Please fill client contact field');
    }
    else if($$('#project_date_update').val()=='')
    {
        call_error_function('Please fill project date field');
    }
    else if($$('#hidden_update_contact_person_id').val()=='')
    {
        call_error_function('Please fill contact person field');
    }
    else if($$('#hidden_update_painter_id').val()=='')
    {
        call_error_function('Please fill painter field');
    }
    else if($$('#hidden_update_dealer_id').val()=='')
    {
        call_error_function('Please fill dealer field');
    }
    else if($$('#project_nature_id_update').val()=='')
    {
        call_error_function('Please fill project nature field');
    }
    else if($$('#painting_type_id_update').val()=='')
    {
        call_error_function('Please fill painting type field');
    }
    else if($$('#project_category_id_update').val()=='')
    {
        call_error_function('Please fill project category field');
    }
    else if($$('#project_segment_id_update').val()=='')
    {
        call_error_function('Please fill project segment field');
    }
    else if($$('#interior_paintable_area_update').val()=='')
    {
        call_error_function('Please fill interior paintable area field');
    }
    else if($$('#exterior_paintable_area_update').val()=='')
    {
        call_error_function('Please fill exterior paintable area field');
    }
    else if($$('#total_potential_value_update').val()=='')
    {
        call_error_function('Please fill total potential value field');
    }
    else if($$('#ap_potential_value_update').val()=='')
    {
        call_error_function('Please fill ap potential value field');
    }
    else if($$('#project_status_id_update').val()=='')
    {
        call_error_function('Please fill current phase field');
    }
    else if($$('#expected_start_date_update').val()=='')
    {
        call_error_function('Please fill expected start date field');
    }
    else if($$('#expected_end_date_update').val()=='')
    {
        call_error_function('Please fill expected end date field');
    }
    else
    {
        var count_potential_products=0;
        $$(".potential_products_update").each(function(index,value)
        {
            if($$(this).val()!='')
            {
                count_potential_products++;
            }
        });
        if(!count_potential_products)
        {
            call_error_function('Please fill at least one product');
            return;
        }
        var project_date=Number($$('#project_date_update').val().replace(/-/g, ""));
        var expected_start_date=Number($$('#expected_start_date_update').val().replace(/-/g, ""));
        if(project_date>expected_start_date)
        {
            call_error_function('Expected date must be greater than project date!');
            return;
        }
        var expected_end_date=Number($$('#expected_end_date_update').val().replace(/-/g, ""));
        if(expected_start_date>expected_end_date)
        {
            call_error_function('Expected end date must be greater than start date!');
            return;
        }
        var contact=$$('#billing_client_contact_update').val();
        if(check_contact_number(contact))
        {
            var form_name_fields=[];
            var form_value_fields=[];
            $$(".project_update_form_fields").each(function(index,value)
            {
                form_name_fields.push($$(this).attr('name'));
                form_value_fields.push($$(this).val());
            });
            update_project_info(form_name_fields,form_value_fields);
        }
        else
        {
            call_error_function('Incorrect client contact number format');
        }
    }
});
function call_error_function(msg) {
    alert(msg);
}

function save_project_info(names,values,image_order_fields,image_value_fields) {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    $$('#submit_project').attr('disabled','disabled');
    myApp.showIndicator();
    var url=base_url+"app/save_project_info";
    var user_info = app_data.user_info;
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],user_id:user_info.user_id,names:names,values:values,image_order_fields:image_order_fields,image_value_fields:image_value_fields,new_data:new_data},
        //timeout: 15000,
        cache: false,
        success: function(data){
            $$('#submit_project').removeAttr('disabled');
            var response= JSON.parse(data);
            myApp.hideIndicator();
            if(response.status=='success')
            {
                window.localStorage["new_project_number_today"]=Number(window.localStorage["new_project_number_today"])+1;
                showAlert('Data saved successfully!','Success','Done');
                empty_project_create_fields();
                project_list('project_list');
            }
            else if(response.status=='unauthorized')
            {
                alert('System Found Unauthorized Action!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Failed to save data!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            $$('#submit_project').removeAttr('disabled');
            alert('There was a problem connecting to the server.Please try again.');
        },
        complete: function(data) {
            myApp.hideIndicator();
            if(!upload_image_function_status)
            {
                uploadImageToServer();
            }
        }
    });
}
function update_project_info(names,values) {
    var project_id=$$('#project_id_update').val();
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    $$('#update_project').attr('disabled','disabled');
    myApp.showIndicator();
    var url=base_url+"app/update_project_info";
    var user_info = app_data.user_info;
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],user_id:user_info.user_id,names:names,values:values,project_id:project_id,new_data:new_data},
        //timeout: 15000,
        cache: false,
        success: function(data){
            $$('#update_project').removeAttr('disabled');
            var response= JSON.parse(data);
            myApp.hideIndicator();
            if(response.status=='success')
            {
                showAlert('Data updated successfully!','Success','Done');
                empty_project_create_fields();
                project_list('project_list');
            }
            else if(response.status=='unauthorized')
            {
                alert('System Found Unauthorized Action!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Failed to save data!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            $$('#update_project').removeAttr('disabled');
            alert('There was a problem connecting to the server.Please try again.');
        },
        complete: function(data) {
            myApp.hideIndicator();
            if(!upload_image_function_status)
            {
                uploadImageToServer();
            }
        }
    });
}
function empty_project_create_fields() {
    $$(".do_empty").each(function(index,value)
    {
        $$(this).val('');
    });
}
$$('.check_in_for_attendance').on('click', function () {
    getlocation('checkin');
});
function home_action(class_name) {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    $$('#project_dash_div').hide();
    $$('#order_approve_dash_div').hide();
    $$('#painter_dash_div').hide();
    $$('#ratification_dash_div').hide();
    $$('#appoint_project_dash_div').hide();
    $$('#appoint_painter_dash_div').hide();
    $$('#sales_dash_div').hide();
    $$('#target_dash_div').hide();
    if(window.localStorage["attendance_configure_status"]==1)
    {
        $$('#attendance_time_show_div').show();
        if((typeof window.localStorage["check_in_time"] !== 'undefined') && window.localStorage["check_in_time"]!='')
        {
            $$('#check_in_time').html(window.localStorage["check_in_time"]);
        }
        if((typeof window.localStorage["check_out_time"] !== 'undefined') && window.localStorage["check_out_time"]!='')
        {
            $$('#check_out_time').html(window.localStorage["check_out_time"]);
        }
    }
    else
    {
        $$('#attendance_time_show_div').hide();
    }
    var user_info = app_data.user_info;
    var user_location = app_data.user_location;
    if(user_info.user_level=='APEC')
    {
        myApp.showIndicator();
        var url=base_url+"app/get_home_page_sales_info";
        $$.ajax({
            url: url,
            type: "POST",
            datatype:'json',
            data: {user_id:user_info.user_id},
            //timeout: 15000,
            cache: false,
            success: function(data){
                myApp.hideIndicator();
                var response= JSON.parse(data);
                $$('#new_project_number_today').html(window.localStorage["new_project_number_today"]);
                $$('#new_painter_number_today').html(window.localStorage["new_painter_number_today"]);
                $$('#new_followup_project_all_number_today').html(window.localStorage["new_followup_project_all_number_today"]);
                $$('#new_followup_project_com_number_today').html(window.localStorage["new_followup_project_com_number_today"]);
                $$('#new_followup_painter_all_number_today').html(window.localStorage["new_followup_painter_all_number_today"]);
                $$('#new_followup_painter_com_number_today').html(window.localStorage["new_followup_painter_com_number_today"]);
                $$('#total_sales_today').html(response.total_sales);
                $$('#total_target_today').html(response.total_target);
                $$('#project_dash_div').show();
                $$('#painter_dash_div').show();
                $$('#appoint_project_dash_div').show();
                $$('#appoint_painter_dash_div').show();
                $$('#sales_dash_div').show();
                $$('#target_dash_div').show();
                adminView.router.load({
                    pageName: class_name+'-page'
                });
                user_nav(class_name);
            },
            error: function (e) {
                myApp.hideIndicator();
                alert('There was a problem connecting to the server.Please try again.');
            }
        });
    }
    else
    {
        myApp.showIndicator();
        var url=base_url+"app/get_home_page_info";
        $$.ajax({
            url: url,
            type: "POST",
            datatype:'json',
            data: {user_id:user_info.user_id,user_level_id:user_info.user_level_id,user_level:user_info.user_level,cluster:user_location.cluster},
            //timeout: 15000,
            cache: false,
            success: function(data){
                myApp.hideIndicator();
                var response= JSON.parse(data);
                $$('#new_followup_project_all_number_today').html(response.new_follow_project_active);
                $$('#new_followup_project_com_number_today').html(response.new_follow_project_complete);
                $$('#new_followup_painter_all_number_today').html(response.new_follow_painter_active);
                $$('#new_followup_painter_com_number_today').html(response.new_follow_painter_complete);
                if(response.user_level=='TSI')
                {
                    $$('#approve_order_number_today').html(response.remaining_order);
                    $$('#order_approve_dash_div').show();
                }
                else
                {
                    $$('#new_project_number_today').html(response.number_project);
                    $$('#project_dash_div').show();
                }
                $$('#ratification_number').html(response.remaining_ratification_number);
                $$('#total_sales_today').html(response.total_sales);
                $$('#total_target_today').html(response.total_target);
                $$('#ratification_dash_div').show();
                $$('#appoint_project_dash_div').show();
                $$('#appoint_painter_dash_div').show();
                $$('#sales_dash_div').show();
                $$('#target_dash_div').show();
                adminView.router.load({
                    pageName: class_name+'-page'
                });
                user_nav(class_name);
            },
            error: function (e) {
                myApp.hideIndicator();
                alert('There was a problem connecting to the server.Please try again.');
            }
        });
    }
}
function attendance_action(class_name) {
    if((typeof window.localStorage["check_in_time"] !== 'undefined') && window.localStorage["check_in_time"]!='')
    {
        var adrs = ((typeof window.localStorage["check_in_addr"] !== 'undefined') && window.localStorage["check_in_addr"]!='')?window.localStorage["check_in_addr"]:'Dhaka, Bangladesh.';
        initMap(parseFloat(window.localStorage["check_in_lat"]),parseFloat(window.localStorage["check_in_long"]),adrs,'check_in_map','#check-in-addr');
    }
    else
    {
        $$('#check_in_map').html('<img style="border-radius:10px;width: 100%;" src="img/ck_in.jpg" />');
    }
    if((typeof window.localStorage["check_out_time"] !== 'undefined') && window.localStorage["check_out_time"]!='')
    {
        var adrs = ((typeof window.localStorage["check_out_addr"] !== 'undefined') && window.localStorage["check_out_addr"]!='')?window.localStorage["check_out_addr"]:'Dhaka, Bangladesh.';
        initMap(parseFloat(window.localStorage["check_out_lat"]),parseFloat(window.localStorage["check_out_long"]),adrs,'check_out_map','#check-out-addr');
    }
    else
    {
        $$('#check_out_map').html('<img style="border-radius:10px;width: 100%;" src="img/ck_out.jpg" />');
    }
    adminView.router.load({
        pageName: class_name+'-page'
    });
    user_nav(class_name);
}
$$('.check_out_for_attendance').on('click', function () {
    navigator.notification.confirm("Are you sure you want to checkout ?", onCheckOut, "Confirmation", "Yes,No");
});
function onCheckOut(button) {
    if(button==1){//If User selected No, then we just do nothing
        if(typeof window.localStorage["check_in_time"]==='undefined' || window.localStorage["check_in_time"]=='')
        {
            alert('Check In-Time not found!');
            return;
        }
        getlocation('checkout');
    }else{
        return;
    }
}
$$(document).on("input", ".class_float", function(event)
{
    this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');
});
$$(document).on("input", ".class_integer", function(event)
{
    this.value = this.value.replace(/[^0-9]/g, '');
});
$$(document).on("input", ".float_type_all", function(event)
{
    this.value = this.value.replace(/[^0-9.-]/g, '').replace(/(\..*)\./g, '$1').replace(/(?!^)-/g, '');
});
$$(document).on("input", ".integer_type_all", function(event)
{
    this.value = this.value.replace(/[^0-9-]/g, '').replace(/(?!^)-/g, '');
});
$('.add_comma_class').keyup(function(event) {
    $(this).val(function(index, value) {
        return value
            .replace(/\D/g, "")
            .replace(/\B(?=(\d{3})+(?!\d))/g, ",")
            ;
    });
});
$$('#interior_paintable_area').on('input',function () {
    var interior_paintable_area=0;
    var exterior_paintable_area=0;
    if($$('#interior_paintable_area').val()!='')
    {
        interior_paintable_area=$$('#interior_paintable_area').val();
        interior_paintable_area=interior_paintable_area.replace(/,/g, '');
        interior_paintable_area=parseFloat(interior_paintable_area);
    }
    if($$('#exterior_paintable_area').val()!='')
    {
        exterior_paintable_area=$$('#exterior_paintable_area').val();
        exterior_paintable_area=exterior_paintable_area.replace(/,/g, '');
        exterior_paintable_area=parseFloat(exterior_paintable_area);
    }
    var total_site_potentials=parseFloat(interior_paintable_area+exterior_paintable_area);
    total_site_potentials = isNaN(total_site_potentials) ? '0.00' : total_site_potentials;
    total_site_potentials = total_site_potentials.toFixed(3);
    total_site_potentials = addCommas(total_site_potentials);
    $$('#total_site_potentials').val(total_site_potentials);
});
$$('#exterior_paintable_area').on('input',function () {
    var interior_paintable_area=0;
    var exterior_paintable_area=0;
    if($$('#interior_paintable_area').val()!='')
    {
        interior_paintable_area=$$('#interior_paintable_area').val();
        interior_paintable_area=interior_paintable_area.replace(/,/g, '');
        interior_paintable_area=parseFloat(interior_paintable_area);
    }
    if($$('#exterior_paintable_area').val()!='')
    {
        exterior_paintable_area=$$('#exterior_paintable_area').val();
        exterior_paintable_area=exterior_paintable_area.replace(/,/g, '');
        exterior_paintable_area=parseFloat(exterior_paintable_area);
    }
    var total_site_potentials=parseFloat(interior_paintable_area+exterior_paintable_area);
    total_site_potentials = isNaN(total_site_potentials) ? '0.00' : total_site_potentials;
    total_site_potentials = total_site_potentials.toFixed(3);
    total_site_potentials = addCommas(total_site_potentials);
    $$('#total_site_potentials').val(total_site_potentials);
});
$$('#interior_paintable_area_update').on('input',function () {
    var interior_paintable_area_update=0;
    var exterior_paintable_area_update=0;
    if($$('#interior_paintable_area_update').val()!='')
    {
        interior_paintable_area_update=$$('#interior_paintable_area_update').val();
        interior_paintable_area_update=interior_paintable_area_update.replace(/,/g, '');
        interior_paintable_area_update=parseFloat(interior_paintable_area_update);
    }
    if($$('#exterior_paintable_area_update').val()!='')
    {
        exterior_paintable_area_update=$$('#exterior_paintable_area_update').val();
        exterior_paintable_area_update=exterior_paintable_area_update.replace(/,/g, '');
        exterior_paintable_area_update=parseFloat(exterior_paintable_area_update);
    }
    var total_site_potentials_update=parseFloat(interior_paintable_area_update+exterior_paintable_area_update);
    total_site_potentials_update = isNaN(total_site_potentials_update) ? '0.00' : total_site_potentials_update;
    total_site_potentials_update = total_site_potentials_update.toFixed(3);
    total_site_potentials_update = addCommas(total_site_potentials_update);
    $$('#total_site_potentials_update').val(total_site_potentials_update);
});
$$('#exterior_paintable_area_update').on('input',function () {
    var interior_paintable_area_update=0;
    var exterior_paintable_area_update=0;
    if($$('#interior_paintable_area_update').val()!='')
    {
        interior_paintable_area_update=$$('#interior_paintable_area_update').val();
        interior_paintable_area_update=interior_paintable_area_update.replace(/,/g, '');
        interior_paintable_area_update=parseFloat(interior_paintable_area_update);
    }
    if($$('#exterior_paintable_area_update').val()!='')
    {
        exterior_paintable_area_update=$$('#exterior_paintable_area_update').val();
        exterior_paintable_area_update=exterior_paintable_area_update.replace(/,/g, '');
        exterior_paintable_area_update=parseFloat(exterior_paintable_area_update);
    }
    var total_site_potentials_update=parseFloat(interior_paintable_area_update+exterior_paintable_area_update);
    total_site_potentials_update = isNaN(total_site_potentials_update) ? '0.00' : total_site_potentials_update;
    total_site_potentials_update = total_site_potentials_update.toFixed(3);
    total_site_potentials_update = addCommas(total_site_potentials_update);
    $$('#total_site_potentials_update').val(total_site_potentials_update);
});
$$('#billing_client_contact_update').on('input',function () {
    var project_id=$$('#project_id_update').val();
    if($$(this).val()=='')
    {
        $$(this).removeAttr('readonly');
        $$('.contact_details_update_project').hide();
        $$('.contact_details_update_project_exists').hide();
        $$('.contact_details_update_project_error').hide();
        $$('#name_contact_details_update_project').val('');
        $$('#mobile_contact_details_update_project').val('');
        myApp.hideIndicator();
    }
    else
    {
        if(check_contact_number($$(this).val()))
        {
            if(!checkConnection())
            {
                alert('No internet connection!');
                return;
            }
            $$('.contact_details_update_project_error').hide();
            $$('.contact_details_update_project_exists').hide();
            myApp.showIndicator();
            $$(this).attr('readonly','readonly');
            var url=base_url+"app/check_update_mobile_number";
            $$.ajax({
                url: url,
                type: "POST",
                datatype:'json',
                data: {mobile_number:$$(this).val(),check_purpose:'project',id:project_id},
                //timeout: 15000,
                cache: false,
                success: function(data){
                    var response= JSON.parse(data);
                    if(response.name!='')
                    {
                        $$('#billing_client_name_update').val('');
                        $$('#billing_client_name_update').val(response.name);
                        $$('.contact_details_update_project').css('display','flex');
                        $$('.contact_details_update_project_error').hide();
                        $$('.contact_details_update_project_exists').css('display','flex');
                        $$('#name_contact_details_update_project').html(response.name);
                        $$('#mobile_contact_details_update_project').html(response.contact);
                        $$('#billing_client_contact_update').removeAttr('readonly');
                    }
                    else
                    {
                        $$('.contact_details_update_project').hide();
                        $$('.contact_details_update_project_error').hide();
                        $$('.contact_details_update_project_exists').hide();
                        $$('#name_contact_details_update_project').html('');
                        $$('#mobile_contact_details_update_project').html('');
                        $$('#billing_client_contact_update').removeAttr('readonly');
                    }
                    myApp.hideIndicator();
                },
                error: function (e) {
                    $$('#billing_client_contact_update').removeAttr('readonly');
                    $$('.contact_details_update_project').hide();
                    $$('.contact_details_update_project_error').hide();
                    $$('.contact_details_update_project_exists').hide();
                    $$('#name_contact_details_update_project').html('');
                    $$('#mobile_contact_details_update_project').html('');
                    myApp.hideIndicator();
                    alert('There was a problem connecting to the server.Please try again.');
                }
            });
        }
        else
        {
            $$(this).removeAttr('readonly');
            $$('.contact_details_update_project').css('display','flex');
            $$('.contact_details_update_project_exists').hide();
            $$('.contact_details_update_project_error').css('display','flex');
            $$('#name_contact_details_update_project').val('');
            $$('#mobile_contact_details_update_project').val('');
            myApp.hideIndicator();
        }
    }
});
$$('#billing_client_contact').on('input',function () {
    if($$(this).val()=='')
    {
        $$(this).removeAttr('readonly');
        $$('.contact_details_project').hide();
        $$('.contact_details_project_exists').hide();
        $$('.contact_details_project_error').hide();
        $$('#name_contact_details_project').val('');
        $$('#mobile_contact_details_project').val('');
        myApp.hideIndicator();
    }
    else
    {
        if(check_contact_number($$(this).val()))
        {
            if(!checkConnection())
            {
                alert('No internet connection!');
                return;
            }
            $$('.contact_details_project_error').hide();
            $$('.contact_details_project_exists').hide();
            myApp.showIndicator();
            $$(this).attr('readonly','readonly');
            var url=base_url+"app/check_mobile_number";
            $$.ajax({
                url: url,
                type: "POST",
                datatype:'json',
                data: {mobile_number:$$(this).val(),check_purpose:'project'},
                //timeout: 15000,
                cache: false,
                success: function(data){
                    var response= JSON.parse(data);
                    if(response.name!='')
                    {
                        $$('#billing_client_name').val('');
                        $$('#billing_client_name').val(response.name);
                        $$('.contact_details_project').css('display','flex');
                        $$('.contact_details_project_error').hide();
                        $$('.contact_details_project_exists').css('display','flex');
                        $$('#name_contact_details_project').html(response.name);
                        $$('#mobile_contact_details_project').html(response.contact);
                        $$('#billing_client_contact').removeAttr('readonly');
                    }
                    else
                    {
                        $$('.contact_details_project').hide();
                        $$('.contact_details_project_error').hide();
                        $$('.contact_details_project_exists').hide();
                        $$('#name_contact_details_project').html('');
                        $$('#mobile_contact_details_project').html('');
                        $$('#billing_client_contact').removeAttr('readonly');
                    }
                    myApp.hideIndicator();
                },
                error: function (e) {
                    $$('#billing_client_contact').removeAttr('readonly');
                    $$('.contact_details_project').hide();
                    $$('.contact_details_project_error').hide();
                    $$('.contact_details_project_exists').hide();
                    $$('#name_contact_details_project').html('');
                    $$('#mobile_contact_details_project').html('');
                    myApp.hideIndicator();
                    alert('There was a problem connecting to the server.Please try again.');
                }
            });
        }
        else
        {
            $$(this).removeAttr('readonly');
            $$('.contact_details_project').css('display','flex');
            $$('.contact_details_project_exists').hide();
            $$('.contact_details_project_error').css('display','flex');
            $$('#name_contact_details_project').val('');
            $$('#mobile_contact_details_project').val('');
            myApp.hideIndicator();
        }
    }
});
$$('#contact_consultant').on('input',function () {
    if($$(this).val()=='')
    {
        $$(this).removeAttr('readonly');
        $$('#save_consultant').attr('disabled','disabled');
        $$('.contact_details_consultant').hide();
        $$('.contact_details_consultant_exists').hide();
        $$('.contact_details_consultant_error').hide();
        $$('#name_contact_details_consultant').val('');
        $$('#mobile_contact_details_consultant').val('');
        myApp.hideIndicator();
    }
    else
    {
        if(check_contact_number($$(this).val()))
        {
            if(!checkConnection())
            {
                alert('No internet connection!');
                return;
            }
            $$('.contact_details_consultant_error').hide();
            $$('.contact_details_consultant_exists').hide();
            myApp.showIndicator();
            $$(this).attr('readonly','readonly');
            var url=base_url+"app/check_mobile_number";
            $$.ajax({
                url: url,
                type: "POST",
                datatype:'json',
                data: {mobile_number:$$(this).val(),check_purpose:'consultant'},
                //timeout: 15000,
                cache: false,
                success: function(data){
                    var response= JSON.parse(data);
                    if(response.name!='')
                    {
                        $$('#contact_consultant').val('');
                        $$('.contact_details_consultant').css('display','flex');
                        $$('.contact_details_consultant_error').hide();
                        $$('.contact_details_consultant_exists').css('display','flex');
                        $$('#name_contact_details_consultant').html(response.name);
                        $$('#mobile_contact_details_consultant').html(response.contact);
                        $$('#contact_consultant').removeAttr('readonly');
                        $$('#save_consultant').attr('disabled','disabled');
                    }
                    else
                    {
                        $$('.contact_details_consultant').hide();
                        $$('.contact_details_consultant_error').hide();
                        $$('.contact_details_consultant_exists').hide();
                        $$('#name_contact_details_consultant').html('');
                        $$('#mobile_contact_details_consultant').html('');
                        $$('#contact_consultant').removeAttr('readonly');
                        $$('#save_consultant').removeAttr('disabled');
                    }
                    myApp.hideIndicator();
                },
                error: function (e) {
                    $$('#contact_consultant').removeAttr('readonly');
                    $$('#save_consultant').attr('disabled','disabled');
                    $$('.contact_details_consultant').hide();
                    $$('.contact_details_consultant_error').hide();
                    $$('.contact_details_consultant_exists').hide();
                    $$('#name_contact_details_consultant').html('');
                    $$('#mobile_contact_details_consultant').html('');
                    myApp.hideIndicator();
                    alert('There was a problem connecting to the server.Please try again.');
                }
            });
        }
        else
        {
            $$(this).removeAttr('readonly');
            $$('#save_consultant').attr('disabled','disabled');
            $$('.contact_details_consultant').css('display','flex');
            $$('.contact_details_consultant_exists').hide();
            $$('.contact_details_consultant_error').css('display','flex');
            $$('#name_contact_details_consultant').val('');
            $$('#mobile_contact_details_consultant').val('');
            myApp.hideIndicator();
        }
    }
});
$$('#form_contact_person_contact').on('input',function () {
    if($$(this).val()=='')
    {
        $$(this).removeAttr('readonly');
        $$('#save_contact_person').attr('disabled','disabled');
        $$('.contact_details_contact').hide();
        $$('.contact_details_contact_exists').hide();
        $$('.contact_details_contact_error').hide();
        $$('#name_contact_details_contact').val('');
        $$('#mobile_contact_details_contact').val('');
        myApp.hideIndicator();
    }
    else
    {
        if(check_contact_number($$(this).val()))
        {
            if(!checkConnection())
            {
                alert('No internet connection!');
                return;
            }
            var possible_users_info = app_data.possible_users_info;
            var ptext='';
            $$.each(possible_users_info, function (personid, name) {
                ptext+=personid+',';
            });
            ptext = ptext.slice(0, -1);
            $$('.contact_details_contact_error').hide();
            $$('.contact_details_contact_exists').hide();
            myApp.showIndicator();
            $$(this).attr('readonly','readonly');
            var url=base_url+"app/check_mobile_number";
            $$.ajax({
                url: url,
                type: "POST",
                datatype:'json',
                data: {mobile_number:$$(this).val(),check_purpose:'contact_person','pusers':ptext},
                //timeout: 15000,
                cache: false,
                success: function(data){
                    var response= JSON.parse(data);
                    if(response.name!='')
                    {
                        $$('#form_contact_person_contact').val('');
                        $$('.contact_details_contact').css('display','flex');
                        $$('.contact_details_contact_error').hide();
                        $$('.contact_details_contact_exists').css('display','flex');
                        $$('#name_contact_details_contact').html(response.name);
                        $$('#mobile_contact_details_contact').html(response.contact);
                        $$('#form_contact_person_contact').removeAttr('readonly');
                        $$('#save_contact_person').attr('disabled','disabled');
                    }
                    else
                    {
                        $$('.contact_details_contact').hide();
                        $$('.contact_details_contact_error').hide();
                        $$('.contact_details_contact_exists').hide();
                        $$('#name_contact_details_contact').html('');
                        $$('#mobile_contact_details_contact').html('');
                        $$('#form_contact_person_contact').removeAttr('readonly');
                        $$('#save_contact_person').removeAttr('disabled');
                    }
                    myApp.hideIndicator();
                },
                error: function (e) {
                    $$('#form_contact_person_contact').removeAttr('readonly');
                    $$('#save_contact_person').attr('disabled','disabled');
                    $$('.contact_details_contact').hide();
                    $$('.contact_details_contact_error').hide();
                    $$('.contact_details_contact_exists').hide();
                    $$('#name_contact_details_contact').html('');
                    $$('#mobile_contact_details_contact').html('');
                    myApp.hideIndicator();
                    alert('There was a problem connecting to the server.Please try again.');
                }
            });
        }
        else
        {
            $$(this).removeAttr('readonly');
            $$('#save_contact_person').attr('disabled','disabled');
            $$('.contact_details_contact').css('display','flex');
            $$('.contact_details_contact_exists').hide();
            $$('.contact_details_contact_error').css('display','flex');
            $$('#name_contact_details_contact').val('');
            $$('#mobile_contact_details_contact').val('');
            myApp.hideIndicator();
        }
    }
});
$$('#form_painter_contact').on('input',function () {
    if($$(this).val()=='')
    {
        $$(this).removeAttr('readonly');
        $$('#save_painter').attr('disabled','disabled');
        $$('.contact_details_painter').hide();
        $$('.contact_details_painter_exists').hide();
        $$('.contact_details_painter_error').hide();
        $$('#name_contact_details_painter').val('');
        $$('#mobile_contact_details_painter').val('');
        myApp.hideIndicator();
    }
    else
    {
        if(check_contact_number($$(this).val()))
        {
            if(!checkConnection())
            {
                alert('No internet connection!');
                return;
            }
            $$('.contact_details_painter_error').hide();
            $$('.contact_details_painter_exists').hide();
            myApp.showIndicator();
            $$(this).attr('readonly','readonly');
            var url=base_url+"app/check_mobile_number";
            $$.ajax({
                url: url,
                type: "POST",
                datatype:'json',
                data: {mobile_number:$$(this).val(),check_purpose:'painter'},
                //timeout: 15000,
                cache: false,
                success: function(data){
                    var response= JSON.parse(data);
                    if(response.name!='')
                    {
                        $$('#form_painter_contact').val('');
                        $$('.contact_details_painter').css('display','flex');
                        $$('.contact_details_painter_error').hide();
                        $$('.contact_details_painter_exists').css('display','flex');
                        $$('#name_contact_details_painter').html(response.name);
                        $$('#mobile_contact_details_painter').html(response.contact);
                        $$('#form_painter_contact').removeAttr('readonly');
                        $$('#save_painter').attr('disabled','disabled');
                    }
                    else
                    {
                        $$('.contact_details_painter').hide();
                        $$('.contact_details_painter_error').hide();
                        $$('.contact_details_painter_exists').hide();
                        $$('#name_contact_details_painter').html('');
                        $$('#mobile_contact_details_painter').html('');
                        $$('#form_painter_contact').removeAttr('readonly');
                        $$('#save_painter').removeAttr('disabled');
                    }
                    myApp.hideIndicator();
                },
                error: function (e) {
                    $$('#form_painter_contact').removeAttr('readonly');
                    $$('#save_painter').attr('disabled','disabled');
                    $$('.contact_details_painter').hide();
                    $$('.contact_details_painter_error').hide();
                    $$('.contact_details_painter_exists').hide();
                    $$('#name_contact_details_painter').html('');
                    $$('#mobile_contact_details_painter').html('');
                    myApp.hideIndicator();
                    alert('There was a problem connecting to the server.Please try again.');
                }
            });
        }
        else
        {
            $$(this).removeAttr('readonly');
            $$('#save_painter').attr('disabled','disabled');
            $$('.contact_details_painter').css('display','flex');
            $$('.contact_details_painter_exists').hide();
            $$('.contact_details_painter_error').css('display','flex');
            $$('#name_contact_details_painter').val('');
            $$('#mobile_contact_details_painter').val('');
            myApp.hideIndicator();
        }
    }
});
function check_contact_number(number) {
    if(number=='')
    {
        return false;
    }
    else
    {
        if(number.length==11)
        {
            if(number[0]==0 && number[1]==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
}
function ValidateEmail(inputText)
{
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if(inputText.match(mailformat))
    {
        return true;
    }
    else
    {
        return false;
    }
}
$$('#save_consultant').on('click',function () {
    if($$('#form_consultant_name').val()!='' && $$('#contact_consultant').val()!='')
    {
        if($$('#form_consultant_email').val()!='')
        {
            if(!ValidateEmail($$('#form_consultant_email').val()))
            {
                alert('Please enter valid email address!');return;
            }
        }
        var form_data={};
        if(check_contact_number($$('#contact_consultant').val()))
        {
            if(!checkConnection())
            {
                alert('No internet connection!');
                return;
            }
            myApp.showIndicator();
            var user_info = app_data.user_info;
            var url=base_url+"app/save_consultant";
            form_data['consultant_name']=$$('#form_consultant_name').val();
            form_data['contact_consultant']=$$('#contact_consultant').val();
            form_data['consultant_email']=$$('#form_consultant_email').val();
            form_data['consultant_dob']=$$('#form_consultant_dob').val();
            var new_data={};
            if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
            {
                new_data['today_date']=window.localStorage["today_date"];
            }
            else
            {
                new_data['today_date']='';
            }
            new_data['app_version']=$$('.version').html();
            $$.ajax({
                url: url,
                type: "POST",
                datatype:'json',
                data: {_token:window.localStorage["token"],user_id:user_info.user_id,form_data:form_data,new_data:new_data},
                //timeout: 15000,
                cache: false,
                success: function(data){
                    myApp.hideIndicator();
                    var response= JSON.parse(data);
                    if(response.status=='success')
                    {
                        $$('#form_consultant_name').val('');
                        $$('#contact_consultant').val('');
                        $$('#form_consultant_email').val('');
                        $$('#form_consultant_dob').val('');
                        $$('#save_consultant').attr('disabled','disabled');
                        var consultant_info = app_data.consultant_info;
                        var new_consultant={id: response.id,consultant_name: response.consultant_name,name_number: response.name_number};
                        consultant_info.push(new_consultant);
                        app_data.consultant_info=consultant_info;
                        saveJSON();
                        alert('Consultant info saved successfully');
                        consultant_list('consultant');
                    }
                    else if(response.status=='unauthorized')
                    {
                        alert('Unauthorized user found!');
                        logout();
                    }
                    else if(response.status == "time_over")
                    {
                        __timeOver();
                    }
                    else if(response.status == "deprecated")
                    {
                        __deprecated();
                    }
                    else
                    {
                        alert('Consultant info not saved successfully');
                    }
                },
                error: function (e) {
                    myApp.hideIndicator();
                    alert('There was a problem connecting to the server.Please try again.');
                }
            });
        }
        else
        {
            alert('Please all required fields!');
        }
    }
    else
    {
        alert('Please all required fields!');
    }
});
$$('#save_contact_person').on('click',function () {
    if($$('#form_contact_person_name').val()!='' && $$('#form_contact_person_contact').val()!='')
    {
        if(check_contact_number($$('#form_contact_person_contact').val()))
        {
            if(!checkConnection())
            {
                alert('No internet connection!');
                return;
            }
            myApp.showIndicator();
            var form_data={};
            var user_info = app_data.user_info;
            var url=base_url+"app/save_contact_person";
            form_data['contact_person_name']=$$('#form_contact_person_name').val();
            form_data['contact_person_contact']=$$('#form_contact_person_contact').val();
            var new_data={};
            if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
            {
                new_data['today_date']=window.localStorage["today_date"];
            }
            else
            {
                new_data['today_date']='';
            }
            new_data['app_version']=$$('.version').html();
            $$.ajax({
                url: url,
                type: "POST",
                datatype:'json',
                data: {_token:window.localStorage["token"],user_id:user_info.user_id,form_data:form_data,new_data:new_data},
                //timeout: 15000,
                cache: false,
                success: function(data){
                    myApp.hideIndicator();
                    var response= JSON.parse(data);
                    if(response.status=='success')
                    {
                        $$('#form_contact_person_name').val('');
                        $$('#form_contact_person_contact').val('');
                        $$('#save_contact_person').attr('disabled','disabled');
                        var contact_person_info=app_data.contact_person_info;
                        var new_person={id: response.id,contact_person_name: response.contact_person_name,name_number: response.name_number};
                        contact_person_info.push(new_person);
                        app_data.contact_person_info=contact_person_info;
                        saveJSON();
                        alert('Contact Person info saved successfully');
                        contact_person_list('contact_person')
                    }
                    else if(response.status=='unauthorized')
                    {
                        alert('Unauthorized user found!');
                        logout();
                    }
                    else if(response.status == "time_over")
                    {
                        __timeOver();
                    }
                    else if(response.status == "deprecated")
                    {
                        __deprecated();
                    }
                    else
                    {
                        alert('Contact Person info not saved successfully');
                    }
                },
                error: function (e) {
                    myApp.hideIndicator();
                    alert('There was a problem connecting to the server.Please try again.');
                }
            });
        }
        else
        {
            alert('Contact Number is not valid!');
        }
    }
    else
    {
        alert('Please all required fields!');
    }
});
$$('#save_painter').on('click',function () {
    if($$('#painter_region').val()!='' && $$('#painter_area').val()!='' && $$('#painter_territory').val()!='' && $$('#painter_cluster').val()!='' && $$('#form_painter_name').val()!='' && $$('#form_painter_contact').val()!='' && $$('#form_painter_status').val()!='')
    {
        var contact=$$('#form_painter_contact').val();
        if(check_contact_number(contact))
        {
            if(!checkConnection())
            {
                alert('No internet connection!');
                return;
            }
            myApp.showIndicator();
            var form_data={};
            var user_info = app_data.user_info;
            var url=base_url+"app/save_painter";
            form_data['painter_name']=$$('#form_painter_name').val();
            form_data['painter_code']=$$('#form_painter_code').val();
            form_data['painter_contact']=$$('#form_painter_contact').val();
            form_data['status']=$$('.form_painter_status').val();
            if($$('.form_painter_status').val()=='Registered')
            {
                form_data['progoti_status_id']=$$('.form_progoti_status').val();
            }
            form_data['cluster']=$$('#painter_cluster').val();
            var new_data={};
            if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
            {
                new_data['today_date']=window.localStorage["today_date"];
            }
            else
            {
                new_data['today_date']='';
            }
            new_data['app_version']=$$('.version').html();
            $$.ajax({
                url: url,
                type: "POST",
                datatype:'json',
                data: {_token:window.localStorage["token"],user_id:user_info.user_id,user_level_id:user_info.user_level_id,form_data:form_data,new_data:new_data},
                //timeout: 15000,
                cache: false,
                success: function(data){
                    myApp.hideIndicator();
                    var response= JSON.parse(data);
                    if(response.status=='success')
                    {
                        alert('Painter info saved successfully');
                        window.localStorage["new_painter_number_today"]=Number(window.localStorage["new_painter_number_today"])+1;
                        painter_list('painter_list');
                    }
                    else if(response.status=='duplicate')
                    {
                        $$('#form_painter_contact').val('');
                        alert('Duplicate contact number found!');
                    }
                    else if(response.status=='unauthorized')
                    {
                        alert('Unauthorized user found!');
                        logout();
                    }
                    else if(response.status == "time_over")
                    {
                        __timeOver();
                    }
                    else if(response.status == "deprecated")
                    {
                        __deprecated();
                    }
                    else
                    {
                        alert('Painter info not saved successfully');
                    }
                },
                error: function (e) {
                    myApp.hideIndicator();
                    alert('There was a problem connecting to the server.Please try again.');
                }
            });
        }
        else
        {
            alert('Invalid Contact No.');
        }
    }
    else
    {
        alert('Please all required fields!');
    }
});
Object.size = function(obj) {
    var size = 0, key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) size++;
    }
    return size;
};

function project_appointment_set(project_id)
{
    var html='';
    var project_list=app_data.project_detail_info;
    if(project_id!='' && project_id!=0)
    {
        $$.each(project_list, function (cluster_id, set_values) {
            $$.each(set_values, function (index, value) {
                if(value.id==project_id)
                {
                    html+= '<option data-cluster="'+cluster_id+'" value="'+value.id+'" selected>'+value.project_name+'</option>';
                }
                else
                {
                    html+= '<option data-cluster="'+cluster_id+'" value="'+value.id+'">'+value.project_name+'</option>';
                }
            });
        });
        adminView.router.load({
            pageName: 'project_call-page'
        });
        user_nav('project_call');
    }
    else
    {
        $$.each(project_list, function (cluster_id, set_values) {
            $$.each(set_values, function (index, value) {
                html+= '<option data-cluster="'+cluster_id+'" value="'+value.id+'">'+value.project_name+'</option>';
            });
        });
    }
    $$('.repeat_info_text').html('');
    $$('.repeat_info_text_container').css("display","none");
    $$('.date_div').css('display','flex');
    $$('#repeat_status_call_project').val(1);
    $$('#save_repeat').attr('data-id',0);
    $$('#project_id_call_project').html(html);
    $$('.u_hide').hide();
    $$('.project_call_add').show();
    $$('.navbar').hide();
    $$('.project_call_add-nav').show();
}
$$('#project_call_create').on('click',function () {
    var id=0;
    if(check_action_status())
    {
        project_appointment_set(id);
    }
});
$$('#project_call_create_today').on('click',function () {
    var id=0;
    if(check_action_status())
    {
        if($$('.popup_start_project').hasClass('modal-in'))
        {
            $$('.page-content').removeAttr('style','opacity: 40%;background-color: #eee;');
            myApp.closePanel();
            $$('.popup-overlay').removeClass('modal-overlay-visible');
            myApp.closeModal('.popup_start_project');
        }
        project_appointment_set(id);
    }
});
$$('#project_call_create_overdue').on('click',function () {
    var id=0;
    if(check_action_status())
    {
        project_appointment_set(id);
    }
});
$$('#project_call_create_upcoming').on('click',function () {
    var id=0;
    if(check_action_status())
    {
        project_appointment_set(id);
    }
});
$$('#project_call_create_completed').on('click',function () {
    var id=0;
    if(check_action_status())
    {
        project_appointment_set(id);
    }
});
$$('#click_here_project_call').on('click',function () {
    var id=0;
    var cluster_id=0;
    if(check_action_status())
    {
        project_appointment_set(id,cluster_id);
    }
});
$$('#click_here_painter_call').on('click',function () {
    var id=0;
    var cluster_id=0;
    if(check_action_status())
    {
        painter_appointment_set(id,cluster_id);
    }
});
$$('.project_call_summary_back_button').on('click',function () {
    if($$('.popup-repeats').hasClass('modal-in'))
    {
        $$('#repeat_status_call_project').val(1);
        myApp.closePanel();
        $$('.popup-overlay').removeClass('modal-overlay-visible');
        myApp.closeModal('.popup-repeats');
    }
    if($$('.popup_start_project').hasClass('modal-in'))
    {
        $$('.page-content').removeAttr('style','opacity: 40%;background-color: #eee;');
        myApp.closePanel();
        $$('.popup-overlay').removeClass('modal-overlay-visible');
        myApp.closeModal('.popup_start_project');
    }
    show_project_call_summary('project_call');
});
$$('.open-panel').on('click',function () {
    if($$('.popup-repeats').hasClass('modal-in'))
    {
        $$('#repeat_status_call_project').val(1);
        myApp.closePanel();
        $$('.popup-overlay').removeClass('modal-overlay-visible');
        myApp.closeModal('.popup-repeats');
    }
    if($$('.popup_start_project').hasClass('modal-in'))
    {
        $$('.page-content').removeAttr('style','opacity: 40%;background-color: #eee;');
        myApp.closePanel();
        $$('.popup-overlay').removeClass('modal-overlay-visible');
        myApp.closeModal('.popup_start_project');
    }
});
$$('.a_home').on('click',function () {
    if($$('.popup-repeats').hasClass('modal-in'))
    {
        $$('#repeat_status_call_project').val(1);
        myApp.closePanel();
        $$('.popup-overlay').removeClass('modal-overlay-visible');
        myApp.closeModal('.popup-repeats');
    }
    if($$('.popup_start_project').hasClass('modal-in'))
    {
        $$('.page-content').removeAttr('style','opacity: 40%;background-color: #eee;');
        myApp.closePanel();
        $$('.popup-overlay').removeClass('modal-overlay-visible');
        myApp.closeModal('.popup_start_project');
    }
});
function painter_appointment_set(painter_id,cluster_id)
{
    var html='';
    var cluster_html='';
    var painter_info = app_data.painter_info;
    var user_location = app_data.user_location;
    if(painter_id!='' && painter_id!=0)
    {
        var result = cluster_id.split(',');
        $$.each(result, function (index, value) {
            $$.each(user_location.cluster, function (index1, value1) {
                $$.each(value1, function (i1, v1) {
                    if(v1.cluster_id==value)
                    {
                        cluster_html+= '<option value="'+v1.cluster_id+'">'+v1.cluster_code+' - '+v1.cluster_name+'</option>';
                    }
                });
            });
        });
        $$.each(painter_info, function (cluster_id, set_value) {
            $$.each(set_value, function (index, value) {
                if(value.id==painter_id)
                {
                    html += '<option value="' + value.id + '" selected>' + value.painter_name + '</option>';
                }
                else
                {
                    html += '<option value="' + value.id + '">' + value.painter_name + '</option>';
                }
            });
        });
        adminView.router.load({
            pageName: 'painter_call-page'
        });
    }
    else
    {
        $$.each(user_location.cluster, function (index, value) {
            $$.each(value, function (i, v) {
                cluster_html+= '<option value="'+v.cluster_id+'">'+v.cluster_code+' - '+v.cluster_name+'</option>';
            });
        });
        $$.each(painter_info, function (cluster_id, set_values) {
            $$.each(set_values, function (index, value) {
                html+= '<option value="'+value.id+'">'+value.painter_name+'</option>';
            });
        });
    }
    $$('.repeat_info_text').html('');
    $$('.repeat_info_text_container').css("display","none");
    $$('.date_div').css('display','flex');
    $$('#repeat_status_call_painter').val(1);
    $$('#save_repeat').attr('data-id',0);
    $$('#painter_id_call_painter').html(html);
    $$('#cluster_id_call_painter').html(cluster_html);
    $$('.u_hide').hide();
    $$('.painter_call_add').show();
    $$('.navbar').hide();
    $$('.painter_call_add-nav').show();
}
function show_project_call_summary(class_name) {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    var user_info = app_data.user_info;
    var user_location = app_data.user_location;
    var url=base_url+"app/get_project_call_summary_info";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    myApp.showIndicator();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],user_id:user_info.user_id,user_level_id:user_info.user_level_id,user_level:user_info.user_level,cluster:user_location.cluster,new_data:new_data},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status='success')
            {
                $$('.overdue_digit').html(response.overdue_digit);
                $$('.today_digit').html(response.today_digit);
                $$('.upcoming_digit').html(response.upcoming_digit);
                $$('.completed_digit').html(response.completed_digit);
                adminView.router.load({
                    pageName: class_name+'-page'
                });
                user_nav(class_name);
            }
            else if(response.status='invalid')
            {
                alert('Invalid Request!');
            }
            else if(response.status='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
$$(document).on('click', function (e) {
    if ($$(e.target).closest(".complete_input_ul").length === 0) {
        $$(".complete_input_ul").hide();
    }
});
$$('#painter_call_create').on('click',function () {
    var id=0;
    var cluster_id=0;
    if(check_action_status())
    {
        painter_appointment_set(id,cluster_id);
    }
});
$$('#painter_call_create_today').on('click',function () {
    var id=0;
    var cluster_id=0;
    if(check_action_status())
    {
        if($$('.popup_start_painter').hasClass('modal-in'))
        {
            $$('.page-content').removeAttr('style','opacity: 40%;background-color: #eee;');
            myApp.closePanel();
            $$('.popup-overlay').removeClass('modal-overlay-visible');
            myApp.closeModal('.popup_start_painter');
        }
        painter_appointment_set(id,cluster_id);
    }
});
$$('#painter_call_create_overdue').on('click',function () {
    var id=0;
    var cluster_id=0;
    if(check_action_status())
    {
        painter_appointment_set(id,cluster_id);
    }
});
$$('#painter_call_create_upcoming').on('click',function () {
    var id=0;
    var cluster_id=0;
    if(check_action_status())
    {
        painter_appointment_set(id,cluster_id);
    }
});
$$('#painter_call_create_completed').on('click',function () {
    var id=0;
    var cluster_id=0;
    if(check_action_status())
    {
        painter_appointment_set(id,cluster_id);
    }
});
$$('.painter_call_summary_back_button').on('click',function () {
    if($$('.popup ').hasClass('modal-in'))
    {
        $$('#repeat_status_call_painter').val(1);
        myApp.closePanel();
        $$('.popup-overlay').removeClass('modal-overlay-visible');
        myApp.closeModal('.popup-repeats');
    }
    show_painter_call_summary('painter_call');
});
function show_painter_call_summary(class_name) {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    var user_info = app_data.user_info;
    var user_location = app_data.user_location;
    var url=base_url+"app/get_painter_call_summary_info";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    myApp.showIndicator();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,user_level_id:user_info.user_level_id,user_level:user_info.user_level,cluster:user_location.cluster},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status='success')
            {
                $$('.overdue_digit').html(response.overdue_digit);
                $$('.today_digit').html(response.today_digit);
                $$('.upcoming_digit').html(response.upcoming_digit);
                $$('.completed_digit').html(response.completed_digit);
                adminView.router.load({
                    pageName: class_name+'-page'
                });
                user_nav(class_name);
            }
            else if(response.status='invalid')
            {
                alert('Invalid Request!');
            }
            else if(response.status='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
$$('#repeat_status_call_project').off('change');
$$('#repeat_status_call_project').on('change', function () {
    $$('.repeat_info_text_container').css("display","none");
    if($$(this).val()==2)
    {
        $$('.date_div').attr('style','display: none !important');
        myApp.popup('.popup-repeats');
        $$('.popup-repeats').attr('style','display: block !important');
        //$$('.popup').attr('style','display: block !important');
        $$('.modal-in').attr('style','display: block !important');
        $$('.popup-overlay').addClass('modal-overlay-visible');
    }
    else
    {
        $$('.date_div').attr('style','display:  !important');
        if(Number($$('#save_repeat').attr('data-id'))!=1)
        {
            myApp.closePanel();
            $$('.popup-overlay').removeClass('modal-overlay-visible');
            myApp.closeModal('.popup-repeats');
        }
    }
});
$$('#repeat_status_call_painter').off('change');
$$('#repeat_status_call_painter').on('change', function () {
    $$('.repeat_info_text_container').css("display","none");
    if($$(this).val()==2)
    {
        $$('.date_div').attr('style','display: none !important');
        myApp.popup('.popup-repeats');
        $$('.popup-repeats').attr('style','display: block !important');
        //$$('.popup').attr('style','display: block !important');
        $$('.modal-in').attr('style','display: block !important');
        $$('.popup-overlay').addClass('modal-overlay-visible');
    }
    else
    {
        $$('.date_div').attr('style','display:  !important');
        if(Number($$('#save_repeat').attr('data-id'))!=1)
        {
            myApp.closePanel();
            $$('.popup-overlay').removeClass('modal-overlay-visible');
            myApp.closeModal('.popup-repeats');
        }
    }
});
$$('#repeat_number').off('change');
$$('#repeat_number').on('change', function () {
    if($$(this).val()==1)
    {
        $$('#day').html('day');
        $$('#week').html('week');
    }
    else
    {
        $$('#day').html('days');
        $$('#week').html('weeks');
    }
});

$$('.repeat_category').off('change');
$$('.repeat_category').on('change', function () {
    if($$(this).val()=='week')
    {
        $$('.repeat_on_head').css("display", "flex");
    }
    else
    {
        $$('.repeat_on_head').css("display", "none");
    }
});

$$('#outer_circle_check_on').on('click', function () {
    $$('#circle_check_input').val('on');
    $$('#inner_circle_check_on').show();
    $$('#inner_circle_check_after').hide();
});
$$('#outer_circle_check_after').on('click', function () {
    $$('#circle_check_input').val('after');
    $$('#inner_circle_check_on').hide();
    $$('#inner_circle_check_after').show();
});
$$('#save_repeat').on('click',function () {

    var repeat_number=$$('#repeat_number').val();
    var repeat_category=$$('.repeat_category').val();
    var circle_class_input='';
    $$(".circle_class_input").each(function(index,valu)
    {
        if($$(this).val()!='')
        {
            circle_class_input+=$$(this).val()+', ';
        }
    });
    var circle_check_input = $$('#circle_check_input').val();
    var ends_on_date = $$('#ends_on_date').val();
    var occurrence_number = $$('#occurrence_number').val();
    if(repeat_number=='' || repeat_category=='' || circle_check_input=='')
    {
        alert('Field Missing!');
        return;
    }
    if(repeat_category=='week' && circle_class_input=='')
    {
        alert('Field Missing!');
        return;
    }
    if(circle_check_input=='on' && ends_on_date=='')
    {
        alert('Field Missing!');
        return;
    }
    if(circle_check_input=='after' && occurrence_number=='')
    {
        alert('Field Missing!');
        return;
    }
    $$('.repeat_number_project').html(repeat_number);
    $$('.repeat_category_project').html(repeat_category);
    var repeat_info='';
    if(repeat_category=='week')
    {
        $$('.circle_class_input_project').html(circle_class_input);
        if(repeat_number==1)
        {
            repeat_info+='Weekly on '+circle_class_input+' '
        }
        else
        {
            repeat_info+='Every '+repeat_number+' weeks on '+circle_class_input+' '
        }
    }
    else
    {
        $$('.circle_class_input_project').html('');
        if(repeat_number==1)
        {
            repeat_info+='Daily, ';
        }
        else
        {
            repeat_info+='Every '+repeat_number+' days, '
        }
    }
    $$('.circle_check_input_project').html(circle_check_input);
    if(circle_check_input=='on')
    {
        $$('.ends_on_date_project').html(ends_on_date);
        repeat_info+='Until '+ends_on_date;
    }
    else
    {
        $$('.occurrence_number_project').html(occurrence_number);
        repeat_info+=occurrence_number+' times';
    }
    repeat_info+='.';
    $$('.repeat_info_text').html(repeat_info);
    $$('.repeat_info_text_container').css("display","flex");
    $$(this).attr('data-id',1);
    myApp.closePanel();
    $$('.popup-overlay').removeClass('modal-overlay-visible');
    myApp.closeModal('.popup-repeats');
});
$$('#cancel_repeat').on('click',function () {
    $$('.repeat_info_text').html('');
    $$('.repeat_info_text_container').css("display","none");
    $$('#save_repeat').attr('data-id',0);
    $$('#repeat_status_call_project').val(1);
    $$('#repeat_status_call_painter').val(1);
    $$('.date_div').attr('style','display:  !important');
    myApp.closePanel();
    $$('.popup-overlay').removeClass('modal-overlay-visible');
    myApp.closeModal('.popup-repeats');
});
$$('#save_call_project').on('click',function () {
    if($$('#project_id_call_project').val()=='')
    {
        alert('Field Missing');
        return;
    }
    if($$('#title_call_project').val()=='')
    {
        alert('Field Missing');
        return;
    }
    if($$('#repeat_status_call_project').val()=='')
    {
        alert('Field Missing');
        return;
    }
    if($$('#time_call_project').val()=='')
    {
        alert('Field Missing');
        return;
    }
    if($$('#repeat_status_call_project').val()==1)
    {
        if($$('#date_call_project').val()=='')
        {
            alert('Field Missing');
            return;
        }
    }
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    var project_id=$$('#project_id_call_project').val();
    var title=$$('#title_call_project').val();
    var repeat_status=$$('#repeat_status_call_project').val();
    var time=$$('#time_call_project').val();
    var remarks=$$('#remarks_call_project').val();
    var date=$$('#date_call_project').val();
    var reminder={};
    if($$('.repeat_number_project').html()!='')
    {
        reminder['repeat_number']=$$('.repeat_number_project').html();
    }
    if($$('.repeat_category_project').html()!='')
    {
        reminder['repeat_category']=$$('.repeat_category_project').html();
    }
    if($$('.circle_class_input_project').html()!='')
    {
        reminder['weekdays']=$$('.circle_class_input_project').html();
    }
    if($$('.circle_check_input_project').html()!='')
    {
        reminder['finish_status']=$$('.circle_check_input_project').html();
    }
    if($$('.ends_on_date_project').html()!='')
    {
        reminder['finish_date']=$$('.ends_on_date_project').html();
    }
    if($$('.occurrence_number_project').html()!='')
    {
        reminder['finish_number']=$$('.occurrence_number_project').html();
    }
    var user_info = app_data.user_info;
    myApp.showIndicator();
    var url=base_url+"app/save_project_call";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,project_id:project_id,title:title,repeat_status:repeat_status,time:time,remarks:remarks,date:date,reminder:reminder},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status='success')
            {
                if(response.today_matching_day==1)
                {
                    window.localStorage["new_followup_project_all_number_today"]=Number(window.localStorage["new_followup_project_all_number_today"])+1;
                }
                alert('Appointment saved successfully!');
                show_project_call_summary('project_call');
            }
            else if(response.status='invalid')
            {
                alert('Invalid Request!');
            }
            else if(response.status='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
});
$$('#save_call_painter').on('click',function () {
    if($$('#cluster_id_call_painter').val()=='')
    {
        alert('Field Missing');
        return;
    }
    if($$('#painter_id_call_painter').val()=='')
    {
        alert('Field Missing');
        return;
    }
    if($$('#title_call_painter').val()=='')
    {
        alert('Field Missing');
        return;
    }
    if($$('#repeat_status_call_painter').val()=='')
    {
        alert('Field Missing');
        return;
    }
    if($$('#time_call_painter').val()=='')
    {
        alert('Field Missing');
        return;
    }
    if($$('#repeat_status_call_painter').val()==1)
    {
        if($$('#date_call_painter').val()=='')
        {
            alert('Field Missing');
            return;
        }
    }
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    var painter_id=$$('#painter_id_call_painter').val();
    var cluster_id=$$('#cluster_id_call_painter').val();
    var title=$$('#title_call_painter').val();
    var repeat_status=$$('#repeat_status_call_painter').val();
    var time=$$('#time_call_painter').val();
    var remarks=$$('#remarks_call_painter').val();
    var date=$$('#date_call_painter').val();
    var reminder={};
    if($$('.repeat_number_project').html()!='')
    {
        reminder['repeat_number']=$$('.repeat_number_project').html();
    }
    if($$('.repeat_category_project').html()!='')
    {
        reminder['repeat_category']=$$('.repeat_category_project').html();
    }
    if($$('.circle_class_input_project').html()!='')
    {
        reminder['weekdays']=$$('.circle_class_input_project').html();
    }
    if($$('.circle_check_input_project').html()!='')
    {
        reminder['finish_status']=$$('.circle_check_input_project').html();
    }
    if($$('.ends_on_date_project').html()!='')
    {
        reminder['finish_date']=$$('.ends_on_date_project').html();
    }
    if($$('.occurrence_number_project').html()!='')
    {
        reminder['finish_number']=$$('.occurrence_number_project').html();
    }
    myApp.showIndicator();
    var user_info = app_data.user_info;
    var url=base_url+"app/save_painter_call";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,cluster_id:cluster_id,painter_id:painter_id,title:title,repeat_status:repeat_status,time:time,remarks:remarks,date:date,reminder:reminder},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status='success')
            {
                if(response.today_matching_day==1)
                {
                    window.localStorage["new_followup_painter_all_number_today"]=Number(window.localStorage["new_followup_painter_all_number_today"])+1;
                }
                alert('Appointment saved successfully!');
                show_painter_call_summary('painter_call');
            }
            else if(response.status='invalid')
            {
                alert('Invalid Request!');
            }
            else if(response.status='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
});
$$('#filter_painter').on('input',function () {
    var search = $$(this).val().toLowerCase();
    var painter_info=app_data.painter_info;
    if(search=='')
    {
        $$.each(painter_info, function (cluster_id, set_values) {
            $$('.cluster_painter_'+cluster_id).css("display", "block");
            $$.each(set_values, function (index, value) {
                $$('.painter_list_'+value.id).css("display", "flex");
            });
        });
    }
    else
    {
        $$.each(painter_info, function (cluster_id, set_values) {
            var check=0;
            $$.each(set_values, function (index, value) {
                var str=value.name_number.toLowerCase();
                if(str.includes(search))
                {
                    $$('.painter_list_'+value.id).css("display", "flex");
                    check++;
                }
                else
                {
                    $$('.painter_list_'+value.id).css("display", "none");
                }
            });
            if(check)
            {
                $$('.cluster_painter_'+cluster_id).css("display", "block");
            }
            else
            {
                $$('.cluster_painter_'+cluster_id).css("display", "none");
            }
        });
    }
});
$$('#filter_painter_status').on('change',function () {
    var status = $$(this).val();
    var painter_info=app_data.painter_info;
    if(status=='ALL')
    {
        $$.each(painter_info, function (cluster_id, set_values) {
            $$('.cluster_painter_'+cluster_id).css("display", "block");
            $$.each(set_values, function (index, value) {
                $$('.painter_list_'+value.id).css("display", "flex");
            });
        });
    }
    else
    {
        if(status=='Registered' || status=='Unregistered')
        {
            $$.each(painter_info, function (cluster_id, set_values) {
                var check=0;
                $$.each(set_values, function (index, value) {
                    if(value.status==status)
                    {
                        $$('.painter_list_'+value.id).css("display", "flex");
                        check++;
                    }
                    else
                    {
                        $$('.painter_list_'+value.id).css("display", "none");
                    }
                });
                if(check)
                {
                    $$('.cluster_painter_'+cluster_id).css("display", "block");
                }
                else
                {
                    $$('.cluster_painter_'+cluster_id).css("display", "none");
                }
            });
        }
        else
        {
            $$.each(painter_info, function (cluster_id, set_values) {
                var check=0;
                $$.each(set_values, function (index, value) {
                    if(value.progoti_status==status)
                    {
                        $$('.painter_list_'+value.id).css("display", "flex");
                        check++;
                    }
                    else
                    {
                        $$('.painter_list_'+value.id).css("display", "none");
                    }
                });
                if(check)
                {
                    $$('.cluster_painter_'+cluster_id).css("display", "block");
                }
                else
                {
                    $$('.cluster_painter_'+cluster_id).css("display", "none");
                }
            });
        }
    }
});
$$('#filter_consultant').on('input',function () {
    var search = $$(this).val().toLowerCase();
    var consultant_info=app_data.consultant_info;
    $$.each(consultant_info, function (index, value) {
        if(search=='')
        {
            $$('.consultant_list_'+value.id).css("display", "flex");
        }
        else
        {
            var str=value.name_number.toLowerCase();
            if(str.includes(search)){
                $$('.consultant_list_'+value.id).css("display", "flex");
            }
            else
            {
                $$('.consultant_list_'+value.id).css("display", "none");
            }
        }
    });
});
$$('#filter_contact_person').on('input',function () {
    var search = $$(this).val().toLowerCase();
    var contact_person_info=app_data.contact_person_info;
    $$.each(contact_person_info, function (index, value) {
        if(search=='')
        {
            $$('.contact_person_list_'+value.id).css("display", "flex");
        }
        else
        {
            var str=value.name_number.toLowerCase();
            if(str.includes(search)){
                $$('.contact_person_list_'+value.id).css("display", "flex");
            }
            else
            {
                $$('.contact_person_list_'+value.id).css("display", "none");
            }
        }
    });
});
$$('#filter_project_list').on('input',function () {
    var search=$$(this).val();
    var project_detail_info=app_data.project_detail_info;
    if(search=='')
    {
        $$.each(project_detail_info, function (cluster_id, set_values) {
            $$('.cluster_project_'+cluster_id).css("display", "block");
            $$.each(set_values, function (index, value) {
                $$('.project_list_'+value.id).css("display", "flex");
            });
        });
    }
    else
    {
        search=$$(this).val().toLowerCase();
        $$.each(project_detail_info, function (cluster_id, set_values) {
            var check=0;
            $$.each(set_values, function (index, value) {
                var str = value.project_name.toLowerCase();
                if(str.includes(search))
                {
                    $$('.project_list_'+value.id).css("display", "flex");
                    check++;
                }
                else
                {
                    $$('.project_list_'+value.id).css("display", "none");
                }
            });
            if(check)
            {
                $$('.cluster_project_'+cluster_id).css("display", "block");
            }
            else
            {
                $$('.cluster_project_'+cluster_id).css("display", "none");
            }
        });
    }
});
$$('#rating_select_div').on('change',function () {
    var status = $$(this).val();
    var project_detail_info=app_data.project_detail_info;
    if(status=='ALL')
    {
        $$.each(project_detail_info, function (cluster_id, set_values) {
            $$('.cluster_project_'+cluster_id).css("display", "block");
            $$.each(set_values, function (index, value) {
                $$('.project_list_'+value.id).css("display", "flex");
            });
        });
    }
    else
    {
        $$.each(project_detail_info, function (cluster_id, set_values) {
            var check=0;
            $$.each(set_values, function (index, value) {
                if(value.project_status==status)
                {
                    $$('.project_list_'+value.id).css("display", "flex");
                    check++;
                }
                else
                {
                    $$('.project_list_'+value.id).css("display", "none");
                }
            });
            if(check)
            {
                $$('.cluster_project_'+cluster_id).css("display", "block");
            }
            else
            {
                $$('.cluster_project_'+cluster_id).css("display", "none");
            }
        });
    }
});
$$('.normal_circle_class').on('click',function () {
    set_bold_circle_class($$(this));
});
$$('.bold_circle_class').on('click',function () {
    set_normal_circle_class($$(this));
});
function set_normal_circle_class(item) {
    var data_id=item.attr('data-id');
    $$('#circle_'+data_id).val('');
    $$('#circle_'+data_id).attr('name','');

    item.removeAttr('class','bold_circle_class');
    item.attr('class','normal_circle_class');
    $$('.normal_circle_class').on('click',function () {
        set_bold_circle_class($$(this));
    });
}
function set_bold_circle_class(item) {
    var data_id=item.attr('data-id');
    var value = $$('#circle_'+data_id).attr('data-value');
    $$('#circle_'+data_id).val(value);
    $$('#circle_'+data_id).attr('name','circle_class_input[]');
    item.removeAttr('class','normal_circle_class');
    item.attr('class','bold_circle_class');
    $$('.bold_circle_class').on('click',function () {
        set_normal_circle_class($$(this));
    });
}
function call_overdue_project_call_list()
{
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    myApp.showIndicator();
    $$('#overdue_project_container_apec_total').css('display','none');
    $$('.overdue_project_container_apec').html('');
    var user_info = app_data.user_info;
    var user_location = app_data.user_location;
    var url=base_url+"app/get_overdue_call";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,user_level_id:user_info.user_level_id,user_level:user_info.user_level,cluster:user_location.cluster,call_type:'project'},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status='success')
            {
                var html='';
                if(response.overdue.length==0)
                {
                    html+='<div class="row call_list_div_pending">' +
                        '<div class="col-100" style="text-align: center;">' +
                        '<span>No Data Found!</span>' +
                        '</div>' +
                        '</div>';
                }
                else
                {
                    $$.each(response.overdue, function( index, value ) {
                        html += '<div class="row call_list_div_pending link_for_details_project" data-id="'+value.id+'">' +
                            '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                            '<p class="call_title_pending">' + value.title + '</p>' +
                            '<p class="call_project_name_pending">' + value.project_name + '</p>' +
                            '</div>' +
                            '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                            '<p class="call_time_pending">' + value.date + ' ' + value.meeting_time + '</p>' +
                            '<p class="call_status_pending">Pending</p>' +
                            '</div>' +
                            '</div>' +
                            '<div class="row separator"></div>';
                    });
                }
                $$('.overdue_project_container').html(html);
                if((user_info.user_level!='TSI') && (user_info.user_level!='APEC'))
                {
                    var other_html='';
                    if(response.overdue_other.length==0)
                    {
                        other_html+='<div class="row call_list_div_pending">' +
                            '<div class="col-100" style="text-align: center;">' +
                            '<span>No Data Found!</span>' +
                            '</div>' +
                            '</div>';
                    }
                    else
                    {
                        $$.each(response.overdue_other, function( index, value ) {
                            other_html += '<div class="row call_list_div_pending link_for_details_project" data-id="'+value.id+'">' +
                                '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                                '<p class="call_title_pending">' + value.title + '</p>' +
                                '<p class="call_project_name_pending">' + value.project_name + '</p>' +
                                '</div>' +
                                '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                                '<p class="call_time_pending">' + value.date + ' ' + value.meeting_time + '</p>' +
                                '<p class="call_status_pending">Pending</p>' +
                                '</div>' +
                                '</div>' +
                                '<div class="row separator"></div>';
                        });
                    }
                    $$('#overdue_project_container_apec_total').css('display','block');
                    $$('.overdue_project_container_apec').html(other_html);
                }
                $$('.u_hide').hide();
                $$('.project_call_overdue').show();
                $$('.navbar').hide();
                $$('.project_call_overdue-nav').show();
                $$('.link_for_details_project').on('click',function () {
                    link_for_details_project($$(this).attr('data-id'),'overdue_project');
                });
            }
            else if(response.status='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
function call_overdue_painter_call_list() {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    myApp.showIndicator();
    $$('#overdue_painter_container_apec_total').css('display','none');
    $$('.overdue_painter_container_apec').html('');
    var user_info = app_data.user_info;
    var user_location = app_data.user_location;
    var url=base_url+"app/get_overdue_call";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,user_level_id:user_info.user_level_id,user_level:user_info.user_level,cluster:user_location.cluster,call_type:'painter'},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status='success')
            {
                var html='';
                if(response.overdue.length==0)
                {
                    html+='<div class="row call_list_div_pending">' +
                        '<div class="col-100" style="text-align: center;">' +
                        '<span>No Data Found!</span>' +
                        '</div>' +
                        '</div>';
                }
                else
                {
                    $$.each(response.overdue, function( index, value ) {
                        html += '<div class="row call_list_div_pending link_for_details_painter" data-id="'+value.id+'">' +
                            '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                            '<p class="call_title_pending">' + value.title + '</p>' +
                            '<p class="call_painter_name_pending">' + value.painter_name + '</p>' +
                            '</div>' +
                            '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                            '<p class="call_time_pending">' + value.date + ' ' + value.meeting_time + '</p>' +
                            '<p class="call_status_pending">Pending</p>' +
                            '</div>' +
                            '</div>' +
                            '<div class="row separator"></div>';
                    });
                }
                $$('.overdue_painter_container').html(html);
                if((user_info.user_level!='TSI') && (user_info.user_level!='APEC'))
                {
                    var other_html='';
                    if(response.overdue_other.length==0)
                    {
                        other_html+='<div class="row call_list_div_pending">' +
                            '<div class="col-100" style="text-align: center;">' +
                            '<span>No Data Found!</span>' +
                            '</div>' +
                            '</div>';
                    }
                    else
                    {
                        $$.each(response.overdue_other, function( index, value ) {
                            other_html += '<div class="row call_list_div_pending link_for_details_painter" data-id="'+value.id+'">' +
                                '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                                '<p class="call_title_pending">' + value.title + '</p>' +
                                '<p class="call_painter_name_pending">' + value.painter_name + '</p>' +
                                '</div>' +
                                '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                                '<p class="call_time_pending">' + value.date + ' ' + value.meeting_time + '</p>' +
                                '<p class="call_status_pending">Pending</p>' +
                                '</div>' +
                                '</div>' +
                                '<div class="row separator"></div>';
                        });
                    }
                    $$('#overdue_painter_container_apec_total').css('display','block');
                    $$('.overdue_painter_container_apec').html(other_html);
                }
                $$('.u_hide').hide();
                $$('.painter_call_overdue').show();
                $$('.navbar').hide();
                $$('.painter_call_overdue-nav').show();
                $$('.link_for_details_painter').on('click',function () {
                    link_for_details_painter($$(this).attr('data-id'),'overdue_painter');
                });
            }
            else if(response.status='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
function call_upcoming_project_call_list()
{
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    myApp.showIndicator();
    $$('#upcoming_project_container_apec_total').css('display','none');
    $$('.upcoming_project_container_apec').html('');
    var user_info = app_data.user_info;
    var user_location = app_data.user_location;
    var url=base_url+"app/get_upcoming_call";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,user_level_id:user_info.user_level_id,user_level:user_info.user_level,cluster:user_location.cluster,call_type:'project'},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status='success')
            {
                var html='';
                if(response.upcoming.length==0)
                {
                    html+='<div class="row call_list_div_pending">' +
                        '<div class="col-100" style="text-align: center;">' +
                        '<span>No Data Found!</span>' +
                        '</div>' +
                        '</div>';
                }
                else
                {
                    $$.each(response.upcoming, function( index, value ) {
                        html+='<div class="row call_list_div_pending link_for_details_project" data-id="'+value.id+'">' +
                            '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                            '<p class="call_title_pending">'+value.title+'</p>' +
                            '<p class="call_project_name_pending">'+value.project_name+'</p>' +
                            '</div>' +
                            '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                            '<p class="call_time_pending">'+value.date+' '+value.meeting_time+'</p>' +
                            '<p class="call_status_pending">Pending</p>' +
                            '</div>' +
                            '</div>' +
                            '<div class="row separator"></div>';
                    });
                }
                $$('.upcoming_project_container').html(html);
                if((user_info.user_level!='TSI') && (user_info.user_level!='APEC'))
                {
                    var other_html='';
                    if(response.upcoming_other.length==0)
                    {
                        other_html+='<div class="row call_list_div_pending">' +
                            '<div class="col-100" style="text-align: center;">' +
                            '<span>No Data Found!</span>' +
                            '</div>' +
                            '</div>';
                    }
                    else
                    {
                        $$.each(response.upcoming_other, function( index, value ) {
                            other_html+='<div class="row call_list_div_pending link_for_details_project" data-id="'+value.id+'">' +
                                '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                                '<p class="call_title_pending">'+value.title+'</p>' +
                                '<p class="call_project_name_pending">'+value.project_name+'</p>' +
                                '</div>' +
                                '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                                '<p class="call_time_pending">'+value.date+' '+value.meeting_time+'</p>' +
                                '<p class="call_status_pending">Pending</p>' +
                                '</div>' +
                                '</div>' +
                                '<div class="row separator"></div>';
                        });
                    }
                    $$('#upcoming_project_container_apec_total').css('display','block');
                    $$('.upcoming_project_container_apec').html(other_html);
                }
                $$('.u_hide').hide();
                $$('.project_call_upcoming').show();
                $$('.navbar').hide();
                $$('.project_call_upcoming-nav').show();
                $$('.link_for_details_project').on('click',function () {
                    link_for_details_project($$(this).attr('data-id'),'upcoming_project');
                });
            }
            else if(response.status='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
function call_upcoming_painter_call_list()
{
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    myApp.showIndicator();
    $$('#upcoming_painter_container_apec_total').css('display','none');
    $$('.upcoming_painter_container_apec').html('');
    var user_info = app_data.user_info;
    var user_location = app_data.user_location;
    var url=base_url+"app/get_upcoming_call";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,user_level_id:user_info.user_level_id,user_level:user_info.user_level,cluster:user_location.cluster,call_type:'painter'},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status='success')
            {
                var html='';
                if(response.upcoming.length==0)
                {
                    html+='<div class="row call_list_div_pending">' +
                        '<div class="col-100" style="text-align: center;">' +
                        '<span>No Data Found!</span>' +
                        '</div>' +
                        '</div>';
                }
                else
                {
                    $$.each(response.upcoming, function( index, value ) {
                        html+='<div class="row call_list_div_pending link_for_details_painter" data-id="'+value.id+'">' +
                            '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                            '<p class="call_title_pending">'+value.title+'</p>' +
                            '<p class="call_project_name_pending">'+value.painter_name+'</p>' +
                            '</div>' +
                            '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                            '<p class="call_time_pending">'+value.date+' '+value.meeting_time+'</p>' +
                            '<p class="call_status_pending">Pending</p>' +
                            '</div>' +
                            '</div>' +
                            '<div class="row separator"></div>';
                    });
                }
                $$('.upcoming_painter_container').html(html);
                if((user_info.user_level!='TSI') && (user_info.user_level!='APEC'))
                {
                    var other_html='';
                    if(response.upcoming_other.length==0)
                    {
                        other_html+='<div class="row call_list_div_pending">' +
                            '<div class="col-100" style="text-align: center;">' +
                            '<span>No Data Found!</span>' +
                            '</div>' +
                            '</div>';
                    }
                    else
                    {
                        $$.each(response.upcoming_other, function( index, value ) {
                            other_html+='<div class="row call_list_div_pending link_for_details_painter" data-id="'+value.id+'">' +
                                '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                                '<p class="call_title_pending">'+value.title+'</p>' +
                                '<p class="call_project_name_pending">'+value.painter_name+'</p>' +
                                '</div>' +
                                '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                                '<p class="call_time_pending">'+value.date+' '+value.meeting_time+'</p>' +
                                '<p class="call_status_pending">Pending</p>' +
                                '</div>' +
                                '</div>' +
                                '<div class="row separator"></div>';
                        });
                    }
                    $$('#upcoming_painter_container_apec_total').css('display','block');
                    $$('.upcoming_painter_container_apec').html(other_html);
                }
                $$('.u_hide').hide();
                $$('.painter_call_upcoming').show();
                $$('.navbar').hide();
                $$('.painter_call_upcoming-nav').show();
                $$('.link_for_details_painter').on('click',function () {
                    link_for_details_painter($$(this).attr('data-id'),'upcoming_painter');
                });
            }
            else if(response.status='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
function call_completed_project_call_list()
{
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    myApp.showIndicator();
    $$('#completed_project_container_apec_total').css('display','none');
    $$('.completed_project_container_apec').html('');
    var user_info = app_data.user_info;
    var user_location = app_data.user_location;
    var url=base_url+"app/get_completed_call";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,user_level_id:user_info.user_level_id,user_level:user_info.user_level,cluster:user_location.cluster,call_type:'project'},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status='success')
            {
                var html='';
                if(response.completed.length==0)
                {
                    html+='<div class="row call_list_div_pending">' +
                        '<div class="col-100" style="text-align: center;">' +
                        '<span>No Data Found!</span>' +
                        '</div>' +
                        '</div>';
                }
                else
                {
                    $$.each(response.completed, function( index, value ) {
                        html+='<div class="row call_list_div_pending link_for_details_project" data-id="'+value.id+'">' +
                            '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                            '<p class="call_title_pending">'+value.title+'</p>' +
                            '<p class="call_project_name_pending">'+value.project_name+'</p>' +
                            '</div>' +
                            '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                            '<p class="call_time_pending">'+value.date+' '+value.meeting_time+'</p>' +
                            '<p class="call_status_pending">'+value.status+'</p>' +
                            '</div>' +
                            '</div>' +
                            '<div class="row separator"></div>';
                    });
                }
                $$('.completed_project_container').html(html);
                if((user_info.user_level!='TSI') && (user_info.user_level!='APEC'))
                {
                    var other_html='';
                    if(response.completed_other.length==0)
                    {
                        other_html+='<div class="row call_list_div_pending">' +
                            '<div class="col-100" style="text-align: center;">' +
                            '<span>No Data Found!</span>' +
                            '</div>' +
                            '</div>';
                    }
                    else
                    {
                        $$.each(response.completed_other, function( index, value ) {
                            other_html+='<div class="row call_list_div_pending link_for_details_project" data-id="'+value.id+'">' +
                                '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                                '<p class="call_title_pending">'+value.title+'</p>' +
                                '<p class="call_project_name_pending">'+value.project_name+'</p>' +
                                '</div>' +
                                '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                                '<p class="call_time_pending">'+value.date+' '+value.meeting_time+'</p>' +
                                '<p class="call_status_pending">'+value.status+'</p>' +
                                '</div>' +
                                '</div>' +
                                '<div class="row separator"></div>';
                        });
                    }
                    $$('#completed_project_container_apec_total').css('display','block');
                    $$('.completed_project_container_apec').html(other_html);
                }
                $$('.u_hide').hide();
                $$('.project_call_completed').show();
                $$('.navbar').hide();
                $$('.project_call_completed-nav').show();
                $$('.link_for_details_project').on('click',function () {
                    link_for_details_project($$(this).attr('data-id'),'completed_project');
                });
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else if(response.status='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else
            {
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
function call_completed_painter_call_list() {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    myApp.showIndicator();
    $$('#completed_painter_container_apec_total').css('display','none');
    $$('.completed_painter_container_apec').html('');
    var user_info = app_data.user_info;
    var user_location = app_data.user_location;
    var url=base_url+"app/get_completed_call";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,user_level_id:user_info.user_level_id,user_level:user_info.user_level,cluster:user_location.cluster,call_type:'painter'},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status='success')
            {
                var html='';
                if(response.completed.length==0)
                {
                    html+='<div class="row call_list_div_pending">' +
                        '<div class="col-100" style="text-align: center;">' +
                        '<span>No Data Found!</span>' +
                        '</div>' +
                        '</div>';
                }
                else
                {
                    $$.each(response.completed, function( index, value ) {
                        html+='<div class="row call_list_div_pending link_for_details_painter" data-id="'+value.id+'">' +
                            '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                            '<p class="call_title_pending">'+value.title+'</p>' +
                            '<p class="call_painter_name_pending">'+value.painter_name+'</p>' +
                            '</div>' +
                            '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                            '<p class="call_time_pending">'+value.date+' '+value.meeting_time+'</p>' +
                            '<p class="call_status_pending">'+value.status+'</p>' +
                            '</div>' +
                            '</div>' +
                            '<div class="row separator"></div>';
                    });
                }
                $$('.completed_painter_container').html(html);
                if((user_info.user_level!='TSI') && (user_info.user_level!='APEC'))
                {
                    var other_html='';
                    if(response.completed_other.length==0)
                    {
                        other_html+='<div class="row call_list_div_pending">' +
                            '<div class="col-100" style="text-align: center;">' +
                            '<span>No Data Found!</span>' +
                            '</div>' +
                            '</div>';
                    }
                    else
                    {
                        $$.each(response.completed_other, function( index, value ) {
                            other_html+='<div class="row call_list_div_pending link_for_details_painter" data-id="'+value.id+'">' +
                                '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                                '<p class="call_title_pending">'+value.title+'</p>' +
                                '<p class="call_painter_name_pending">'+value.painter_name+'</p>' +
                                '</div>' +
                                '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                                '<p class="call_time_pending">'+value.date+' '+value.meeting_time+'</p>' +
                                '<p class="call_status_pending">'+value.status+'</p>' +
                                '</div>' +
                                '</div>' +
                                '<div class="row separator"></div>';
                        });
                    }
                    $$('#completed_painter_container_apec_total').css('display','block');
                    $$('.completed_painter_container_apec').html(other_html);
                }
                $$('.u_hide').hide();
                $$('.painter_call_completed').show();
                $$('.navbar').hide();
                $$('.painter_call_completed-nav').show();
                $$('.link_for_details_painter').on('click',function () {
                    link_for_details_painter($$(this).attr('data-id'),'completed_painter');
                });
            }
            else if(response.status='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
function call_today_project_call_list() {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    myApp.showIndicator();
    $$('#today_project_container_apec_total').css('display','none');
    $$('.today_project_container_apec').html('');
    $$('#finish_button_project_call').attr('data-id','');
    $$('.time_start_call_project').attr('data-time-int','');
    $$('.time_start_call_project').attr('data-time-string','');
    var user_info = app_data.user_info;
    var user_location = app_data.user_location;
    var url=base_url+"app/get_today_call";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,user_level_id:user_info.user_level_id,user_level:user_info.user_level,cluster:user_location.cluster,call_type:'project'},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status='success')
            {
                var html='';
                if(response.today.length==0)
                {
                    html+='<div class="row call_list_div_pending">' +
                        '<div class="col-100" style="text-align: center;">' +
                        '<span>No Data Found!</span>' +
                        '</div>' +
                        '</div>';
                }
                else
                {
                    $$.each(response.today, function( index, value ) {

                        if(value.status=='Active')
                        {
                            html += '<div class="row call_list_div_pending link_for_finish_call_project" data-id="'+value.id+'">' +
                                '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                                '<p class="call_title_pending">' + value.title + '</p>' +
                                '<p class="call_project_name_pending">' + value.project_name + '</p>' +
                                '</div>' +
                                '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                                '<p class="call_time_pending">' + value.date + ' ' + value.meeting_time + '</p>' +
                                '<p class="call_status_pending">Pending</p>' +
                                '</div>' +
                                '</div>' +
                                '<div class="row separator"></div>';
                        }
                        else if(value.status=='Completed')
                        {
                            html += '<div class="row call_list_div_completed link_for_details_project" data-id="'+value.id+'">' +
                                '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                                '<p class="call_title_completed">' + value.title + '</p>' +
                                '<p class="call_project_name_completed">' + value.project_name + '</p>' +
                                '</div>' +
                                '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                                '<p class="call_time_completed">' + value.date + ' ' + value.meeting_time + '</p>' +
                                '<p class="call_status_completed">Completed</p>' +
                                '</div>' +
                                '</div>' +
                                '<div class="row separator"></div>';
                        }
                    });
                }
                $$('.today_project_container').html(html);
                if((user_info.user_level!='TSI') && (user_info.user_level!='APEC'))
                {
                    var other_html='';
                    if(response.today_other.length==0)
                    {
                        other_html+='<div class="row call_list_div_pending">' +
                            '<div class="col-100" style="text-align: center;">' +
                            '<span>No Data Found!</span>' +
                            '</div>' +
                            '</div>';
                    }
                    else
                    {
                        $$.each(response.today_other, function( index, value ) {
                            if(value.status=='Active')
                            {
                                other_html += '<div class="row call_list_div_pending" data-id="'+value.id+'">' +
                                    '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                                    '<p class="call_title_pending">' + value.title + '</p>' +
                                    '<p class="call_project_name_pending">' + value.project_name + '</p>' +
                                    '</div>' +
                                    '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                                    '<p class="call_time_pending">' + value.date + ' ' + value.meeting_time + '</p>' +
                                    '<p class="call_status_pending">Pending</p>' +
                                    '</div>' +
                                    '</div>' +
                                    '<div class="row separator"></div>';
                            }
                            else if(value.status=='Completed')
                            {
                                other_html += '<div class="row call_list_div_completed" data-id="'+value.id+'">' +
                                    '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                                    '<p class="call_title_completed">' + value.title + '</p>' +
                                    '<p class="call_project_name_completed">' + value.project_name + '</p>' +
                                    '</div>' +
                                    '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                                    '<p class="call_time_completed">' + value.date + ' ' + value.meeting_time + '</p>' +
                                    '<p class="call_status_completed">Completed</p>' +
                                    '</div>' +
                                    '</div>' +
                                    '<div class="row separator"></div>';
                            }
                        });
                    }
                    $$('#today_project_container_apec_total').css('display','block');
                    $$('.today_project_container_apec').html(other_html);
                }
                $$('.u_hide').hide();
                $$('.project_call_today').show();
                $$('.navbar').hide();
                $$('.project_call_today-nav').show();
                $$('.link_for_details_project').on('click',function () {
                    link_for_details_project($$(this).attr('data-id'),'today_project');
                });
                $$('.link_for_finish_call_project').on('click',function () {
                    link_for_finish_call_project($$(this).attr('data-id'),'today_project');
                });
            }
            else if(response.status='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
function call_today_painter_call_list() {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    myApp.showIndicator();
    $$('#today_painter_container_apec_total').css('display','none');
    $$('.today_painter_container_apec').html('');
    $$('#finish_button_painter_call').attr('data-id','');
    $$('.time_start_call_painter').attr('data-time-int','');
    $$('.time_start_call_painter').attr('data-time-string','');
    var user_info = app_data.user_info;
    var user_location = app_data.user_location;
    var url=base_url+"app/get_today_call";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,user_level_id:user_info.user_level_id,user_level:user_info.user_level,cluster:user_location.cluster,call_type:'painter'},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status='success')
            {
                var html='';
                if(response.today.length==0)
                {
                    html+='<div class="row call_list_div_pending">' +
                        '<div class="col-100" style="text-align: center;">' +
                        '<span>No Data Found!</span>' +
                        '</div>' +
                        '</div>';
                }
                else
                {
                    $$.each(response.today, function( index, value ) {
                        if(value.status=='Active')
                        {
                            html += '<div class="row call_list_div_pending link_for_finish_call_painter" data-id="'+value.id+'">' +
                                '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                                '<p class="call_title_pending">' + value.title + '</p>' +
                                '<p class="call_painter_name_pending">' + value.painter_name + '</p>' +
                                '</div>' +
                                '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                                '<p class="call_time_pending">' + value.date + ' ' + value.meeting_time + '</p>' +
                                '<p class="call_status_pending">Pending</p>' +
                                '</div>' +
                                '</div>' +
                                '<div class="row separator"></div>';
                        }
                        else if(value.status=='Completed')
                        {
                            html += '<div class="row call_list_div_completed link_for_details_painter" data-id="'+value.id+'">' +
                                '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                                '<p class="call_title_completed">' + value.title + '</p>' +
                                '<p class="call_painter_name_completed">' + value.painter_name + '</p>' +
                                '</div>' +
                                '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                                '<p class="call_time_completed">' + value.date + ' ' + value.meeting_time + '</p>' +
                                '<p class="call_status_completed">Completed</p>' +
                                '</div>' +
                                '</div>' +
                                '<div class="row separator"></div>';
                        }
                    });
                }
                $$('.today_painter_container').html(html);
                if((user_info.user_level!='TSI') && (user_info.user_level!='APEC'))
                {
                    var other_html='';
                    if(response.today_other.length==0)
                    {
                        other_html+='<div class="row call_list_div_pending">' +
                            '<div class="col-100" style="text-align: center;">' +
                            '<span>No Data Found!</span>' +
                            '</div>' +
                            '</div>';
                    }
                    else
                    {
                        $$.each(response.today_other, function( index, value ) {
                            if(value.status=='Active')
                            {
                                other_html += '<div class="row call_list_div_pending" data-id="'+value.id+'">' +
                                    '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                                    '<p class="call_title_pending">' + value.title + '</p>' +
                                    '<p class="call_painter_name_pending">' + value.painter_name + '</p>' +
                                    '</div>' +
                                    '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                                    '<p class="call_time_pending">' + value.date + ' ' + value.meeting_time + '</p>' +
                                    '<p class="call_status_pending">Pending</p>' +
                                    '</div>' +
                                    '</div>' +
                                    '<div class="row separator"></div>';
                            }
                            else if(value.status=='Completed')
                            {
                                other_html += '<div class="row call_list_div_completed" data-id="'+value.id+'">' +
                                    '<div class="col-66" style="text-align: left;margin-top: 3%;">' +
                                    '<p class="call_title_completed">' + value.title + '</p>' +
                                    '<p class="call_painter_name_completed">' + value.painter_name + '</p>' +
                                    '</div>' +
                                    '<div class="col-34" style="text-align: right;margin-top: 3%;">' +
                                    '<p class="call_time_completed">' + value.date + ' ' + value.meeting_time + '</p>' +
                                    '<p class="call_status_completed">Completed</p>' +
                                    '</div>' +
                                    '</div>' +
                                    '<div class="row separator"></div>';
                            }
                        });
                    }
                    $$('#today_painter_container_apec_total').css('display','block');
                    $$('.today_painter_container_apec').html(other_html);
                }
                $$('.u_hide').hide();
                $$('.painter_call_today').show();
                $$('.navbar').hide();
                $$('.painter_call_today-nav').show();
                $$('.link_for_details_painter').on('click',function () {
                    link_for_details_painter($$(this).attr('data-id'),'today_painter');
                });
                $$('.link_for_finish_call_painter').on('click',function () {
                    link_for_finish_call_painter($$(this).attr('data-id'),'today_painter');
                });
            }
            else if(response.status='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
$$('.overdue_project_card').on('click',function () {
    call_overdue_project_call_list();
});
$$('.today_project_card').on('click',function () {
    call_today_project_call_list();
});
$$('.upcoming_project_card').on('click',function () {
    call_upcoming_project_call_list();
});
$$('.completed_project_card').on('click',function () {
    call_completed_project_call_list();
});
$$('.overdue_painter_card').on('click',function () {
    call_overdue_painter_call_list();
});
$$('.upcoming_painter_card').on('click',function () {
    call_upcoming_painter_call_list();
});
$$('.completed_painter_card').on('click',function () {
    call_completed_painter_call_list();
});
$$('.today_painter_card').on('click',function () {
    call_today_painter_call_list();
});
function link_for_details_project(data_id,data_for) {
    $$('.action_project_call_overdue').hide();
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    myApp.showIndicator();
    var call_id=data_id;
    var user_info = app_data.user_info;
    var url=base_url+"app/get_call_details";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,call_type:'project',call_id:call_id},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            $$('.finish_now_project_call').attr('data-id','');
            $$('.finish_now_project_call').attr('data-for','');
            $$('.cancel_now_project_call').attr('data-id','');
            $$('.cancel_now_project_call').attr('data-for','');
            var response= JSON.parse(data);
            if(response.status='success')
            {
                var repeat_status;
                var status;
                if(response.call_details.repeat_status=='1')
                {
                    repeat_status='Not Repeated';
                }
                else
                {
                    repeat_status='Repeated';
                }
                if(response.call_details.status=='Active')
                {
                    status='Pending';
                }
                else
                {
                    status=response.call_details.status;
                }
                $$('.appointment_title_project').html(response.call_details.title);
                $$('.project_name_project').html(response.call_details.project_name);
                $$('.job_status_project').html(status);
                $$('.appointment_date_project').html(response.call_details.date);
                $$('.appointment_time_project').html(response.call_details.meeting_time);
                $$('.appointment_repeat_status_project').html(repeat_status);
                $$('.appointment_before_remarks_project').html(response.call_details.before_remarks);
                if(data_for=='overdue_project')
                {
                    if(user_info.user_id==response.call_details.created_by)
                    {
                        $$('.finish_now_project_call').attr('data-id',response.call_details.id);
                        $$('.finish_now_project_call').attr('data-for',data_for);
                        $$('.cancel_now_project_call').attr('data-id',response.call_details.id);
                        $$('.cancel_now_project_call').attr('data-for',data_for);
                        $$('.action_project_call_overdue').css('display','flex');
                    }
                    $$('.u_hide').hide();
                    $$('.project_call_overdue_details').show();
                    $$('.navbar').hide();
                    $$('.overdue_project_list_details-nav').show();
                }
                else if(data_for=='today_project')
                {
                    $$('#geo_location_project_call').html('');
                    $$('.appointment_after_remarks_project').html(response.call_details.after_remarks);
                    $$('.check_in_project_call').html(response.call_details.check_in_time);
                    $$('.check_out_project_call').html(response.call_details.check_out_time);
                    var iLat =parseFloat(response.call_details.latitude);
                    var iLong=parseFloat(response.call_details.longitude);
                    var myLatLng = {lat: iLat, lng: iLong};
                    var iMap = document.getElementById('geo_location_project_call');
                    iMap.style.height = "100px";
                    var map = new google.maps.Map(document.getElementById('geo_location_project_call'), {
                        zoom: 15,
                        center: myLatLng,
                        disableDefaultUI: true
                    });
                    var marker = new google.maps.Marker({
                        position: myLatLng,
                        map: map
                    });
                    $$('.u_hide').hide();
                    $$('.project_call_today_details').show();
                    $$('.navbar').hide();
                    $$('.today_project_list_details-nav').show();
                }
                else if(data_for=='upcoming_project')
                {
                    $$('.u_hide').hide();
                    $$('.project_call_upcoming_details').show();
                    $$('.navbar').hide();
                    $$('.upcoming_project_list_details-nav').show();
                }
                else
                {
                    $$('#geo_location_completed_project_call').html('');
                    $$('.appointment_after_remarks_project').html(response.call_details.after_remarks);
                    $$('.check_in_project_call').html(response.call_details.check_in_time);
                    $$('.check_out_project_call').html(response.call_details.check_out_time);
                    var iLat =parseFloat(response.call_details.latitude);
                    var iLong=parseFloat(response.call_details.longitude);
                    var myLatLng = {lat: iLat, lng: iLong};
                    var iMap = document.getElementById('geo_location_completed_project_call');
                    iMap.style.height = "100px";
                    var map = new google.maps.Map(document.getElementById('geo_location_completed_project_call'), {
                        zoom: 15,
                        center: myLatLng,
                        disableDefaultUI: true
                    });
                    var marker = new google.maps.Marker({
                        position: myLatLng,
                        map: map
                    });
                    $$('.u_hide').hide();
                    $$('.project_call_completed_details').show();
                    $$('.navbar').hide();
                    $$('.completed_project_list_details-nav').show();
                }
                $$('.finish_now_project_call').on('click',function (event) {
                    if(check_action_status())
                    {
                        link_for_finish_call_project($$(this).attr('data-id'),$$(this).attr('data-for'));
                    }
                });
                $$('.cancel_now_project_call').on('click',function () {
                    if(check_action_status())
                    {
                        if(confirm('Are you sure to cancel this call?'))
                        {
                            if(!checkConnection())
                            {
                                alert('No internet connection!');
                                return;
                            }
                            myApp.showIndicator();
                            var user_info = app_data.user_info;
                            var url=base_url+"app/cancel_project_call";
                            var new_data={};
                            if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
                            {
                                new_data['today_date']=window.localStorage["today_date"];
                            }
                            else
                            {
                                new_data['today_date']='';
                            }
                            new_data['app_version']=$$('.version').html();
                            $$.ajax({
                                url: url,
                                type: "POST",
                                datatype:'json',
                                data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,id:$$(this).attr('data-id')},
                                //timeout: 15000,
                                cache: false,
                                success: function(data){
                                    myApp.hideIndicator();
                                    var response= JSON.parse(data);
                                    if(response.status='success')
                                    {
                                        alert('Cancelled Successfully!');
                                        call_overdue_project_call_list();
                                    }
                                    else if(response.status='unauthorized')
                                    {
                                        alert('Unauthorized Action Found!');
                                        logout();
                                    }
                                    else if(response.status == "time_over")
                                    {
                                        __timeOver();
                                    }
                                    else if(response.status == "deprecated")
                                    {
                                        __deprecated();
                                    }
                                    else
                                    {
                                        alert('Operation Failed. Please try again!');
                                    }
                                },
                                error: function (e) {
                                    myApp.hideIndicator();
                                    alert('There was a problem connecting to the server.Please try again.');
                                }
                            });
                        }
                    }
                });
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else if(response.status='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else
            {
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
function link_for_details_painter(data_id,data_for) {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    myApp.showIndicator();
    var call_id=data_id;
    var user_info = app_data.user_info;
    var url=base_url+"app/get_call_details";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,call_type:'painter',call_id:call_id},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            $$('.finish_now_painter_call').attr('data-id','');
            $$('.finish_now_painter_call').attr('data-for','');
            $$('.cancel_now_painter_call').attr('data-id','');
            $$('.cancel_now_painter_call').attr('data-for','');
            var response= JSON.parse(data);
            if(response.status='success')
            {
                var repeat_status;
                var status;
                if(response.call_details.repeat_status=='1')
                {
                    repeat_status='Not Repeated';
                }
                else
                {
                    repeat_status='Repeated';
                }
                if(response.call_details.status=='Active')
                {
                    status='Pending';
                }
                else
                {
                    status=response.call_details.status;
                }
                $$('.appointment_title_project').html(response.call_details.title);
                $$('.project_name_project').html(response.call_details.painter_name);
                $$('.job_status_project').html(status);
                $$('.appointment_date_project').html(response.call_details.date);
                $$('.appointment_time_project').html(response.call_details.meeting_time);
                $$('.appointment_repeat_status_project').html(repeat_status);
                $$('.appointment_before_remarks_project').html(response.call_details.before_remarks);
                if(data_for=='overdue_painter')
                {
                    if(user_info.user_id==response.call_details.created_by)
                    {
                        $$('.finish_now_painter_call').attr('data-id',response.call_details.id);
                        $$('.finish_now_painter_call').attr('data-for',data_for);
                        $$('.cancel_now_painter_call').attr('data-id',response.call_details.id);
                        $$('.cancel_now_painter_call').attr('data-for',data_for);
                        $$('.action_painter_call_overdue').css('display','flex');
                    }
                    $$('.u_hide').hide();
                    $$('.painter_call_overdue_details').show();
                    $$('.navbar').hide();
                    $$('.overdue_painter_list_details-nav').show();
                }
                else if(data_for=='today_painter')
                {
                    $$('#geo_location_painter_call').html('');
                    $$('.appointment_after_remarks_project').html(response.call_details.after_remarks);
                    $$('.check_in_project_call').html(response.call_details.check_in_time);
                    $$('.check_out_project_call').html(response.call_details.check_out_time);

                    var iLat =parseFloat(response.call_details.latitude);
                    var iLong=parseFloat(response.call_details.longitude);
                    var myLatLng = {lat: iLat, lng: iLong};
                    var iMap = document.getElementById('geo_location_painter_call');
                    iMap.style.height = "100px";
                    var map = new google.maps.Map(document.getElementById('geo_location_painter_call'), {
                        zoom: 15,
                        center: myLatLng,
                        disableDefaultUI: true
                    });
                    var marker = new google.maps.Marker({
                        position: myLatLng,
                        map: map
                    });

                    $$('.u_hide').hide();
                    $$('.painter_call_today_details').show();
                    $$('.navbar').hide();
                    $$('.today_painter_list_details-nav').show();
                }
                else if(data_for=='upcoming_painter')
                {
                    $$('.u_hide').hide();
                    $$('.painter_call_upcoming_details').show();
                    $$('.navbar').hide();
                    $$('.upcoming_painter_list_details-nav').show();
                }
                else
                {
                    $$('#geo_location_completed_painter_call').html('');
                    $$('.appointment_after_remarks_project').html(response.call_details.after_remarks);
                    $$('.check_in_project_call').html(response.call_details.check_in_time);
                    $$('.check_out_project_call').html(response.call_details.check_out_time);
                    var iLat =parseFloat(response.call_details.latitude);
                    var iLong=parseFloat(response.call_details.longitude);
                    var myLatLng = {lat: iLat, lng: iLong};
                    var iMap = document.getElementById('geo_location_completed_painter_call');
                    iMap.style.height = "100px";
                    var map = new google.maps.Map(document.getElementById('geo_location_completed_painter_call'), {
                        zoom: 15,
                        center: myLatLng,
                        disableDefaultUI: true
                    });
                    var marker = new google.maps.Marker({
                        position: myLatLng,
                        map: map
                    });
                    $$('.u_hide').hide();
                    $$('.painter_call_completed_details').show();
                    $$('.navbar').hide();
                    $$('.completed_painter_list_details-nav').show();
                }
                $$('.finish_now_painter_call').on('click',function () {
                    if(check_action_status())
                    {
                        link_for_finish_call_painter($$(this).attr('data-id'),$$(this).attr('data-for'));
                    }
                });
                $$('.cancel_now_painter_call').on('click',function () {
                    if(check_action_status())
                    {
                        if(confirm('Are you sure to cancel this call?'))
                        {
                            if(!checkConnection())
                            {
                                alert('No internet connection!');
                                return;
                            }
                            myApp.showIndicator();
                            var user_info = app_data.user_info;
                            var url=base_url+"app/cancel_painter_call";
                            var new_data={};
                            if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
                            {
                                new_data['today_date']=window.localStorage["today_date"];
                            }
                            else
                            {
                                new_data['today_date']='';
                            }
                            new_data['app_version']=$$('.version').html();
                            $$.ajax({
                                url: url,
                                type: "POST",
                                datatype:'json',
                                data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,id:$$(this).attr('data-id')},
                                //timeout: 15000,
                                cache: false,
                                success: function(data){
                                    myApp.hideIndicator();
                                    var response= JSON.parse(data);
                                    if(response.status='success')
                                    {
                                        alert('Cancelled Successfully!');
                                        call_overdue_painter_call_list();
                                    }
                                    else if(response.status='unauthorized')
                                    {
                                        alert('Unauthorized Action Found!');
                                        logout();
                                    }
                                    else if(response.status == "time_over")
                                    {
                                        __timeOver();
                                    }
                                    else if(response.status == "deprecated")
                                    {
                                        __deprecated();
                                    }
                                    else
                                    {
                                        alert('Operation Failed. Please try again!');
                                    }
                                },
                                error: function (e) {
                                    myApp.hideIndicator();
                                    alert('There was a problem connecting to the server.Please try again.');
                                }
                            });
                        }
                    }
                });
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else if(response.status='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else
            {
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
function link_for_finish_call_project(data_id,data_for) {
    if(check_action_status())
    {
        if(!checkConnection())
        {
            alert('No internet connection!');
            return;
        }
        myApp.showIndicator();
        $$('.start_button_project').attr('data-id','');
        $$('.start_button_project').attr('data-for','');
        var call_id=data_id;
        var user_info = app_data.user_info;
        var url=base_url+"app/get_call_details";
        var new_data={};
        if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
        {
            new_data['today_date']=window.localStorage["today_date"];
        }
        else
        {
            new_data['today_date']='';
        }
        new_data['app_version']=$$('.version').html();
        $$.ajax({
            url: url,
            type: "POST",
            datatype:'json',
            data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,call_type:'project',call_id:call_id},
            //timeout: 15000,
            cache: false,
            success: function(data){
                myApp.hideIndicator();
                var response= JSON.parse(data);
                if(response.status='success')
                {
                    $$('.title_start_call_project').html(response.call_details.title);
                    $$('.project_name_start_call_project').html(response.call_details.project_name);
                    $$('.time_start_call_project').html(response.start_time_string);
                    $$('.time_start_call_project').attr('data-time-int',response.start_time_int);
                    $$('.time_start_call_project').attr('data-time-string',response.start_time_string);
                    $$('.start_button_project').attr('data-id',call_id);
                    $$('.start_button_project').attr('data-for',data_for);
                    myApp.popup('.popup_start_project');
                    $$('.popup_start_project').attr('style','display: block !important');
                    $$('.popup_start_project').attr('style','display: block !important');
                    $$('.modal-in').attr('style','display: block !important');
                    $$('.page-content').attr('style','opacity: 40%;background-color: #eee;');
                    $$('.popup-overlay').addClass('modal-overlay-visible');
                }
                else if(response.status='unauthorized')
                {
                    $$('#finish_button_project_call').attr('data-id','');
                    $$('#finish_button_project_call').attr('data-type','');
                    $$('.time_start_call_project').attr('data-time-int','');
                    $$('.time_start_call_project').attr('data-time-string','');
                    alert('Unauthorized Action Found!');
                    logout();
                }
                else if(response.status == "time_over")
                {
                    $$('#finish_button_project_call').attr('data-id','');
                    $$('#finish_button_project_call').attr('data-type','');
                    $$('.time_start_call_project').attr('data-time-int','');
                    $$('.time_start_call_project').attr('data-time-string','');
                    __timeOver();
                }
                else if(response.status == "deprecated")
                {
                    $$('#finish_button_project_call').attr('data-id','');
                    $$('#finish_button_project_call').attr('data-type','');
                    $$('.time_start_call_project').attr('data-time-int','');
                    $$('.time_start_call_project').attr('data-time-string','');
                    __deprecated();
                }
                else
                {
                    $$('#finish_button_project_call').attr('data-id','');
                    $$('#finish_button_project_call').attr('data-type','');
                    $$('.time_start_call_project').attr('data-time-int','');
                    $$('.time_start_call_project').attr('data-time-string','');
                    alert('Operation Failed. Please try again!');
                }
            },
            error: function (e) {
                myApp.hideIndicator();
                $$('#finish_button_project_call').attr('data-id','');
                $$('#finish_button_project_call').attr('data-type','');
                $$('.time_start_call_project').attr('data-time-int','');
                $$('.time_start_call_project').attr('data-time-string','');
                alert('There was a problem connecting to the server.Please try again.');
            }
        });
    }
}
function link_for_finish_call_painter(data_id,data_for) {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    myApp.showIndicator();
    $$('.start_button_painter').attr('data-id','');
    $$('.start_button_painter').attr('data-for','');
    var call_id=data_id;
    var user_info = app_data.user_info;
    var url=base_url+"app/get_call_details";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,call_type:'painter',call_id:call_id},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status='success')
            {
                $$('.title_start_call_painter').html(response.call_details.title);
                $$('.painter_name_start_call_painter').html(response.call_details.painter_name);
                $$('.time_start_call_painter').html(response.start_time_string);
                $$('.time_start_call_painter').attr('data-time-int',response.start_time_int);
                $$('.time_start_call_painter').attr('data-time-string',response.start_time_string);
                $$('.start_button_painter').attr('data-id',call_id);
                $$('.start_button_painter').attr('data-for',data_for);
                myApp.popup('.popup_start_painter');
                $$('.popup_start_painter').attr('style','display: block !important');
                $$('.popup_start_painter').attr('style','display: block !important');
                $$('.modal-in').attr('style','display: block !important');
                $$('.page-content').attr('style','opacity: 40%;background-color: #eee;');
                $$('.popup-overlay').addClass('modal-overlay-visible');
            }
            else if(response.status='unauthorized')
            {
                $$('#finish_button_painter_call').attr('data-id','');
                $$('#finish_button_painter_call').attr('data-type','');
                $$('.time_start_call_painter').attr('data-time-int','');
                $$('.time_start_call_painter').attr('data-time-string','');
                alert('Unauthorized Action Found!');
                logout();
            }
            else if(response.status == "time_over")
            {
                $$('#finish_button_painter_call').attr('data-id','');
                $$('#finish_button_painter_call').attr('data-type','');
                $$('.time_start_call_painter').attr('data-time-int','');
                $$('.time_start_call_painter').attr('data-time-string','');
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                $$('#finish_button_painter_call').attr('data-id','');
                $$('#finish_button_painter_call').attr('data-type','');
                $$('.time_start_call_painter').attr('data-time-int','');
                $$('.time_start_call_painter').attr('data-time-string','');
                __deprecated();
            }
            else
            {
                $$('#finish_button_painter_call').attr('data-id','');
                $$('#finish_button_painter_call').attr('data-type','');
                $$('.time_start_call_painter').attr('data-time-int','');
                $$('.time_start_call_painter').attr('data-time-string','');
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            $$('#finish_button_project_call').attr('data-id','');
            $$('#finish_button_project_call').attr('data-type','');
            $$('.time_start_call_project').attr('data-time-int','');
            $$('.time_start_call_project').attr('data-time-string','');
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
$$('.close_modal_icon').on('click', function (e) {
    $$('.page-content').removeAttr('style','opacity: 40%;background-color: #eee;');
    myApp.closePanel();
    $$('.popup-overlay').removeClass('modal-overlay-visible');
    myApp.closeModal('.popup_start_project');
});
$$('.close_modal_icon_painter').on('click', function (e) {
    $$('.page-content').removeAttr('style','opacity: 40%;background-color: #eee;');
    myApp.closePanel();
    $$('.popup-overlay').removeClass('modal-overlay-visible');
    myApp.closeModal('.popup_start_painter');
});
$$('.start_button_project').on('click', function (e) {
    if($$(this).attr('data-id')!='' && $$(this).attr('data-for')!='' && $$('.time_start_call_project').attr('data-time')!='')
    {
        if(!checkConnection())
        {
            alert('No internet connection!');
            return;
        }
        myApp.showIndicator();
        $$('#remarks_follow_up_project').val('');
        $$('.page-content').removeAttr('style','opacity: 40%;background-color: #eee;');
        myApp.closePanel();
        $$('.popup-overlay').removeClass('modal-overlay-visible');
        myApp.closeModal('.popup_start_project');
        var call_id=$$(this).attr('data-id');
        var call_type=$$(this).attr('data-for');
        var user_info = app_data.user_info;
        var url=base_url+"app/get_call_details";
        var new_data={};
        if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
        {
            new_data['today_date']=window.localStorage["today_date"];
        }
        else
        {
            new_data['today_date']='';
        }
        new_data['app_version']=$$('.version').html();
        $$.ajax({
            url: url,
            type: "POST",
            datatype:'json',
            data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,call_type:'project',call_id:call_id},
            //timeout: 15000,
            cache: false,
            success: function(data){
                myApp.hideIndicator();
                var response= JSON.parse(data);
                if(response.status='success')
                {
                    $$('#finish_button_project_call').attr('data-id',response.call_details.id);
                    $$('#finish_button_project_call').attr('data-type',call_type);
                    var start_time_int=$$('.time_start_call_project').attr('data-time-int');
                    var start_time_string=$$('.time_start_call_project').attr('data-time-string');
                    var start_date=response.start_date;
                    $$('.finish_project_name').html(response.call_details.project_name);
                    $$('.finish_call_title').html(response.call_details.title);
                    $$('.finish_call_time').html(response.call_details.date+' '+response.call_details.meeting_time);
                    $$('.finish_check_in_time').html(start_date+' '+start_time_string);
                    $$('.u_hide').hide();
                    $$('.project_call_finish').show();
                    $$('.navbar').hide();
                    $$('.project_call_finish-nav').show();
                }
                else if(response.status='unauthorized')
                {
                    $$('#finish_button_project_call').attr('data-id','');
                    $$('#finish_button_project_call').attr('data-type','');
                    $$('.time_start_call_project').attr('data-time-int','');
                    $$('.time_start_call_project').attr('data-time-string','');
                    alert('Unauthorized Action Found!');
                    logout();
                }
                else if(response.status == "time_over")
                {
                    $$('#finish_button_project_call').attr('data-id','');
                    $$('#finish_button_project_call').attr('data-type','');
                    $$('.time_start_call_project').attr('data-time-int','');
                    $$('.time_start_call_project').attr('data-time-string','');
                    __timeOver();
                }
                else if(response.status == "deprecated")
                {
                    $$('#finish_button_project_call').attr('data-id','');
                    $$('#finish_button_project_call').attr('data-type','');
                    $$('.time_start_call_project').attr('data-time-int','');
                    $$('.time_start_call_project').attr('data-time-string','');
                    __deprecated();
                }
                else
                {
                    $$('#finish_button_project_call').attr('data-type','');
                    $$('#finish_button_project_call').attr('data-id','');
                    $$('.time_start_call_project').attr('data-time-int','');
                    $$('.time_start_call_project').attr('data-time-string','');
                    alert('Operation Failed. Please try again!');
                }
            },
            error: function (e) {
                myApp.hideIndicator();
                $$('#finish_button_project_call').attr('data-id','');
                $$('#finish_button_project_call').attr('data-type','');
                $$('.time_start_call_project').attr('data-time-int','');
                $$('.time_start_call_project').attr('data-time-string','');
                alert('There was a problem connecting to the server.Please try again.');
            }
        });
    }
    else
    {
        alert('Please Try Again!');
        $$('#finish_button_project_call').attr('data-id','');
        $$('.time_start_call_project').attr('data-time-int','');
        $$('.time_start_call_project').attr('data-time-string','');
    }
});
$$('.start_button_painter').on('click', function (e) {
    if($$(this).attr('data-id')!='' && $$(this).attr('data-for')!='' && $$('.time_start_call_painter').attr('data-time')!='')
    {
        if(!checkConnection())
        {
            alert('No internet connection!');
            return;
        }
        myApp.showIndicator();
        $$('#remarks_follow_up_painter').val('');
        $$('.page-content').removeAttr('style','opacity: 40%;background-color: #eee;');
        myApp.closePanel();
        $$('.popup-overlay').removeClass('modal-overlay-visible');
        myApp.closeModal('.popup_start_painter');
        var call_id=$$(this).attr('data-id');
        var call_type=$$(this).attr('data-for');
        var user_info = app_data.user_info;
        var url=base_url+"app/get_call_details";
        var new_data={};
        if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
        {
            new_data['today_date']=window.localStorage["today_date"];
        }
        else
        {
            new_data['today_date']='';
        }
        new_data['app_version']=$$('.version').html();
        $$.ajax({
            url: url,
            type: "POST",
            datatype:'json',
            data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,call_type:'painter',call_id:call_id},
            //timeout: 15000,
            cache: false,
            success: function(data){
                myApp.hideIndicator();
                var response= JSON.parse(data);
                if(response.status='success')
                {
                    $$('#finish_button_painter_call').attr('data-id',response.call_details.id);
                    $$('#finish_button_painter_call').attr('data-type',call_type);
                    var start_time_int=$$('.time_start_call_painter').attr('data-time-int');
                    var start_time_string=$$('.time_start_call_painter').attr('data-time-string');
                    var start_date=response.start_date;
                    $$('.finish_painter_name').html(response.call_details.painter_name);
                    $$('.finish_call_title').html(response.call_details.title);
                    $$('.finish_call_time').html(response.call_details.date+' '+response.call_details.meeting_time);
                    $$('.finish_check_in_time').html(start_date+' '+start_time_string);
                    $$('.u_hide').hide();
                    $$('.painter_call_finish').show();
                    $$('.navbar').hide();
                    $$('.painter_call_finish-nav').show();
                }
                else if(response.status='unauthorized')
                {
                    $$('#finish_button_painter_call').attr('data-id','');
                    $$('#finish_button_painter_call').attr('data-type','');
                    $$('.time_start_call_painter').attr('data-time-int','');
                    $$('.time_start_call_painter').attr('data-time-string','');
                    alert('Unauthorized Action Found!');
                    logout();
                }
                else if(response.status == "time_over")
                {
                    $$('#finish_button_painter_call').attr('data-id','');
                    $$('#finish_button_painter_call').attr('data-type','');
                    $$('.time_start_call_painter').attr('data-time-int','');
                    $$('.time_start_call_painter').attr('data-time-string','');
                    __timeOver();
                }
                else if(response.status == "deprecated")
                {
                    $$('#finish_button_painter_call').attr('data-id','');
                    $$('#finish_button_painter_call').attr('data-type','');
                    $$('.time_start_call_painter').attr('data-time-int','');
                    $$('.time_start_call_painter').attr('data-time-string','');
                    __deprecated();
                }
                else
                {
                    $$('#finish_button_painter_call').attr('data-type','');
                    $$('#finish_button_painter_call').attr('data-id','');
                    $$('.time_start_call_painter').attr('data-time-int','');
                    $$('.time_start_call_painter').attr('data-time-string','');
                    alert('Operation Failed. Please try again!');
                }
            },
            error: function (e) {
                myApp.hideIndicator();
                $$('#finish_button_painter_call').attr('data-id','');
                $$('#finish_button_painter_call').attr('data-type','');
                $$('.time_start_call_painter').attr('data-time-int','');
                $$('.time_start_call_painter').attr('data-time-string','');
                alert('There was a problem connecting to the server.Please try again.');
            }
        });
    }
    else
    {
        alert('Please Try Again!');
        $$('#finish_button_painter_call').attr('data-id','');
        $$('.time_start_call_painter').attr('data-time-int','');
        $$('.time_start_call_painter').attr('data-time-string','');
    }
});
$$('#project_call_create_today_finish').on('click',function () {
    if(confirm("Sure to go back?"))
    {
        $$('#finish_button_project_call').attr('data-id','');
        $$('.time_start_call_project').attr('data-time-int','');
        $$('.time_start_call_project').attr('data-time-string','');
        $$('.u_hide').hide();
        $$('.project_call_add').show();
        $$('.navbar').hide();
        $$('.project_call_add-nav').show();
    }
});
$$('#painter_call_create_today_finish').on('click',function () {
    if(confirm("Sure to go back?"))
    {
        $$('#finish_button_painter_call').attr('data-id','');
        $$('.time_start_call_painter').attr('data-time-int','');
        $$('.time_start_call_painter').attr('data-time-string','');
        $$('.u_hide').hide();
        $$('.painter_call_add').show();
        $$('.navbar').hide();
        $$('.painter_call_add-nav').show();
    }
});
$$('.finish_painter_back').on('click',function () {
    if(confirm("Sure to go back?"))
    {
        if($$('#finish_button_painter_call').attr('data-type')=='today_painter')
        {
            call_today_painter_call_list();
        }
        else
        {
            call_overdue_painter_call_list();
        }
    }
});
$$('.finish_project_back').on('click',function () {
    if(confirm("Sure to go back?"))
    {
        if($$('#finish_button_project_call').attr('data-type')=='today_project')
        {
            call_today_project_call_list();
        }
        else
        {
            call_overdue_project_call_list();
        }
    }
});
$$('#finish_button_project_call').on('click',function () {
    var call_id=$$(this).attr('data-id');
    var call_type=$$(this).attr('data-type');
    if(call_id!='' && $$('#remarks_follow_up_project').val()!='' && $$('#finish_project_latitude').val()!='' && $$('#finish_project_longitude').val()!='')
    {
        if(!checkConnection())
        {
            alert('No internet connection!');
            return;
        }
        myApp.showIndicator();
        var check_in_time=$$('.time_start_call_project').attr('data-time-int');
        var after_remarks=$$('#remarks_follow_up_project').val();
        var lat=$$('#finish_project_latitude').val();
        var long=$$('#finish_project_longitude').val();
        var user_info = app_data.user_info;
        var url=base_url+"app/save_call_details";
        var new_data={};
        if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
        {
            new_data['today_date']=window.localStorage["today_date"];
        }
        else
        {
            new_data['today_date']='';
        }
        new_data['app_version']=$$('.version').html();
        $$.ajax({
            url: url,
            type: "POST",
            datatype:'json',
            data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,call_type:'project',call_id:call_id,after_remarks:after_remarks,check_in_time:check_in_time,lat:lat,long:long},
            //timeout: 15000,
            cache: false,
            success: function(data){
                myApp.hideIndicator();
                var response= JSON.parse(data);
                if(response.status='success')
                {
                    if(call_type=='today_project')
                    {
                        window.localStorage["new_followup_project_com_number_today"]=Number(window.localStorage["new_followup_project_com_number_today"])+1;
                        call_today_project_call_list();
                    }
                    else
                    {
                        call_overdue_project_call_list();
                    }
                }
                else if(response.status='unauthorized')
                {
                    alert('Unauthorized Action Found!');
                    logout();
                }
                else if(response.status == "time_over")
                {
                    __timeOver();
                }
                else if(response.status == "deprecated")
                {
                    __deprecated();
                }
                else
                {
                    alert('Operation Failed. Please try again!');
                }
            },
            error: function (e) {
                myApp.hideIndicator();
                alert('There was a problem connecting to the server.Please try again.');
            }
        });
    }
    else
    {
        alert('Field Missing!');
    }
});


$$('#finish_button_painter_call').on('click',function () {
    var call_id=$$(this).attr('data-id');
    var call_type=$$(this).attr('data-type');
    if(call_id!='' && $$('#remarks_follow_up_painter').val()!='' && $$('#finish_painter_latitude').val()!='' && $$('#finish_painter_longitude').val()!='')
    {
        if(!checkConnection())
        {
            alert('No internet connection!');
            return;
        }
        myApp.showIndicator();
        var check_in_time=$$('.time_start_call_painter').attr('data-time-int');
        var after_remarks=$$('#remarks_follow_up_painter').val();
        var lat=$$('#finish_painter_latitude').val();
        var long=$$('#finish_painter_longitude').val();
        var user_info = app_data.user_info;
        var url=base_url+"app/save_call_details";
        var new_data={};
        if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
        {
            new_data['today_date']=window.localStorage["today_date"];
        }
        else
        {
            new_data['today_date']='';
        }
        new_data['app_version']=$$('.version').html();
        $$.ajax({
            url: url,
            type: "POST",
            datatype:'json',
            data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,call_type:'painter',call_id:call_id,after_remarks:after_remarks,check_in_time:check_in_time,lat:lat,long:long},
            //timeout: 15000,
            cache: false,
            success: function(data){
                myApp.hideIndicator();
                var response= JSON.parse(data);
                if(response.status='success')
                {
                    if(call_type=='today_painter')
                    {
                        window.localStorage["new_followup_painter_com_number_today"]=Number(window.localStorage["new_followup_painter_com_number_today"])+1;
                        call_today_painter_call_list();
                    }
                    else
                    {
                        call_overdue_painter_call_list();
                    }
                }
                else if(response.status='unauthorized')
                {
                    alert('Unauthorized Action Found!');
                    logout();
                }
                else if(response.status == "time_over")
                {
                    __timeOver();
                }
                else if(response.status == "deprecated")
                {
                    __deprecated();
                }
                else
                {
                    alert('Operation Failed. Please try again!');
                }
            },
            error: function (e) {
                myApp.hideIndicator();
                alert('There was a problem connecting to the server.Please try again.');
            }
        });
    }
    else
    {
        alert('Field Missing!');
    }
});
function show_sales_create_page(class_name){
    $$('.dealer_in_order').attr('disabled','disabled');
    $$('.dealer_in_order').val('');
    $$('.product_in_order').val('');
    $$('#hidden_product_id_in_order').val('');
    $$('#volume_in_order').val('');
    $$('#sale_order_table').html('');
    $$('#total_amount_footer').html('--');
    var project_list=app_data.project_detail_info;
    var html='<option value="">Choose Project</option>';
    $$.each(project_list, function (cluster_id, set_values) {
        $$.each(set_values, function (index, value) {
            html+= '<option value="'+value.id+'">'+value.project_name+'</option>';
        });
    });
    $$('#requested_date_sales_order').val(window.localStorage["today_date"]);
    $$('#project_id_sales_order').html(html);
    var user_info = app_data.user_info;
    adminView.router.load({
        pageName: class_name+'-page'
    });
    user_nav(class_name);
}
function show_sales_order_list(class_name){
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    var url=base_url+"app/get_all_sales_order";
    var user_info = app_data.user_info;
    var user_location = app_data.user_location;
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    myApp.showIndicator();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,user_level_id:user_info.user_level_id,cluster:user_location.cluster},
        //timeout: 15000,
        cache: false,
        success: function(data){
            var response= JSON.parse(data);
            if(response.status=='success')
            {
                $$('#search_sales_order').val('');
                $$('#sales_status_select_div').val('ALL');
                app_data.sales_order_list_info=response.sales_order_list_data;
                $$('#sales_order_list_div').hide();
                $$('#sales_order_list_div').html('<div class="row separator"></div>');
                $$.each(response.sales_order_list_data, function (index, value) {
                    if(value.status=='Requested')
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#0077f9;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                    else if(value.status=='Approved')
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending approve_sales sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#04a71f;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                    else
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending rejected_sales sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#c10c2d;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                });
                $$('#sales_order_list_div').show();
                adminView.router.load({
                    pageName: class_name+'-page'
                });
                user_nav(class_name);
                $$('.sales_order_list_class').on('click',function () {
                    var order_id=$$(this).attr('data-id');
                    show_sale_order_details(order_id);
                });
                saveJSON();
            }
            else if(response.status=='unauthorized')
            {
                alert('System Found Unauthorized Action!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Failed!');
            }
            myApp.hideIndicator();
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}

function show_sale_order_details(id) {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    var user_location = app_data.user_location;
    var region=[];
    var area=[];
    var territory=[];
    var cluster=[];
    $$.each(user_location.region, function (region_id, region_values) {
        $$.each(user_location.area[region_id], function (area_id, area_values) {
            $$.each(user_location.territory[area_id], function (territory_id, territory_values) {
                $$.each(user_location.cluster[territory_id], function (cluster_id, cluster_values) {
                    var cluster_id=cluster_id;
                    region[cluster_id]=region_values.region_name;
                    area[cluster_id]=area_values.area_name;
                    territory[cluster_id]=territory_values.territory_name;
                    cluster[cluster_id]=cluster_values.cluster_name;
                });
            });
        });
    });
    $$('.resubmit_class').hide();
    $$('#resubmit_link').attr('data-id','');
    var url=base_url+"app/get_sales_order_details";
    var user_info = app_data.user_info;
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    myApp.showIndicator();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,order_id:id},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status=='success')
            {
                $$('#approval_history_sales_order').hide();
                $$('#approval_step_sales_order').hide();
                $$('#approval_history_sales_order_table').html('');
                var sales_order_list_info=app_data.sales_order_list_info;
                $$.each(sales_order_list_info, function (index, value) {
                    if(value.id==id)
                    {
                        var products=app_data.products;
                        var pr_info = [];
                        $$.each(products, function (index, value) {
                            pr_info[value.id]=value.product_name;
                        });
                        $$('#sale_order_no_in_detail').val(value.sales_order_no);
                        $$('#requested_date_in_detail').html(value.requested_date);
                        $$('#region_name_in_detail').html(region[value.cluster_id]);
                        $$('#area_name_in_detail').html(area[value.cluster_id]);
                        $$('#territory_name_in_detail').html(territory[value.cluster_id]);
                        $$('#cluster_name_in_detail').html(cluster[value.cluster_id]);
                        $$('#initiated_user_in_detail').html(value.initiator);
                        $$('#project_name_in_detail').html(value.project_name);
                        $$('#medium_type_in_detail').html(value.medium_type);
                        $$('#medium_name_in_detail').html(value.medium_name);
                        $$('#total_amount_footer_details').html(value.total_iprice_amount.toFixed(2));
                        var html = '';
                        var i=0;
                        $$.each(response.sales_details, function (index, value) {
                            i++;
                            html+='<tr>' +
                                '<td>'+i+'</td>' +
                                '<td>'+pr_info[value.product_id]+'</td>' +
                                '<td>'+value.price_per_ltr+'</td>' +
                                '<td>'+value.iprice_per_ltr+'</td>' +
                                '<td>'+value.volume+'</td>' +
                                '<td class="order_table_price">'+value.total_iprice.toFixed(2)+'</td>' +
                                '</tr>';
                        });
                        $$('#sale_details_table_body').html(html);
                        var possible_users_info=app_data.possible_users_info;
                        var all_user_level_info=app_data.all_user_level_info;
                        if(value.status=='Requested')
                        {
                            if(typeof value.approval_history !== 'undefined')
                            {
                                var table_contant='';
                                var status='';
                                $$.each(value.approval_history, function (initiator_id, value_details) {
                                    $$.each(value_details, function (sort_number, value) {
                                        if(value.is_approved==1)
                                        {
                                            status='Approved';
                                        }
                                        else
                                        {
                                            status='Rejected';
                                        }
                                        table_contant+='<tr>';
                                        table_contant+='<td>'+value.updated_date+'</td>';
                                        table_contant+='<td>'+possible_users_info[initiator_id]+'-'+all_user_level_info[value.initiator_level_id]+'</td>';
                                        table_contant+='<td>'+possible_users_info[value.approve_person_user_id]+'-'+all_user_level_info[value.approve_person_level_id]+'</td>';
                                        table_contant+='<td>'+value.remarks+'</td>';
                                        table_contant+='<td>'+status+'</td>';
                                        table_contant+='</tr>';
                                    });
                                });
                                $$('#approval_history_sales_order_table').html(table_contant);
                                $$('#approval_history_sales_order').show();
                            }
                            if(typeof value.approval_action_info !== 'undefined')
                            {
                                $$( ".approval_action_button_sales" ).each(function( index ) {
                                    $$(this).attr('data-event-id',id);
                                });
                                $$.each(value.approval_action_info, function (initiator_id, value_details) {
                                    if(value_details.approve_action==1)
                                    {
                                        $$('#step_initiator_sales_order').html(possible_users_info[initiator_id]+' - '+all_user_level_info[value_details.initiator_level_id]);
                                        $$('#step_approve_person_sales_order').html(possible_users_info[value_details.approve_person_user_id]+' - '+all_user_level_info[value_details.approve_person_level_id]);
                                        $$('#approval_step_sales_order').show();
                                    }
                                });
                            }
                        }
                        else
                        {
                            if(value.status=='Rejected' && value.created_by==user_info.user_id)
                            {
                                $$('.resubmit_class').show();
                                $$('#resubmit_link').attr('data-id',value.id);
                            }
                            if(typeof value.approval_history !== 'undefined')
                            {
                                var table_contant='';
                                var status='';
                                $$.each(value.approval_history, function (initiator_id, value_details) {
                                    $$.each(value_details, function (sort_number, value) {
                                        if(value.is_approved==1)
                                        {
                                            status='Approved';
                                        }
                                        else
                                        {
                                            status='Rejected';
                                        }
                                        table_contant+='<tr>';
                                        table_contant+='<td>'+value.updated_date+'</td>';
                                        table_contant+='<td>'+possible_users_info[initiator_id]+'-'+all_user_level_info[value.initiator_level_id]+'</td>';
                                        table_contant+='<td>'+possible_users_info[value.approve_person_user_id]+'-'+all_user_level_info[value.approve_person_level_id]+'</td>';
                                        table_contant+='<td>'+value.remarks+'</td>';
                                        table_contant+='<td>'+status+'</td>';
                                        table_contant+='</tr>';
                                    });
                                });
                                $$('#approval_history_sales_order_table').html(table_contant);
                                $$('#approval_history_sales_order').show();
                            }
                            if(typeof value.approval_action_info !== 'undefined')
                            {
                                $$( ".approval_action_button_sales" ).each(function( index ) {
                                    $$(this).attr('data-event-id',id);
                                });
                                $$.each(value.approval_action_info, function (initiator_id, value_details) {
                                    if(value_details.approve_action==1)
                                    {
                                        $$('#step_initiator_sales_order').html(possible_users_info[initiator_id]+' - '+all_user_level_info[value_details.initiator_level_id]);
                                        $$('#step_approve_person_sales_order').html(possible_users_info[value_details.approve_person_user_id]+' - '+all_user_level_info[value_details.approve_person_level_id]);
                                        $$('#approval_step_sales_order').show();
                                    }
                                });
                            }
                        }
                    }
                });
                $$('.u_hide').hide();
                $$('.sales_list_details').show();
                $$('.navbar').hide();
                $$('.sales_list_details-nav').show();
            }
            else if(response.status=='unauthorized')
            {
                alert('System Found Unauthorized Action!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Failed!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
$$('#resubmit_link').on('click',function () {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    $$('.product_in_order_revert').val('');
    $$('#hidden_product_id_in_order_revert').val('');
    $$('#volume_in_order_revert').val('');
    var data_id = $$(this).attr('data-id');
    $$('#sales_order_resubmit').attr('data-id',data_id);
    var url = base_url+"app/get_sales_data_by_sales_id";
    var user_info = app_data.user_info;
    var products=app_data.products;
    var product_info=[];
    $$.each(products, function (index, value){
        product_info[value.id]=value.product_name;
    });
    var project_detail_info=app_data.project_detail_info;
    var project_info=[];
    $$.each(project_detail_info, function (cluster_id, set_values) {
        $$.each(set_values, function (index, value) {
            project_info[value.id]=value.project_name;
        });
    });
    var dealer_info=[];
    var dealer_location=app_data.dealer_location;
    $$.each(dealer_location.cluster, function (index, set_value) {
        $$.each(set_value, function (indx, value) {
            dealer_info[value.dealer_id]=value.name_number;
        });
    });
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    myApp.showIndicator();
    $$.ajax({
        url: url,
        type: "POST",
        datatype: 'json',
        data: {_token: window.localStorage["token"],new_data:new_data,user_id: user_info.user_id, sales_id: data_id},
        //timeout: 15000,
        cache: false,
        success: function (data) {
            myApp.hideIndicator();
            var response = JSON.parse(data);
            if(response.status == 'success')
            {
                var count_row=0;
                var total_amount=0;
                var html='';
                $$.each(response.sales_details, function (index, value) {
                    if(count_row==0)
                    {
                        $$('#sale_order_no_in_revert').html(value.sales_order_no);
                        $$('#requested_date_in_revert').html(value.requested_date);
                        $$('#project_name_in_revert').html(project_info[value.project_id]);
                        $$('.dealer_in_order_revert').val(dealer_info[value.dealer_id]);
                        $$('#hidden_dealer_id_in_order_revert').val(value.dealer_id);
                        $$('#project_name_in_revert').attr('data-id',value.project_id);
                        $$('#total_amount_footer_revert').html(value.total_iprice_amount.toFixed(2));
                    }
                    count_row++;
                    html+='<tr class="order_table_tr_revert" id="order_table_tr_revert_'+(index+1)+'" data-product-id="'+value.product_id+'" data-product-volume="'+value.volume+'">' +
                        '<td class="order_table_row_revert">'+(index+1)+'</td>' +
                        '<td>'+product_info[value.product_id]+'</td>' +
                        '<td>'+value.price_per_ltr+'</td>' +
                        '<td><input type="text" class="order_table_iprice_revert class_float" data-id="'+(index+1)+'" id="order_table_iprice_revert_'+(index+1)+'" style="border: 1px solid palegoldenrod;width:100%;" value="'+value.iprice_per_ltr+'"></td>' +
                        '<td>'+value.volume+'</td>' +
                        '<td class="order_table_price_revert" id="order_table_price_revert_'+(index+1)+'">'+value.total_iprice.toFixed(2)+'</td>' +
                        '<td><i class="fa fa-trash-o delete_order_row_revert" data-id="'+(index+1)+'" aria-hidden="true"></i></td>' +
                        '</tr>';
                });
                $$('#sale_order_revert_table').html(html);
                $$('.order_table_iprice_revert').on('input', function(event) {
                    var iprice=$$(this).val();
                    iprice=iprice.replace(/[^.0-9]/g, '');
                    iprice=Number(iprice);
                    var data_id=$$(this).attr('data-id');
                    var volume=Number($$('#order_table_tr_revert_'+data_id).attr('data-product-volume'));
                    var new_sub_total=Number((volume*iprice).toFixed(2));
                    $$('#order_table_price_revert_'+data_id).html(new_sub_total);
                    var total_amount_footer_for_iprice=0;
                    $$(".order_table_price_revert").each(function( index ) {
                        total_amount_footer_for_iprice+=Number($$(this).html());
                    });
                    $$('#total_amount_footer_revert').html(total_amount_footer_for_iprice.toFixed(2));
                    $$('#order_table_iprice_revert_'+data_id).attr('value',iprice);
                });
                $$('.order_table_iprice_revert').on('change', function(event) {
                    var data_id=$$(this).attr('data-id');
                    $$('#order_table_iprice_revert_'+data_id).attr('value',$$('#order_table_iprice_revert_'+data_id).val());
                });
                $$('.delete_order_row_revert').on('click',function () {
                    if(confirm('Are you sure to delete this item?'))
                    {
                        var row_id=$$(this).attr('data-id');
                        $$('#order_table_tr_revert_'+row_id).remove();
                        var total_amount_footer=0;
                        var l=0;
                        $$(".order_table_price_revert").each(function( index ) {
                            l=l+1;
                            $$(this).attr('id','order_table_price_revert_'+l);
                            total_amount_footer+=Number($$(this).html());
                        });
                        $$('#total_amount_footer_revert').html(total_amount_footer.toFixed(2));
                        var i=0;
                        var j=0;
                        var k=0;
                        var m=0;
                        $$(".order_table_row_revert").each(function( index ) {
                            i=i+1;
                            $$(this).html(i);
                        });
                        $$(".delete_order_row_revert").each(function( index ) {
                            j=j+1;
                            $$(this).attr('data-id',j);
                        });
                        $$(".order_table_tr_revert").each(function( index ) {
                            k=k+1;
                            $$(this).attr('id','order_table_tr_revert_'+k);
                            $$(this).attr('data-id',k);
                        });
                        $$(".order_table_iprice_revert").each(function( index ) {
                            m=m+1;
                            $$(this).attr('id','order_table_iprice_revert_'+m);
                            $$(this).attr('data-id',m);
                        });
                    }
                });
                $$('.u_hide').hide();
                $$('.sales_list_revert').show();
                $$('.navbar').hide();
                $$('.sales_list_revert-nav').show();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else{}
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
});
$$('#sales_order_resubmit').on('click',function () {
    if(confirm('Are you sure to resubmit this sales?'))
    {
        var sales_id=$$(this).attr('data-id');
        var rowCount = Number($$('#sale_order_revert_table tr').length);
        if(rowCount)
        {
            var istatus=true;
            $$(".order_table_iprice_revert").each(function( index ) {
                if(!istatus)
                {
                    return false;
                }
                if($$(this).val()=='' || $$(this).val()==0)
                {
                    alert('Invoice price missing!!!!');
                    istatus=false;
                }
            });
            if(!istatus)
            {
                return false;
            }
            if($$('#hidden_dealer_id_in_order_revert').val()!='')
            {
                if(!checkConnection())
                {
                    alert('No internet connection!');
                    return;
                }
                var product_ids=[];
                var volumes=[];
                var iprices=[];
                var dealer_id=$$('#hidden_dealer_id_in_order_revert').val();
                $$(".order_table_tr_revert").each(function( index ) {
                    product_ids.push($$(this).attr('data-product-id'));
                    volumes.push($$(this).attr('data-product-volume'));
                });
                $$(".order_table_iprice_revert").each(function( index ) {
                    iprices.push($$(this).val());
                });
                var url=base_url+"app/save_sales_revert_order";
                var user_info = app_data.user_info;
                var new_data={};
                if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
                {
                    new_data['today_date']=window.localStorage["today_date"];
                }
                else
                {
                    new_data['today_date']='';
                }
                new_data['app_version']=$$('.version').html();
                myApp.showIndicator();
                $$.ajax({
                    url: url,
                    type: "POST",
                    datatype:'json',
                    data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,user_level_id:user_info.user_level_id,products:product_ids,volumes:volumes,iprices:iprices,dealer_id:dealer_id,sales_id:sales_id},
                    //timeout: 15000,
                    cache: false,
                    success: function(data){
                        myApp.hideIndicator();
                        var response= JSON.parse(data);
                        if(response.status=='success')
                        {
                            alert('Sales Order Saved Successfully');
                            show_sales_order_list('sales_list');
                        }
                        else if(response.status=='unauthorized')
                        {
                            alert('System Found Unauthorized Action!');
                            logout();
                        }
                        else if(response.status == "time_over")
                        {
                            __timeOver();
                        }
                        else if(response.status == "deprecated")
                        {
                            __deprecated();
                        }
                        else
                        {
                            alert('Failed to save data!');
                        }
                    },
                    error: function (e) {
                        myApp.hideIndicator();
                        alert('There was a problem connecting to the server.Please try again.');
                    }
                });
            }
            else
            {
                alert('Please fill up all required fields');
            }
        }
        else
        {
            alert('You must add a product!');
        }
    }
});
$$('.sales_order_details_back_button').on('click',function () {
    show_sales_order_list('sales_list');
});
function show_sales_ratification_list(class_name){
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    var url=base_url+"app/sales_ratification_list";
    var user_info = app_data.user_info;
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    myApp.showIndicator();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,user_level_id:user_info.user_level_id,user_level:user_info.user_level},
        //timeout: 15000,
        cache: false,
        success: function(data){
            var response= JSON.parse(data);
            if(response.status=='success')
            {
                $$('#search_sales_ratification').val('');
                $$('#sales_ratify_status_select_div').val('ALL');
                var div_close='</div>';
                var div_40='';
                var div_60='';
                var div_start='';
                var final_html='';
                var sales_ratify_status={};
                $$('#sales_ratification_list_div').hide();
                $$('#sales_ratification_list_div').html('<div class="row separator"></div>');
                $$.each(response.sales_ratification_list_data, function (index, value) {
                    sales_ratify_status[value.id]=value.status;
                    if(user_info.user_level=='APEC')
                    {
                        if(response.ratify_condition[value.id]['ok']==0 && response.ratify_condition[value.id]['not']==0)
                        {
                            div_40 = '<div class="col-40" style="text-align: right;margin-top: 8%;">' +
                                '<p class="sale_order_status" style="color:#8a6d3b;">R. Pending</p>' +
                                '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                                '<p class="sale_order_status">'+value.name+'</p>' +
                                '</div>';
                        }
                        else
                        {
                            div_40 = '<div class="col-40" style="text-align: right;margin-top: 8%;">' +
                                '<p class="sale_order_status" style="color:#8a6d3b;">Ratified ('+'<span style="color:#04a71f">'+response.ratify_condition[value.id]['ok']+'</span>'+' || '+'<span style="color:#bf1313ed">'+response.ratify_condition[value.id]['not']+'</span>'+')</p>' +
                                '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                                '<p class="sale_order_status">'+value.name+'</p>' +
                                '</div>';
                        }
                    }
                    else
                    {
                        if(value.status=='Pending')
                        {
                            div_40 = '<div class="col-40" style="text-align: right;margin-top: 8%;">' +
                                '<p class="sale_order_status" style="color:#0077f9;">'+value.status+' ('+'<span style="color:#04a71f">'+response.ratify_condition[value.id]['ok']+'</span>'+' || '+'<span style="color:#bf1313ed">'+response.ratify_condition[value.id]['not']+'</span>'+')</p>' +
                                '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                                '<p class="sale_order_status">'+value.name+'</p>' +
                                '</div>';
                        }
                        else if(value.status=='Approved')
                        {
                            div_40 = '<div class="col-40" style="text-align: right;margin-top: 8%;">' +
                                '<p class="sale_order_status" style="color:#04a71f;">'+value.status+' ('+'<span style="color:#04a71f">'+response.ratify_condition[value.id]['ok']+'</span>'+' || '+'<span style="color:#bf1313ed">'+response.ratify_condition[value.id]['not']+'</span>'+')</p>' +
                                '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                                '<p class="sale_order_status">'+value.name+'</p>' +
                                '</div>';
                        }
                        else
                        {
                            div_40 = '<div class="col-40" style="text-align: right;margin-top: 8%;">' +
                                '<p class="sale_order_status" style="color:#c10c2d;">'+value.status+' ('+'<span style="color:#04a71f">'+response.ratify_condition[value.id]['ok']+'</span>'+' || '+'<span style="color:#bf1313ed">'+response.ratify_condition[value.id]['not']+'</span>'+')</p>' +
                                '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                                '<p class="sale_order_status">'+value.name+'</p>' +
                                '</div>';
                        }
                    }
                    div_60 = '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                        '<p class="sale_order_project" id="rat_sales_project_name_'+value.id+'">'+value.project_name+'</p>' +
                        '<p class="sale_order_painter">Order No. : <span id="rat_sales_order_'+value.id+'">'+value.sales_order_no+'</span></p>' +
                        '<p class="sale_order_painter">Submission Date : '+value.submission_date+'</p>' +
                        '</div>';
                    div_start = '<div class="row separator" id="rat_separator_'+value.id+'"></div><div class="row call_list_div_pending sales_ratification_list_class" id="sales_ratification_list_id_'+value.id+'" data-id="'+value.id+'" data-ratify-status="'+value.ratify_status+'">';
                    final_html=div_start+div_60+div_40+div_close;
                    $$('#sales_ratification_list_div').prepend(final_html);
                });
                $$('#sales_ratification_list_div').show();
                adminView.router.load({
                    pageName: class_name+'-page'
                });
                user_nav(class_name);
                $$('.sales_ratification_list_class').on('click',function () {
                    var sales_id=$$(this).attr('data-id');
                    if(user_info.user_level=='APEC')
                    {
                        show_sale_ratification_details(sales_id);
                    }
                    else
                    {
                        if(sales_ratify_status[sales_id]=="Pending")
                        {
                            if(check_action_status())
                            {
                                show_sale_ratification_details(sales_id);
                            }
                        }
                        else
                        {
                            show_sale_ratification_details(sales_id);
                        }
                    }
                });
            }
            else if(response.status=='unauthorized')
            {
                alert('System Found Unauthorized Action!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Failed to retrieve data!');
            }
            myApp.hideIndicator();
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
$$('#project_id_sales_order').on('change',function()
{
    $$('.depot_medium_div').hide();
    $$('.dealer_medium_div').hide();
    $$('.dealer_in_order').attr('disabled','disabled');
    $$('.dealer_in_order').val('');
    $$('#hidden_dealer_id_in_order').val('');
    $$('.depot_in_order').val('');
    $$('.depot_in_order').html('');
    $$('#medium_sales_order').val('');
});

$$('#medium_sales_order').on('change',function(){
    var project_id=$$('#project_id_sales_order').val();
    if(project_id)
    {
        if($$(this).val()=='')
        {
            $$('.dealer_in_order').attr('disabled','disabled');
            $$('.dealer_in_order').val('');
            $$('#hidden_dealer_id_in_order').val('');
            $$('.depot_in_order').val('');
            $$('.depot_in_order').html('');
            $$('.dealer_medium_div').hide();
            $$('.depot_medium_div').hide();
        }
        else
        {
            var project_list=app_data.project_detail_info;
            var cluster='';
            var dealer='';
            var depot='';
            $$.each(project_list, function (cluster_id, value) {
                $$.each(value, function (index, v) {
                    if(v.id==project_id)
                    {
                        cluster=cluster_id;
                        dealer= v.dealer_id;
                        depot= v.depot_id;
                    }
                });
            });
            if($$(this).val()=='dealer')
            {
                var dealer_location=app_data.dealer_location;
                if(dealer_location.length==0)
                {
                    $$('#hidden_dealer_id_in_order').val('');
                    $$('.dealer_in_order').val('');
                }
                else
                {
                    $$('#hidden_dealer_id_in_order').val(dealer);
                    $$.each(dealer_location.cluster[cluster], function (index, value) {
                        if(value.dealer_id==dealer){
                            $$('.dealer_in_order').val(value.name_number);
                        }
                    });
                }
                $$('.dealer_in_order').removeAttr('disabled');
                $$('.dealer_medium_div').css('display','flex');
                $$('.depot_medium_div').hide();
            }
            else
            {
                var depot_location=app_data.depo_location;
                var html='<option value="">Choose Depot</option>';

                if(depot_location.length==0)
                {
                    $$('.depot_in_order').html(html);
                }
                else
                {
                    $$.each(depot_location.cluster[cluster], function (index, value) {
                        if(value.depo_id==depot){
                            html+='<option value="'+value.depo_id+'" selected="selected">'+value.depo_code+'</option>';
                        }
                        else
                        {
                            html+='<option value="'+value.depo_id+'">'+value.depo_code+'</option>';
                        }
                    });
                    $$('.depot_in_order').html(html);
                }
                $$('.dealer_medium_div').hide();
                $$('.depot_medium_div').css('display','flex');
            }
        }
    }
    else
    {
        alert('Project Missing!');
    }
});




$$('.sales_list_new_button').on('click',function () {
    if(check_action_status())
    {
        show_sales_create_page('create_sales');
    }
});
$$('#sales_ratification_back_button').on('click',function () {
    show_sales_order_list('sales_list');
});
$$('.dealer_in_order').on('input', function () {
    if($$(this).val()=='')
    {
        $$('.dealer_ul_in_order').hide();
        $$('#hidden_dealer_id_in_order').val('');
    }
    else
    {
        var project_id=$$('#project_id_sales_order').val();
        var project_list=app_data.project_detail_info;
        var cluster='';
        $$.each(project_list, function (cluster_id, value) {
            $$.each(value, function (index, v) {
                if(v.id==project_id)
                {
                    cluster=cluster_id;
                }
            });
        });
        var string = $$(this).val().toLowerCase();
        var html='';
        var dealer_location=app_data.dealer_location;
        $$.each(dealer_location.cluster[cluster], function (index, value) {
            var str=value.name_number.toLowerCase();
            if(str.includes(string)){
                html+='<li class="dealer_li_in_order complete_input_li" data-id="'+value.dealer_id+'">'+value.name_number+'</li>';
            }
        });
        $$('.dealer_ul_in_order').html(html);
        $$('.dealer_ul_in_order').show();
    }
    $$('.dealer_li_in_order').on('click', function () {
        var li_text = $$(this).text();
        var data_id= $$(this).attr('data-id');
        $$('.dealer_in_order').val(li_text);
        $$('.dealer_ul_in_order').hide();
        $$('#hidden_dealer_id_in_order').val(data_id);
    });
});
$$('.dealer_in_order_revert').on('input', function () {
    if($$(this).val()=='')
    {
        $$('.dealer_ul_in_order_revert').hide();
        $$('#hidden_dealer_id_in_order_revert').val('');
    }
    else
    {
        var project_id=$$('#project_name_in_revert').attr('data-id');
        var project_list=app_data.project_detail_info;
        var cluster='';
        $$.each(project_list, function (cluster_id, value) {
            $$.each(value, function (index, v) {
                if(v.id==project_id)
                {
                    cluster=cluster_id;
                }
            });
        });
        var string = $$(this).val().toLowerCase();
        var html='';
        var dealer_location=app_data.dealer_location;
        $$.each(dealer_location.cluster[cluster], function (index, value) {
            var str=value.name_number.toLowerCase();
            if(str.includes(string)){
                html+='<li class="dealer_li_in_order_revert complete_input_li" data-id="'+value.dealer_id+'">'+value.name_number+'</li>';
            }
        });
        $$('.dealer_ul_in_order_revert').html(html);
        $$('.dealer_ul_in_order_revert').show();
    }
    $$('.dealer_li_in_order_revert').on('click', function () {
        var li_text = $$(this).text();
        var data_id= $$(this).attr('data-id');
        $$('.dealer_in_order_revert').val(li_text);
        $$('.dealer_ul_in_order_revert').hide();
        $$('#hidden_dealer_id_in_order_revert').val(data_id);
    });
});
function get_all_products(user_id)
{
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    var url=base_url+"app/get_all_products";
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],user_id:user_id},
        //timeout: 15000,
        cache: false,
        success: function(data){
            var response= JSON.parse(data);
            app_data.products=response;
            saveJSON();
        },
        error: function (e) {
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}
$$('.product_in_order').on('input', function () {
    if($$(this).val()=='')
    {
        $$('.product_ul_in_order').hide();
        $$('#hidden_product_id_in_order').val('');
    }
    else
    {
        var string = $$(this).val().toLowerCase();
        var html='';
        var products=app_data.products;
        $$.each(products, function (index, value) {
            var str=(value.product_name+'-'+value.product_code).toLowerCase();
            if(str.includes(string)){
                html+='<li class="product_li_in_order complete_input_li" data-id="'+value.id+'">'+value.product_name+'('+value.product_code+')'+'</li>';
            }
        });
        $$('.product_ul_in_order').html(html);
        $$('.product_ul_in_order').show();
    }
    $$('.product_li_in_order').on('click', function () {
        var products=app_data.products;
        var li_text;
        var data_id= $$(this).attr('data-id');
        $$.each(products, function (index, value) {
            if(value.id==data_id)
            {
                li_text = value.product_code;
            }
        });
        $$('.product_in_order').val(li_text);
        $$('.product_ul_in_order').hide();
        $$('#hidden_product_id_in_order').val(data_id);
    });
});
$$('.product_in_order_revert').on('input', function () {
    if($$(this).val()=='')
    {
        $$('.product_ul_in_order_revert').hide();
        $$('#hidden_product_id_in_order_revert').val('');
    }
    else
    {
        var string = $$(this).val().toLowerCase();
        var html='';
        var products=app_data.products;
        $$.each(products, function (index, value) {
            var str=(value.product_name+'-'+value.product_code).toLowerCase();
            if(str.includes(string)){
                html+='<li class="product_li_in_order_revert complete_input_li" data-id="'+value.id+'">'+value.product_name+'('+value.product_code+')'+'</li>';
            }
        });
        $$('.product_ul_in_order_revert').html(html);
        $$('.product_ul_in_order_revert').show();
    }
    $$('.product_li_in_order_revert').on('click', function () {
        var products=app_data.products;
        var li_text;
        var data_id= $$(this).attr('data-id');
        $$.each(products, function (index, value) {
            if(value.id==data_id)
            {
                li_text = value.product_code;
            }
        });
        $$('.product_in_order_revert').val(li_text);
        $$('.product_ul_in_order_revert').hide();
        $$('#hidden_product_id_in_order_revert').val(data_id);
    });
});
$$('.add_product_button').on('click',function () {
    if(($$('#hidden_product_id_in_order').val()!='') && (Number($$('#volume_in_order').val())!=0))
    {
        var product_id=$$('#hidden_product_id_in_order').val();
        var product_volume=Number($$('#volume_in_order').val());
        var products=app_data.products;
        $$.each(products, function (index, value) {
            if(value.id==product_id)
            {
                var price_per_ltr=value.price_per_ltr;
                var product_name=value.product_name;
                var total_price=Number(price_per_ltr)*Number(product_volume);
                var rowCount = $$('#sale_order_table tr').length;
                var html='<tr class="order_table_tr" id="order_table_tr_'+(rowCount+1)+'" data-id="'+(rowCount+1)+'" data-product-id="'+product_id+'" data-product-volume="'+product_volume+'">' +
                    '<td class="order_table_row">'+(rowCount+1)+'</td>' +
                    '<td>'+product_name+'</td>' +
                    '<td>'+price_per_ltr+'</td>' +
                    '<td><input type="text" class="order_table_iprice class_float" data-id="'+(rowCount+1)+'" id="order_table_iprice_'+(rowCount+1)+'" style="border: 1px solid palegoldenrod;width:100%;" value="'+value.price_per_ltr+'"></td>' +
                    '<td>'+product_volume+'</td>' +
                    '<td class="order_table_price" id="order_table_price_'+(rowCount+1)+'" >'+total_price.toFixed(2)+'</td>' +
                    '<td><i class="fa fa-trash-o delete_order_row" data-id="'+(rowCount+1)+'" aria-hidden="true"></i></td>' +
                    '</tr>';
                var total_html=$$('#sale_order_table').html();
                var total_amount_footer=0;
                $$(".order_table_price").each(function( index ) {
                    total_amount_footer+=Number($$(this).html());
                });
                total_amount_footer+=total_price;
                $$('#sale_order_table').html(total_html+html);
                $$('#total_amount_footer').html(total_amount_footer.toFixed(2));
                $$('.order_table_iprice').on('input', function(event) {
                    var iprice=$$(this).val();
                    iprice=iprice.replace(/[^.0-9]/g, '');
                    iprice=Number(iprice);
                    var data_id=$$(this).attr('data-id');
                    var volume=Number($$('#order_table_tr_'+data_id).attr('data-product-volume'));
                    var new_sub_total=Number((volume*iprice).toFixed(2));
                    $$('#order_table_price_'+data_id).html(new_sub_total);
                    var total_amount_footer_for_iprice=0;
                    $$(".order_table_price").each(function( index ) {
                        total_amount_footer_for_iprice+=Number($$(this).html());
                    });
                    $$('#total_amount_footer').html(total_amount_footer_for_iprice.toFixed(2));
                    $$('#order_table_iprice_'+data_id).attr('value',iprice);
                });
                $$('.order_table_iprice').on('change', function(event) {
                    var data_id=$$(this).attr('data-id');
                    $$('#order_table_iprice_'+data_id).attr('value',$$('#order_table_iprice_'+data_id).val());
                });
            }
        });
        $$('.delete_order_row').on('click',function () {
            if(confirm('Are you sure to delete this item?'))
            {
                var row_id=$$(this).attr('data-id');
                $$('#order_table_tr_'+row_id).remove();
                var total_amount_footer=0;
                var l=0;
                $$(".order_table_price").each(function( index ) {
                    l=l+1;
                    $$(this).attr('id','order_table_price_'+l);
                    total_amount_footer+=Number($$(this).html());
                });
                $$('#total_amount_footer').html(total_amount_footer.toFixed(2));
                var i=0;
                var j=0;
                var k=0;
                var m=0;
                $$(".order_table_row").each(function( index ) {
                    i=i+1;
                    $$(this).html(i);
                });
                $$(".delete_order_row").each(function( index ) {
                    j=j+1;
                    $$(this).attr('data-id',j);
                });
                $$(".order_table_tr").each(function( index ) {
                    k=k+1;
                    $$(this).attr('id','order_table_tr_'+k);
                    $$(this).attr('data-id',k);
                });
                $$(".order_table_iprice").each(function( index ) {
                    m=m+1;
                    $$(this).attr('id','order_table_iprice_'+m);
                    $$(this).attr('data-id',m);
                });
            }
        });
        $$('.product_in_order').val('');
        $$('#hidden_product_id_in_order').val('');
        $$('#volume_in_order').val('');
    }
    else
    {
        alert('Please select a product and product volume!');
    }
});

$$('.add_product_button_revert').on('click',function () {
    if(($$('#hidden_product_id_in_order_revert').val()!='') && ($$('#volume_in_order_revert').val()!='') && ($$('#volume_in_order_revert').val()!=0))
    {
        var product_id=$$('#hidden_product_id_in_order_revert').val();
        var product_volume=Number($$('#volume_in_order_revert').val());
        var products=app_data.products;
        $$.each(products, function (index, value) {
            if(value.id==product_id)
            {
                var price_per_ltr=value.price_per_ltr;
                var product_name=value.product_name;
                var total_price=Number(price_per_ltr)*Number(product_volume);
                var rowCount = $$('#sale_order_revert_table tr').length;
                var html='<tr class="order_table_tr_revert" id="order_table_tr_revert_'+(rowCount+1)+'" data-id="'+(rowCount+1)+'" data-product-id="'+product_id+'" data-product-volume="'+product_volume+'">' +
                    '<td class="order_table_row_revert">'+(rowCount+1)+'</td>' +
                    '<td>'+product_name+'</td>' +
                    '<td>'+price_per_ltr+'</td>' +
                    '<td><input type="text" class="order_table_iprice_revert class_float" data-id="'+(rowCount+1)+'" id="order_table_iprice_revert_'+(rowCount+1)+'" style="border: 1px solid palegoldenrod;width:100%;" value="'+value.price_per_ltr+'"></td>' +
                    '<td>'+product_volume+'</td>' +
                    '<td class="order_table_price_revert" id="order_table_price_revert_'+(rowCount+1)+'">'+total_price.toFixed(2)+'</td>' +
                    '<td><i class="fa fa-trash-o delete_order_row_revert" data-id="'+(rowCount+1)+'" aria-hidden="true"></i></td>' +
                    '</tr>';
                var total_html=$$('#sale_order_revert_table').html();
                var total_amount_footer=0;
                $$(".order_table_price_revert").each(function( index ) {
                    total_amount_footer+=Number($$(this).html());
                });
                total_amount_footer+=total_price;
                $$('#sale_order_revert_table').html(total_html+html);
                $$('#total_amount_footer_revert').html(total_amount_footer.toFixed(2));
                $$('.order_table_iprice_revert').on('input', function(event) {
                    var iprice=$$(this).val();
                    iprice=iprice.replace(/[^.0-9]/g, '');
                    iprice=Number(iprice);
                    var data_id=$$(this).attr('data-id');
                    var volume=Number($$('#order_table_tr_revert_'+data_id).attr('data-product-volume'));
                    var new_sub_total=Number((volume*iprice).toFixed(2));
                    $$('#order_table_price_revert_'+data_id).html(new_sub_total);
                    var total_amount_footer_for_iprice=0;
                    $$(".order_table_price_revert").each(function( index ) {
                        total_amount_footer_for_iprice+=Number($$(this).html());
                    });
                    $$('#total_amount_footer_revert').html(total_amount_footer_for_iprice.toFixed(2));
                    $$('#order_table_iprice_revert_'+data_id).attr('value',iprice);
                });
                $$('.order_table_iprice_revert').on('change', function(event) {
                    var data_id=$$(this).attr('data-id');
                    $$('#order_table_iprice_revert_'+data_id).attr('value',$$('#order_table_iprice_revert_'+data_id).val());
                });
            }
        });
        $$('.delete_order_row_revert').on('click',function () {
            if(confirm('Are you sure to delete this item?'))
            {
                var row_id=$$(this).attr('data-id');
                $$('#order_table_tr_revert_'+row_id).remove();
                var total_amount_footer=0;
                var l=0;
                $$(".order_table_price_revert").each(function( index ) {
                    l=l+1;
                    $$(this).attr('id','order_table_price_revert_'+l);
                    total_amount_footer+=Number($$(this).html());
                });
                $$('#total_amount_footer_revert').html(total_amount_footer.toFixed(2));
                var i=0;
                var j=0;
                var k=0;
                var m=0;
                $$(".order_table_row_revert").each(function( index ) {
                    i=i+1;
                    $$(this).html(i);
                });
                $$(".delete_order_row_revert").each(function( index ) {
                    j=j+1;
                    $$(this).attr('data-id',j);
                });
                $$(".order_table_tr_revert").each(function( index ) {
                    k=k+1;
                    $$(this).attr('id','order_table_tr_revert_'+k);
                    $$(this).attr('data-id',k);
                });
                $$(".order_table_iprice_revert").each(function( index ) {
                    m=m+1;
                    $$(this).attr('id','order_table_iprice_revert_'+m);
                    $$(this).attr('data-id',m);
                });
            }
        });
        $$('.product_in_order_revert').val('');
        $$('#hidden_product_id_in_order_revert').val('');
        $$('#volume_in_order_revert').val('');
    }
    else
    {
        alert('Please select a product and product volume!');
    }
});


$$('#sales_order_save').on('click',function () {
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    var rowCount = Number($$('#sale_order_table tr').length);
    if(rowCount)
    {
        var status=true;
        if($$('#medium_sales_order').val()!='' && $$('#project_id_sales_order').val()!='' && $$('#requested_date_sales_order').val()!='')
        {
            if($$('#medium_sales_order').val()=='dealer')
            {
                if($$('.dealer_in_order').val()=='')
                {
                    status=false;
                }
                else
                {
                    var medium_id=$$('#hidden_dealer_id_in_order').val();
                }
            }
            else
            {
                if($$('.depot_in_order').val()=='')
                {
                    status=false;
                }
                else
                {
                    var medium_id=$$('.depot_in_order').val();
                }
            }
            var istatus=true;
            $$(".order_table_iprice").each(function( index ) {
                if(!istatus)
                {
                    return false;
                }
                if($$(this).val()=='' || $$(this).val()==0)
                {
                    alert('Invoice price missing!!!!');
                    istatus=false;
                }
            });
            if(!istatus)
            {
                return false;
            }
            if(status)
            {
                var product_ids=[];
                var volumes=[];
                var iprices=[];
                var medium=$$('#medium_sales_order').val();;
                var project_id=$$('#project_id_sales_order').val();
                var project_list=app_data.project_detail_info;
                if(project_id)
                {
                    var cluster='';
                    $$.each(project_list, function (cluster_id, set_values) {
                        $$.each(set_values, function (index, value) {
                            if(value.id==project_id)
                            {
                                cluster=cluster_id;
                            }
                        });
                    });
                }
                else
                {
                    alert('Please try Again!');
                    return false;
                }
                var requested_date=$$('#requested_date_sales_order').val();
                $$(".order_table_tr").each(function( index ) {
                    product_ids.push($$(this).attr('data-product-id'));
                    volumes.push($$(this).attr('data-product-volume'));
                });
                $$(".order_table_iprice").each(function( index ) {
                    iprices.push($$(this).val());
                });
                myApp.showIndicator();
                var url=base_url+"app/save_sales_order";
                var user_info = app_data.user_info;
                var new_data={};
                if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
                {
                    new_data['today_date']=window.localStorage["today_date"];
                }
                else
                {
                    new_data['today_date']='';
                }
                new_data['app_version']=$$('.version').html();
                $$.ajax({
                    url: url,
                    type: "POST",
                    datatype:'json',
                    data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,user_level_id:user_info.user_level_id,cluster_id:cluster,products:product_ids,volumes:volumes,iprices:iprices,requested_date:requested_date,project_id:project_id,medium:medium,medium_id:medium_id},
                    //timeout: 15000,
                    cache: false,
                    success: function(data){
                        myApp.hideIndicator();
                        var response= JSON.parse(data);
                        if(response.status=='success')
                        {
                            showAlert('Sales Order Saved Successfully!','Success','Done');
                            show_sales_order_list('sales_list');
                        }
                        else if(response.status=='unauthorized')
                        {
                            alert('System Found Unauthorized Action!');
                            logout();
                        }
                        else if(response.status == "time_over")
                        {
                            __timeOver();
                        }
                        else if(response.status == "deprecated")
                        {
                            __deprecated();
                        }
                        else
                        {
                            alert('Failed to save data!');
                        }
                    },
                    error: function (e) {
                        myApp.hideIndicator();
                        alert('There was a problem connecting to the server.Please try again.');
                    }
                });
            }
            else
            {
                alert('Please fill up all required fields');
            }
        }
        else
        {
            alert('Please fill up all required fields');
        }
    }
    else
    {
        alert('You must add a product!');
    }
});
$$('.approval_action_button_sales').on('click',function () {
    var data_id=$$(this).attr('data-id');
    var data_event_id=$$(this).attr('data-event-id');
    var remarks=$$('#remarks_sales_order').val();
    if(remarks=='')
    {
        alert('Remarks field required!');
        return;
    }
    myApp.showIndicator();
    var user_info = app_data.user_info;
    var url=base_url+"app/save_sales_approve_status";
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,user_level_id:user_info.user_level_id,is_approved:data_id,event_item_id:data_event_id,remarks:remarks},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            if(response.status='success')
            {
                alert('Sales approval status saved successfully!');
                show_sales_order_list('sales_list');
            }
            else if(response.status='invalid')
            {
                alert('Invalid Request!');
            }
            else if(response.status='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else
            {
                alert('Operation Failed. Please try again!');
            }
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
});

function show_invoice_submit_page(class_name)
{
    $$('.invoice_image_name_div').html('');
    $$('#capture_image_for_invoice_id').css('display','flex');
    $$('#capture_image_for_invoice_id').attr('disabled','disabled');
    //$$('.invoiceImgDiv').html('');
    $$('.total_amount_search_order').html('0.00');
    $$('#invoice_table_body').html('');
    $$('.sales_order_in_invoice').val('');
    $$('#project_name_in_invoice').html('');
    $$('#medium_name_in_invoice').html('');
    $$('#medium_type_in_invoice').html('');
    $$('#customer_name_in_invoice').html('');
    $$('#customer_contact_in_invoice').html('');
    $$('#invoice_submit_date').val('');
    adminView.router.load({
        pageName: class_name+'-page'
    });
    user_nav(class_name);
}
$$('.view_order_button').on('click',function () {
    $$('.invoiceImgDiv').html('');
    $$('#capture_image_for_invoice_id').attr('disabled','disabled');
    $$('.total_amount_search_order').html('');
    $$('#invoice_table_body').html('');
    $$('#project_name_in_invoice').html('');
    $$('#medium_name_in_invoice').html('');
    $$('#medium_type_in_invoice').html('');
    $$('#customer_name_in_invoice').html('');
    $$('#customer_contact_in_invoice').html('');
    $$('#submit_customer_info').attr('data-id','');
    $$('#invoice_amount').val('');
    if($$('.sales_order_in_invoice').val())
    {
        var order_no=$$('.sales_order_in_invoice').val();
        if(order_no.length<11)
        {
            alert('Invalid Try!');
        }
        else
        {
            if(!checkConnection())
            {
                alert('No internet connection!');
                return;
            }
            myApp.showIndicator();
            var user_info = app_data.user_info;
            var url=base_url+"app/search_sales_order_by_order_no";
            var new_data={};
            if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
            {
                new_data['today_date']=window.localStorage["today_date"];
            }
            else
            {
                new_data['today_date']='';
            }
            new_data['app_version']=$$('.version').html();
            $$.ajax({
                url: url,
                type: "POST",
                datatype:'json',
                data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,order_no:order_no},
                //timeout: 15000,
                cache: false,
                success: function(data){
                    myApp.hideIndicator();
                    var response= JSON.parse(data);
                    if(response.status=='success')
                    {
                        $$('#capture_image_for_invoice_id').removeAttr('disabled');
                        $$('#project_name_in_invoice').html(response.sales_details[0].project_name);
                        $$('#medium_type_in_invoice').html(response.sales_details[0].medium_type);
                        $$('#medium_name_in_invoice').html(response.sales_details[0].medium_name);
                        $$('#customer_name_in_invoice').html(response.sales_details[0].billing_client_name);
                        $$('#customer_contact_in_invoice').html(response.sales_details[0].billing_client_contact);
                        $$('.total_amount_search_order').html(response.sales_details[0].total_iprice_amount);
                        $$('#submit_customer_info').attr('data-id',response.sales_details[0].id);
                        $$('#invoice_submit_date').val(response.today);
                        var html='';
                        $$.each(response.sales_details, function (index, value) {
                            html+='<tr>' +
                                '<td class="">'+(index+1)+'</td>' +
                                '<td>'+value.product_name+'</td>' +
                                '<td>'+value.price_per_ltr+'</td>' +
                                '<td>'+value.iprice_per_ltr+'</td>' +
                                '<td>'+value.volume+'</td>' +
                                '<td class="">'+value.total_iprice.toFixed(2)+'</td>' +
                                '</tr>';
                        });
                        $$('#invoice_table_body').html(html);
                        $$('#invoice_amount').val(response.sales_details[0].total_iprice_amount);
                    }
                    else if(response.status=='duplicate')
                    {
                        alert("Requested sales order's invoice already submitted!");
                    }
                    else if(response.status=='unauthorized')
                    {
                        alert('Unauthorized Action Found!');
                        logout();
                    }
                    else if(response.status == "time_over")
                    {
                        __timeOver();
                    }
                    else if(response.status == "deprecated")
                    {
                        __deprecated();
                    }
                    else
                    {
                        alert('Sales Order Not Found!');
                    }
                },
                error: function (e) {
                    myApp.hideIndicator();
                    alert('There was a problem connecting to the server.Please try again.');
                }
            });
        }
    }
    else
    {
        alert('Please enter sales order no.');
    }
});

$$('#submit_customer_info').on('click',function () {
    var sales_id=$$(this).attr('data-id');
    var lat=$$('#invoice_latitude').val();
    var long=$$('#invoice_longitude').val();
    var date=$$('#invoice_submit_date').val();
    var remarks=$$('#invoice_remarks').val();
    var invoice_amount=$$('#invoice_amount').val();
    var post_array={};
    post_array['sales_id']=sales_id;
    post_array['lat']=lat;
    post_array['long']=long;
    post_array['submission_date']=date;
    post_array['remarks']=remarks;
    post_array['invoice_amount']=invoice_amount;
    var image_order_fields=[];
    var image_value_fields=[];
    $$(".invoice_capture_image_names").each(function(index,value)
    {
        image_order_fields.push($$(this).attr('data-id'));
        image_value_fields.push($$(this).val());
    });
    if(Number(image_value_fields.length)==0)
    {
        alert("Please Capture Invoice Image!");
    }
    else
    {
        if(sales_id!='' && lat!='' && long!='' && date!='' && invoice_amount!='')
        {
            if(confirm('Are you sure to submit this invoice?'))
            {
                if(!checkConnection())
                {
                    alert('No internet connection!');
                    return;
                }
                myApp.showIndicator();
                var user_info = app_data.user_info;
                var url=base_url+"app/submit_customer_invoice";
                var new_data={};
                if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
                {
                    new_data['today_date']=window.localStorage["today_date"];
                }
                else
                {
                    new_data['today_date']='';
                }
                new_data['app_version']=$$('.version').html();
                $$.ajax({
                    url: url,
                    type: "POST",
                    datatype:'json',
                    data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,datas:post_array,image_order_fields:image_order_fields,image_value_fields:image_value_fields},
                    //timeout: 15000,
                    cache: false,
                    success: function(data){
                        myApp.hideIndicator();
                        var response= JSON.parse(data);
                        if(response.status=='success')
                        {
                            alert('Customer Invoice Submitted Successfully!');
                            show_sales_ratification_list('sales_ratification_list');
                        }
                        else if(response.status=='unauthorized')
                        {
                            alert('Unauthorized Action Found!');
                            logout();
                        }
                        else if(response.status == "time_over")
                        {
                            __timeOver();
                        }
                        else if(response.status == "deprecated")
                        {
                            __deprecated();
                        }
                        else
                        {
                            alert('Sales Order Not Saved Successfully!');
                        }
                    },
                    error: function (e) {
                        myApp.hideIndicator();
                        alert('There was a problem connecting to the server.Please try again.');
                    },
                    complete: function (e) {
                        myApp.hideIndicator();
                        if(!upload_image_function_status)
                        {
                            uploadImageToServer();
                        }
                    }
                });
            }
        }
        else
        {
            alert('Required Field Missing!');
        }
    }
});
function show_sale_ratification_details(sales_id) {
    $$('.ratification_image_name_div').html('');
    $$('#capture_image_for_ratification_id').css('display','flex');
    $$('.ratificationImgDiv').html('');
    $$('#invoice_image_in_ratification').html('');
    $$('#submit_ratification_info').attr('data-id','');
    $$('#project_name_in_ratification').html('');
    $$('#medium_type_in_ratification').html('');
    $$('#medium_name_in_ratification').html('');
    $$('#customer_name_in_ratification').html('');
    $$('#customer_contact_in_ratification').html('');
    $$('.total_amount_ratification').html('');
    $$('#ratification_table_body').html('');
    $$('#invoice_submit_amount_in_ratification').html('');
    $$('#invoice_submit_date_in_ratification').html('');
    $$('#invoice_reamrks_in_ratification').html('');
    $$('#ratification_history_table_body').html('');
    var sales_id=sales_id;
    var user_info = app_data.user_info;
    var url=base_url+"app/sales_ratification_data_by_sales_id";
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    var new_data={};
    if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
    {
        new_data['today_date']=window.localStorage["today_date"];
    }
    else
    {
        new_data['today_date']='';
    }
    new_data['app_version']=$$('.version').html();
    myApp.showIndicator();
    $$.ajax({
        url: url,
        type: "POST",
        datatype:'json',
        data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,sales_id:sales_id},
        //timeout: 15000,
        cache: false,
        success: function(data){
            myApp.hideIndicator();
            var response= JSON.parse(data);
            image_order=0;
            image_name=[];
            if(response.status=='success')
            {
                if(user_info.user_level=='APEC')
                {
                    $$('#ratification_action_container').hide();
                }
                else
                {
                    if(response.sales_ratification_list_data.action==1)
                    {
                        $$('#ratification_action_container').show();
                    }
                    else
                    {
                        $$('#ratification_action_container').hide();
                    }
                }
                $$('#submit_ratification_info').attr('data-id',sales_id);
                var html='';
                $$.each(response.sales_ratification_list_data.products, function (index, value) {
                    html+='<tr>' +
                        '<td class="">'+(index+1)+'</td>' +
                        '<td>'+value.product_name+'</td>' +
                        '<td>'+value.price_per_ltr+'</td>' +
                        '<td>'+value.iprice_per_ltr+'</td>' +
                        '<td>'+value.volume+'</td>' +
                        '<td class="">'+value.total_iprice.toFixed(2)+'</td>' +
                        '</tr>';
                });
                var iLat =parseFloat(response.sales_ratification_list_data.sale_n_invoice.lat);
                var iLong=parseFloat(response.sales_ratification_list_data.sale_n_invoice.long);
                var myLatLng = {lat: iLat, lng: iLong};
                var iMap = document.getElementById('invoice_details_map');
                iMap.style.height = "100px";
                var map = new google.maps.Map(document.getElementById('invoice_details_map'), {
                    zoom: 15,
                    center: myLatLng,
                    disableDefaultUI: true
                });
                var marker = new google.maps.Marker({
                    position: myLatLng,
                    map: map
                });
                var image_arr = response.sales_ratification_list_data.sale_n_invoice.image_names.split(',');
                $$.each(image_arr, function (index, value) {
                    var inx=Number(index)+1;
                    if(index==0)
                    {
                        image_order=index;
                    }
                    image_name[inx]=value;
                    var path = "file:///storage/emulated/0/AsianPaint/" + value;
                    checkIfFileExistsinvoice(path);
                });
                $$('#ratification_submit_date').val(response.today);
                $$('#ratification_table_body').html(html);
                $$('#sales_order_in_ratification').html(response.sales_ratification_list_data.sale_n_invoice.sales_order_no);
                $$('#project_name_in_ratification').html(response.sales_ratification_list_data.sale_n_invoice.project_name);
                $$('#medium_type_in_ratification').html(response.sales_ratification_list_data.sale_n_invoice.medium_type);
                $$('#medium_name_in_ratification').html(response.sales_ratification_list_data.sale_n_invoice.medium_name);
                $$('#customer_name_in_ratification').html(response.sales_ratification_list_data.sale_n_invoice.billing_client_name);
                $$('#customer_contact_in_ratification').html(response.sales_ratification_list_data.sale_n_invoice.billing_client_contact);
                $$('.total_amount_ratification').html(response.sales_ratification_list_data.sale_n_invoice.total_iprice_amount);
                $$('#invoice_submit_amount_in_ratification').html(response.sales_ratification_list_data.sale_n_invoice.invoice_amount);
                $$('#invoice_submit_date_in_ratification').html(response.sales_ratification_list_data.sale_n_invoice.submission_date);
                $$('#invoice_remarks_in_ratification').val(response.sales_ratification_list_data.sale_n_invoice.remarks);
                var ratify_status;
                var html='';
                var possible_users_info=app_data.possible_users_info;
                var inx=0;
                $$.each(response.sales_ratification_list_data.history, function (index, value) {
                    if(index==0)
                    {
                        ratify_image_order=index;
                    }
                    if(value.image!=null)
                    {
                        inx=inx+1;
                        ratify_image_name[inx]=value.image;
                        var path = "file:///storage/emulated/0/AsianPaint/" + value.image;
                        checkIfFileExistsratify(path);
                    }
                    if(value.ratify_status==1)
                    {
                        ratify_status='Approved';
                    }
                    else
                    {
                        ratify_status='Rejected';
                    }
                    html+='<tr>' +
                        '<td>'+value.date+'</td>';
                    if(value.image==null)
                    {
                        html+='<td>N/A</td>';
                    }
                    else
                    {
                        html+='<td id="ratify_image_'+inx+'"></td>';
                    }
                    html+='<td>'+possible_users_info[value.ratified_by]+'</td>' +
                        '<td>'+ratify_status+'</td>' +
                        '<td>'+value.ratification_reason+'</td>' +
                        '</tr>';
                });
                $$('#ratification_history_table_body').html(html);
                $$('.u_hide').hide();
                $$('.sales_ratify').show();
                $$('.navbar').hide();
                $$('.sales_ratify-nav').show();
            }
            else if(response.status=='unauthorized')
            {
                alert('Unauthorized Action Found!');
                logout();
            }
            else if(response.status == "time_over")
            {
                __timeOver();
            }
            else if(response.status == "deprecated")
            {
                __deprecated();
            }
            else{}
        },
        error: function (e) {
            myApp.hideIndicator();
            alert('There was a problem connecting to the server.Please try again.');
        }
    });
}

$$('.copy_sales_order').on('click',function () {
    var copyText = document.getElementById("sale_order_no_in_detail");
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    document.execCommand("copy");
});
function checkIfFileExistsratify(path){
    // path is the full absolute path to the file.
    window.resolveLocalFileSystemURL(path, fileExistsratify, fileDoesNotExistratify);
}
function fileExistsratify(fileEntry){
    ratify_image_order=Number(ratify_image_order)+1;
    var imagePath = "file:///storage/emulated/0"+fileEntry.fullPath;
    $$('#ratify_image_'+ratify_image_order).html('<img src="'+imagePath+'" style="width: 90%;padding: 5px;">');
}
function fileDoesNotExistratify(){
    ratify_image_order=Number(ratify_image_order)+1;
    var live_image_path=base_url+'public/uploads/ratification/'+ratify_image_name[ratify_image_order];
    var pending_image_path=base_url+'public/uploads/pending_img.jpg';
    UrlExists(live_image_path, function(status) {
        if(status.status === 200)
        {
            $$('#ratify_image_'+status.id).html('<img src="'+live_image_path+'" style="width: 85%;padding: 5px;">');
        }
        else if(status.status === 404)
        {
            $$('#ratify_image_'+status.id).html('<img src="'+pending_image_path+'" style="width: 85%;padding: 5px;">');
        }
        else
        {
            $$('#ratify_image_'+status.id).html('<img src="'+pending_image_path+'" style="width: 85%;padding: 5px;">');
        }
    },ratify_image_order);
}
function checkIfFileExistsinvoice(path){
    // path is the full absolute path to the file.
    window.resolveLocalFileSystemURL(path, fileExistsinvoice, fileDoesNotExistinvoice);
}
function fileExistsinvoice(fileEntry){
    image_order=Number(image_order)+1;
    var imagePath1 = "file:///storage/emulated/0"+fileEntry.fullPath;
    $$('#invoice_image_in_ratification').append('<img src="'+imagePath1+'" style="width: 90%;padding: 5px;">');
}
function fileDoesNotExistinvoice(){
    image_order=Number(image_order)+1;
    var live_image_path1=base_url+'public/uploads/invoice/'+image_name[image_order];
    var pending_image_path1=base_url+'public/uploads/pending_img.jpg';
    UrlExists(live_image_path1, function(status) {
        if(status.status === 200)
        {
            $$('#invoice_image_in_ratification').append('<img src="'+live_image_path1+'" style="width: 85%;padding: 5px;">');
        }
        else if(status.status === 404)
        {
            $$('#invoice_image_in_ratification').append('<img src="'+pending_image_path1+'" style="width: 85%;padding: 5px;">');
        }
        else
        {
            $$('#invoice_image_in_ratification').append('<img src="'+pending_image_path1+'" style="width: 85%;padding: 5px;">');
        }
    },1);
}
$$('.sales_ratify_details_back_button').on('click',function () {
    show_sales_ratification_list('sales_ratification_list');
});

$$('#ratification_customer_call').on('change',function () {
    if($$(this).val()=='physical')
    {
        $$('.ratification_image_name_div').html('');
        $$('#capture_image_for_ratification_id').css('display','flex');
        $$('#ratification_showing_photo_span').css('display','flex');
        $$('.ratificationImgDiv').html('');
        $$('.capture_image_div_for_ratification').css('display','flex');
    }
    else
    {
        $$('.ratification_image_name_div').html('');
        $$('#capture_image_for_ratification_id').css('display','flex');
        $$('#ratification_showing_photo_span').hide();
        $$('.ratificationImgDiv').html('');
        $$('.capture_image_div_for_ratification').hide();
    }
});

$$('#submit_ratification_info').on('click',function () {
    var sales_id=$$(this).attr('data-id');
    var ratification_latitude=$$('#ratification_latitude').val();
    var ratification_longitude=$$('#ratification_longitude').val();
    var ratification_submit_date=$$('#ratification_submit_date').val();
    var ratification_reason=$$('#ratification_reason').val();
    var ratification_status=$$('#ratification_status').val();
    var customer_call=$$('#ratification_customer_call').val();
    var post_array={};
    var image_order_fields=[];
    var image_value_fields=[];
    post_array['sales_id']=sales_id;
    post_array['lat']=ratification_latitude;
    post_array['long']=ratification_longitude;
    post_array['date']=ratification_submit_date;
    post_array['ratification_reason']=ratification_reason;
    post_array['ratify_status']=ratification_status;
    post_array['customer_call_type']=customer_call;
    post_array['customer_call_status']='Yes';
    if(customer_call=='physical')
    {
        $$(".ratification_capture_image_names").each(function(index,value)
        {
            image_order_fields.push($$(this).attr('data-id'));
            image_value_fields.push($$(this).val());
        });
        if(Number(image_value_fields.length)==0)
        {
            alert("Please Capture Ratify Image!");
            return;
        }
    }
    if(customer_call!='' && sales_id!='' && ratification_latitude!='' && ratification_longitude!='' && ratification_submit_date!='' && ratification_status!='' && ratification_reason!='')
    {
        if(confirm('Are you sure to submit this ratification?'))
        {
            if(!checkConnection())
            {
                alert('No internet connection!');
                return;
            }
            myApp.showIndicator();
            var user_info = app_data.user_info;
            var url=base_url+"app/submit_ratification";
            var new_data={};
            if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
            {
                new_data['today_date']=window.localStorage["today_date"];
            }
            else
            {
                new_data['today_date']='';
            }
            new_data['app_version']=$$('.version').html();
            $$.ajax({
                url: url,
                type: "POST",
                datatype:'json',
                data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,datas:post_array,image_order_fields:image_order_fields,image_value_fields:image_value_fields},
                //timeout: 15000,
                cache: false,
                success: function(data){
                    myApp.hideIndicator();
                    var response= JSON.parse(data);
                    if(response.status=='success')
                    {
                        alert('Ratification Process Completed Successfully!');
                        show_sales_ratification_list('sales_ratification_list');
                    }
                    else if(response.status=='unauthorized')
                    {
                        alert('Unauthorized Action Found!');
                        logout();
                    }
                    else if(response.status == "time_over")
                    {
                        __timeOver();
                    }
                    else if(response.status == "deprecated")
                    {
                        __deprecated();
                    }
                    else
                    {
                        alert('Process Failed!');
                    }
                },
                error: function (e) {
                    myApp.hideIndicator();
                    alert('There was a problem connecting to the server.Please try again.');
                },
                complete: function (e) {
                    myApp.hideIndicator();
                    if(!upload_image_function_status)
                    {
                        uploadImageToServer();
                    }
                }
            });
        }
    }
    else
    {
        alert('Required Field Missing!');
    }
});
$$('.form_painter_status').on('change',function () {
    $$('.progoti_status_container').hide();
    if($$(this).val()=='Registered')
    {
        $$('.progoti_status_container').css("display", "flex");
    }
});

function be_base_64(imgCount) {
    var folderPath = 'file:///storage/emulated/0/AsianPaint/';
    var image_name = $$('#project_id').val()+"_"+imgCount+".jpg";
    var imagePath = folderPath + image_name;
    getFileContentAsBase64(imagePath, function(base64Image){
        window.localStorage[image_name]=base64Image;
    });
}


/* newly added - start */
function getFileContentAsBase64(path,callback){
    window.resolveLocalFileSystemURL(path, gotFile, fail);
    function fail(e) {
        alert('Cannot found requested file');
    }

    function gotFile(fileEntry) {
        fileEntry.file(function(file) {
            var reader = new FileReader();
            reader.onloadend = function(e) {
                var content = this.result;
                callback(content);
            };
            // The most important point, use the readAsDatURL Method from the file plugin
            reader.readAsDataURL(file);
        });
    }
}
/* newly added - end */




// function getFileContentAsBase64(path, callback){
//     function fail(e) {
//         var id = Number($$('#image_count').val());
//         var image_name=$$('#project_id').val()+"_"+id+".jpg";
//         del_image_from_device(image_name);
//         $$('#id_'+id).remove();
//         $$('#image_name_'+id).remove();
//         $$('#capture_image_for_project_id').removeAttr('disabled');
//         alert('Cannot Found Requested Image File. Try again!');
//     }
//     function gotFile(fileEntry) {
//         fileEntry.file(function(file) {
//             var reader = new FileReader();
//             reader.onloadend = function(e) {
//                 var content = this.result;
//                 callback(content);
//             };
//             // The most important point, use the readAsDataURL Method from the file plugin
//             reader.readAsDataURL(file);
//         });
//     }
//     window.resolveLocalFileSystemURL(path, gotFile, fail);
// }

// Camera related function
function getProjectImage(){
    navigator.camera.getPicture(function cameraSuccess(imageData) {
        var D = $$('#project_img123');
        var imgCount = parseInt($$('.capturred_image').length)+1;
        var imageHtml = '<div class="imgDiv" id="id_'+imgCount+'" data-id="'+imgCount+'" style="position:relative;"><img id="image_show_'+imgCount+'" src="'+imageData+'" data-id="'+imgCount+'" class="capturred_image" style="width: 43% !important;margin-left: 5px;height: 80px !important;" /><a onclick="del_img(this);" class="del_btn'+imgCount+'"><i class="material-icons">delete</i></a></div>';
        D.append(imageHtml);
        if(imgCount==2)
        {
            $$('#image_show_1').css('float','left');
        }
        movePic(imageData);
    }, function cameraError(error) {
        alert("Unable to obtain picture: " + JSON.stringify(error), "app");
    }, { quality: 20, correctOrientation: true, destinationType: Camera.DestinationType.FILE_URI});
}
function getFileEntry(imgUri) {
    window.resolveLocalFileSystemURL(imgUri, function success(fileEntry) {
        // Do something with the FileEntry object, like write to it, upload it, etc.
        // writeFile(fileEntry, imgUri);
        alert("got file: " + fileEntry.fullPath);
        // displayFileData(fileEntry.nativeURL, "Native URL");
    }, function () {
        // If don't get the FileEntry (which may happen when testing
        // on some emulators), copy to a new FileEntry.
        createNewFileEntry(imgUri);
    });
}
function createNewFileEntry(imgUri) {
    window.resolveLocalFileSystemURL(cordova.file.cacheDirectory, function success(dirEntry) {
        // JPEG file
        dirEntry.getFile("tempFile.jpeg", { create: true, exclusive: false }, function (fileEntry) {
            // Do something with it, like write to it, upload it, etc.
            // writeFile(fileEntry, imgUri);
            alert("got file: " + fileEntry.fullPath);
            // displayFileData(fileEntry.fullPath, "File copied to");
        }, function(err){alert('Error creating file'+JSON.stringify(err));});
    }, function(errr){alert('Error reslove uri'+JSON.stringify(errr));});
}

function onFail(message) {
    alert('Failed because: ' + message);
}

function movePic(file){
    //alert('movePic');
    //window.resolveLocalFileSystemURI(file, resolveOnSuccess, resOnError);
    window.resolveLocalFileSystemURL(file, resolveOnSuccess, resOnError);
}

//Callback function when the file system uri has been resolved
function resolveOnSuccess(fileEntry){
    var n = $$('.capturred_image').length;
    var newFileName = window.localStorage["today_date"]+"_"+$$('#project_id').val()+"_"+n+".jpg";
    var myFolderApp = "file:///storage/emulated/0/";
    $$('#image_count').val(n);
    /* newly added - start Rubel */
    if(window.localStorage["captured_pic"] != undefined){
        var pictures = JSON.parse(window.localStorage["captured_pic"]);
        pictures.push({type :'project', name : newFileName});
        window.localStorage["captured_pic"] = JSON.stringify(pictures);
    }else{
        var pictures = [];
        pictures.push({type :'project', name : newFileName});
        window.localStorage["captured_pic"] = JSON.stringify(pictures);
    }
    /* newly added - end Rubel */

    window.resolveLocalFileSystemURL(myFolderApp, function (dirEntry) {
        dirEntry.getDirectory("AsianPaint", { create: true, exclusive: false }, function succ(dirEntry){fileEntry.moveTo(dirEntry, newFileName,  successMove(n), resOnError);}, function fl(){alert('Dir Failed');});
        var input_html='<input type="hidden" value="'+newFileName+'" id="image_name_'+n+'" data-id="'+n+'" class="project_capture_image_names"/>'
        $$('.project_image_name_div').append(input_html);
        $$('#showing_photo_span').hide();
        if(n==2)
        {
            $$('#capture_image_for_project_id').attr('disabled','disabled');
            $$('#capture_image_for_project_id').hide();
        }
    }, function wfail(error) {alert('Error in writing file. Error:-'+error.code);});
}

//Callback function when the file has been moved successfully - inserting the complete path
function successMove(n) {
    //Store imagepath in session for future use
    // like to store it in database
    //sessionStorage.setItem('imagepath', entry.fullPath);
    // alert('Image storage done!');
    //be_base_64(n);
}

function resOnError(error) {
    alert('Error saving file '+JSON.stringify(error));
}

function getImage(imageID,imageCount) {
    var image3 = document.getElementById('project_img');
    var i;
    for(i=1;i<=getImage;i++){
        $$('#project_img').append('<img src="file:///storage/emulated/0/AsianPaint/'+imageID+'_'+i+'.jpg" style="width: 100%">');
    }

    //image3.src = 'file:///storage/emulated/0/AsianPaint/'+imageID+'.jpg';
    /*var directory_path = "file:///storage/emulated/0/AsianPaint/";
    window.resolveLocalFileSystemURL(directory_path , function(dirEntry) {
        var directoryReader = dirEntry.createReader();
        directoryReader.readEntries(successDir,failDir);
    });*/
}
function successDir(entries) {
    var i;
    for (i=0; i<entries.length; i++) {
        alert('En - ', entries[i]);
    }
}
function failDir(error) {
    //console.log("Failed to list directory contents: ", error);
}
function createDirectory(rootDirEntry) {
    rootDirEntry.getDirectory('NewDirInRoot', { create: true }, function (dirEntry) {
        dirEntry.getDirectory('images', { create: true }, function (subDirEntry) {

            createFile(subDirEntry, "fileInNewSubDir.txt");

        }, onErrorGetDir);
    }, onErrorGetDir);
}
function del_img(obj){
    if(confirm('Do you want to delete?')) {
        var id = $$(obj).parents('div.imgDiv').attr('data-id');
        var image_name = $$('#project_id').val() + "_" + id + ".jpg";
        del_image_from_device(image_name);
        $$('#id_' + id).remove();
        $$('#image_name_' + id).remove();
        $$('#capture_image_for_project_id').removeAttr('disabled');
        $$('#capture_image_for_project_id').css('display','flex');
        var image_count = Number($$('#image_count').val());
        $$('#image_count').val(image_count - 1);
        if (image_count == 2) {
            $$('#image_show_1').css('float', 'none');
        } else if (image_count == 1) {
            $$('#showing_photo_span').css('display', 'flex');
        } else {

        }
    }
}
function del_image_from_device(image_name) {
    window.resolveLocalFileSystemURL('file:///storage/emulated/0/AsianPaint/', function (dir) {
        dir.getFile(image_name, {create: false}, function (fileEntry) {
            fileEntry.remove(function (file) {

            }, function (error) {
                alert("error occurred: " + error.code);
            }, function () {
            });
        });
    });
}

/* newly added - start */
function getInvoiceImage(){
    var order_no = $$('.sales_order_in_invoice').val();
    if(order_no != '') {
        navigator.camera.getPicture(function cameraSuccess(imageData) {
            var D = $$('.invoice_img123');
            var imgCount = parseInt($$('.capturred_invoice_image').length) + 1;
            var imageHtml = '<div class="invoiceImgDiv" id="invoice_id_' + imgCount + '" data-id="' + imgCount + '" style="position:relative;"><img id="invoice_image_show_' + imgCount + '" src="' + imageData + '" data-id="' + imgCount + '" class="capturred_invoice_image" style="width: 43% !important;margin-left: 0px;height: 80px !important;" /><a style="padding:10px;" onclick="del_invoice_img(this);" class="del_invoice_btn' + imgCount + '"><i class="material-icons">delete</i></a></div>';
            D.append(imageHtml);
            if (imgCount == 1) {
                $$('customar_invoice_image_div').hide();
            }
            moveInvoicePic(imageData);
        }, function cameraError(error) {
            alert("Unable to obtain picture: " + JSON.stringify(error), "app");
        }, {quality: 20, correctOrientation: true, destinationType: Camera.DestinationType.FILE_URI});
    }else {
        alert('Please, Enter Order No.');
    }
}
function moveInvoicePic(file){
    //alert('movePic');
    //window.resolveLocalFileSystemURI(file, resolveOnSuccess, resOnError);
    window.resolveLocalFileSystemURL(file, resolveOnSuccessInvoice, resOnError);
}
function resolveOnSuccessInvoice(fileEntry){
    var n = $$('.capturred_invoice_image').length;
    var newFileName = $$('.sales_order_in_invoice').val()+"_"+n+".jpg";
    var myFolderApp = "file:///storage/emulated/0/";
    $$('#invoice_image_count').val(n);

    if(window.localStorage["captured_pic"] != undefined){
        var pictures = JSON.parse(window.localStorage["captured_pic"]);
        pictures.push({type :'invoice', name : newFileName});
        window.localStorage["captured_pic"] = JSON.stringify(pictures);
    }else{
        var pictures = [];
        pictures.push({type :'invoice', name : newFileName});
        window.localStorage["captured_pic"] = JSON.stringify(pictures);
    }
    window.resolveLocalFileSystemURL(myFolderApp, function (dirEntry) {
        dirEntry.getDirectory("AsianPaint", { create: true, exclusive: false }, function succ(dirEntry){fileEntry.moveTo(dirEntry, newFileName,  successMove(n), resOnError);}, function fl(){alert('Dir Failed');});
        var input_html='<input type="hidden" value="'+newFileName+'" id="invoice_image_name_'+n+'" data-id="'+n+'" class="invoice_capture_image_names"/>'
        $$('.invoice_image_name_div').append(input_html);
        $$('#invoice_showing_photo_span').hide();
        if(n == 1){
            $$('#capture_image_for_invoice_id').hide();
        }
    }, function wfail(error) {alert('Error in writing file. Error:-'+error.code);});
}
function del_invoice_img(obj){
    if(confirm('Do you want to delete?')) {
        var id = $$(obj).parents('div.invoiceImgDiv').attr('data-id');
        var image_name = $$('.sales_order_in_invoice').val() + "_" + id + ".jpg";
        del_image_from_device(image_name);
        $$('#invoice_id_' + id).remove();
        $$('#invoice_image_name_' + id).remove();
        $$('#capture_image_for_invoice_id').show();
        var image_count = Number($$('#invoice_image_count').val());
        $$('#invoice_image_count').val(image_count - 1);
        if (image_count == 1) {
            $$('#invoice_showing_photo_span').css('display', 'flex');
            $$('#invoice_image_show_1').css('float', 'none');
        } else {
            $$('#invoice_showing_photo_span').css('display', 'flex');
        }
    }
}
function getRatificationImage(){
    var order_no = $$('#sales_order_in_ratification').html();
    if(order_no != '') {
        navigator.camera.getPicture(function cameraSuccess(imageData) {
            var D = $$('.ratification_img123');
            var imgCount = parseInt($$('.capturred_ratification_image').length) + 1;
            var imageHtml = '<div class="ratificationImgDiv" id="ratification_id_' + imgCount + '" data-id="' + imgCount + '" style="position:relative;"><img id="ratification_image_show_' + imgCount + '" src="' + imageData + '" data-id="' + imgCount + '" class="capturred_ratification_image" style="width: 43% !important;margin-left: 5px;height: 80px !important;" /><a style="padding:10px;" onclick="del_ratification_img(this);" class="del_ratification_btn' + imgCount + '"><i class="material-icons">delete</i></a></div>';
            D.append(imageHtml);
            if (imgCount == 1) {
                $$('customar_ratification_image_div').hide();
            }
            moveRatificationPic(imageData);
        }, function cameraError(error) {
            alert("Unable to obtain picture: " + JSON.stringify(error), "app");
        }, {quality: 20, correctOrientation: true, destinationType: Camera.DestinationType.FILE_URI});
    }
    else{
        alert('Please Try Again!');
    }
}
function moveRatificationPic(file){
    //alert('movePic');
    //window.resolveLocalFileSystemURI(file, resolveOnSuccess, resOnError);
    window.resolveLocalFileSystemURL(file, resolveOnSuccessRatification, resOnError);
}
function resolveOnSuccessRatification(fileEntry){
    var n = $$('.capturred_ratification_image').length;
    var user_info = app_data.user_info;
    var newFileName = $$('#sales_order_in_ratification').html()+'_'+user_info.user_id+"_"+n+".jpg";
    var myFolderApp = "file:///storage/emulated/0/";
    $$('#ratification_image_count').val(n);
    if(window.localStorage["captured_pic"] != undefined){
        var pictures = JSON.parse(window.localStorage["captured_pic"]);
        pictures.push({type :'ratification', name : newFileName});
        window.localStorage["captured_pic"] = JSON.stringify(pictures);
    }else{
        var pictures = [];
        pictures.push({type :'ratification', name : newFileName});
        window.localStorage["captured_pic"] = JSON.stringify(pictures);
    }
    window.resolveLocalFileSystemURL(myFolderApp, function (dirEntry) {
        dirEntry.getDirectory("AsianPaint", { create: true, exclusive: false }, function succ(dirEntry){fileEntry.moveTo(dirEntry, newFileName,  successMove(n), resOnError);}, function fl(){alert('Dir Failed');});
        var input_html='<input type="hidden" value="'+newFileName+'" id="ratification_image_name_'+n+'" data-id="'+n+'" class="ratification_capture_image_names"/>'
        $$('.ratification_image_name_div').append(input_html);
        $$('#ratification_showing_photo_span').hide();
        if(n == 1){
            $$('#capture_image_for_ratification_id').hide();
        }
    }, function wfail(error) {alert('Error in writing file. Error:-'+error.code);});
}
function del_ratification_img(obj){
    if(confirm('Do you want to delete?')) {
        var id = $$(obj).parents('div.ratificationImgDiv').attr('data-id');
        var user_info = app_data.user_info;
        var image_name = $$('#sales_order_in_ratification').html()+'_'+user_info.user_id+"_"+id+".jpg";
        del_image_from_device(image_name);
        $$('#ratification_id_' + id).remove();
        $$('#ratification_image_name_' + id).remove();
        $$('#capture_image_for_ratification_id').show();
        var image_count = Number($$('#ratification_image_count').val());
        $$('#ratification_image_count').val(image_count - 1);
        if (image_count == 1) {
            $$('#ratification_showing_photo_span').css('display', 'flex');
            $$('#ratification_image_show_1').css('float', 'none');
        } else {
            $$('#ratification_showing_photo_span').css('display', 'flex');
        }
    }
}
function uploadImageToServer(){
    if(typeof window.localStorage["captured_pic"]!=='undefined')
    {
        if(server_status==true)
        {
            var imageArr1 = JSON.parse(window.localStorage["captured_pic"]);
            imageArr1.shift();
            window.localStorage["captured_pic"] = JSON.stringify(imageArr1);
            send_image_for_64();
        }
        else
        {
            send_image_for_64();
        }
    }
}
function send_image_for_64() {
    var imageArr = JSON.parse(window.localStorage["captured_pic"]);
    if(imageArr.length > 0) {
        upload_image_function_status=true;
        var path = "file:///storage/emulated/0/AsianPaint/" + imageArr[0].name;
        window.resolveLocalFileSystemURL(path, fileExists, fileDoesNotExist);
    }
    else
    {
        upload_image_function_status=false;
    }
}
function fileExists(fileEntry){
    var imagePath = "file:///storage/emulated/0"+fileEntry.fullPath;
    getFileContentAsBase64(imagePath,function(base64Image){
        var imageArr = JSON.parse(window.localStorage["captured_pic"]);
        var data_all = {
            _token: window.localStorage["token"],
            name: imageArr[0].name,
            type: imageArr[0].type,
            image: base64Image
        };
        $$.ajax({
            type: "POST",
            url: base_url+"/app/uploadImageData",
            data: {data:JSON.stringify(data_all)},
            //timeout: 15000,
            beforeSend: function (data){
                server_status=false;
            },success: function (data){
                var response = JSON.parse(data);
                if(response.status == 'success'){
                    server_status=true;
                }
                uploadImageToServer();
            },
            error: function(data) {
                uploadImageToServer();
            }
        });
    });
}
function fileDoesNotExist(){
    server_status=true;
    uploadImageToServer();
}
function getFSFail(evt) {
    //console.log(evt.target.error.code);
}
/* newly added - end */
function getlocation(type){
    if(type=='checkin'){
        myApp.showIndicator();
        navigator.geolocation.getCurrentPosition(function(position) {
            window.localStorage["check_in_lat"]=position.coords.latitude;
            window.localStorage["check_in_long"]=position.coords.longitude;
            $$.get('https://maps.googleapis.com/maps/api/geocode/json?latlng='+position.coords.latitude+','+position.coords.longitude+'&sensor=true&key=AIzaSyCkPFxxjI1aUggl_3XLOJsPi8BB0Zdsu1A', function( data ) {
                data = JSON.parse(data);
                var addr = data.results[0].formatted_address;
                window.localStorage["check_in_addr"]=addr;
                var user_info = app_data.user_info;
                var url=base_url+"app/save_current_time";
                var new_data={};
                if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
                {
                    new_data['today_date']=window.localStorage["today_date"];
                }
                else
                {
                    new_data['today_date']='';
                }
                new_data['app_version']=$$('.version').html();
                $$.ajax({
                    url: url,
                    type: "POST",
                    datatype:'json',
                    data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,check_in_latitude:window.localStorage["check_in_lat"],check_in_longitude:window.localStorage["check_in_long"],check_in_addr:window.localStorage["check_in_addr"]},
                    //timeout: 15000,
                    cache: false,
                    success: function(data){
                        myApp.hideIndicator();
                        var response= JSON.parse(data);
                        if(response.status=='success')
                        {
                            $$('#check_in_time').html(response.time);
                            $$('.check_in_for_attendance').attr('disabled','disabled');
                            $$('.attendance-in-time').html(response.date_time);
                            window.localStorage["check_in_time"]=response.time;
                            window.localStorage["check_in_date_time"]=response.date_time;
                            $$('.check_out_for_attendance').removeAttr('disabled');
                            initMap(parseFloat(window.localStorage["check_in_lat"]),parseFloat(window.localStorage["check_in_long"]),window.localStorage["check_in_addr"],'check_in_map','#check-in-addr');
                        }
                        else if(response.status == "time_over")
                        {
                            window.localStorage["check_in_lat"]='';
                            window.localStorage["check_in_long"]='';
                            window.localStorage["check_in_addr"]='';
                            __timeOver();
                        }
                        else if(response.status == "deprecated")
                        {
                            window.localStorage["check_in_lat"]='';
                            window.localStorage["check_in_long"]='';
                            window.localStorage["check_in_addr"]='';
                            __deprecated();
                        }
                        else{
                            window.localStorage["check_in_lat"]='';
                            window.localStorage["check_in_long"]='';
                            window.localStorage["check_in_addr"]='';
                        }
                    },
                    error: function (e) {
                        myApp.hideIndicator();
                        window.localStorage["check_in_lat"]='';
                        window.localStorage["check_in_long"]='';
                        window.localStorage["check_in_addr"]='';
                        alert('There was a problem connecting to the server.Please try again.');
                    }
                });
            });
        }, function(err) {
            myApp.hideIndicator();
            alert('code: ' + err.code + '\n message: ' + err.message);
        }, { maximumAge: 3000, timeout: 15000, enableHighAccuracy: true} );
    }
    else if(type=='checkout'){
        myApp.showIndicator();
        navigator.geolocation.getCurrentPosition(function(position) {
            window.localStorage["check_out_lat"]=position.coords.latitude;
            window.localStorage["check_out_long"]=position.coords.longitude;
            $$.get('https://maps.googleapis.com/maps/api/geocode/json?latlng='+position.coords.latitude+','+position.coords.longitude+'&sensor=true&key=AIzaSyCkPFxxjI1aUggl_3XLOJsPi8BB0Zdsu1A', function( data ) {
                data = JSON.parse(data);
                var addr = data.results[0].formatted_address;
                window.localStorage["check_out_addr"]=addr;
                var user_info = app_data.user_info;
                var url=base_url+"app/save_check_out_time";
                var new_data={};
                if(typeof window.localStorage["today_date"]!=='undefined' && window.localStorage["today_date"]!='')
                {
                    new_data['today_date']=window.localStorage["today_date"];
                }
                else
                {
                    new_data['today_date']='';
                }
                new_data['app_version']=$$('.version').html();
                $$.ajax({
                    url: url,
                    type: "POST",
                    datatype:'json',
                    data: {_token:window.localStorage["token"],new_data:new_data,user_id:user_info.user_id,check_out_latitude:window.localStorage["check_out_lat"],check_out_longitude:window.localStorage["check_out_long"],check_out_addr:window.localStorage["check_out_addr"]},
                    //timeout: 15000,
                    cache: false,
                    success: function(data){
                        myApp.hideIndicator();
                        var response= JSON.parse(data);
                        if(response.status == "success")
                        {
                            $$('#check_out_time').html(response.time);
                            $$('.check_out_for_attendance').attr('disabled','disabled');
                            $$('.attendance-out-time').html(response.date_time);
                            window.localStorage["check_out_time"]=response.time;
                            window.localStorage["check_out_date_time"]=response.date_time;
                            initMap(parseFloat(window.localStorage["check_out_lat"]),parseFloat(window.localStorage["check_out_long"]),window.localStorage["check_out_addr"],'check_out_map','#check-out-addr');
                        }
                        else if(response.status == "time_over")
                        {
                            window.localStorage["check_out_lat"]='';
                            window.localStorage["check_out_long"]='';
                            window.localStorage["check_out_addr"]='';
                            __timeOver();
                        }
                        else if(response.status == "deprecated")
                        {
                            window.localStorage["check_out_lat"]='';
                            window.localStorage["check_out_long"]='';
                            window.localStorage["check_out_addr"]='';
                            __deprecated();
                        }
                        else
                        {
                            window.localStorage["check_out_lat"]='';
                            window.localStorage["check_out_long"]='';
                            window.localStorage["check_out_addr"]='';
                        }
                    },
                    error: function (e) {
                        myApp.hideIndicator();
                        window.localStorage["check_out_lat"]='';
                        window.localStorage["check_out_long"]='';
                        window.localStorage["check_out_addr"]='';
                        alert('There was a problem connecting to the server.Please try again.');
                    }
                });
            });
        }, function(err) {
            myApp.hideIndicator();
            alert('code: ' + err.code + '\n message: ' + err.message);
        }, { maximumAge: 3000, timeout: 15000, enableHighAccuracy: true} );
    }
}
function getProjectLocation(){
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    //navigator.permissions.query({name:'geolocation'}).then(function(result) {Will return ['granted', 'prompt', 'denied']});
    myApp.showIndicator();
    $$('#project_latitude').val('');
    $$('#project_longitude').val('');
    navigator.geolocation.getCurrentPosition(function(position) {
        $$('#project_latitude').val(position.coords.latitude);
        $$('#project_longitude').val(position.coords.longitude);
        $$.ajax({
            url: 'https://maps.googleapis.com/maps/api/geocode/json?latlng='+position.coords.latitude+','+position.coords.longitude+'&sensor=true&key=AIzaSyCkPFxxjI1aUggl_3XLOJsPi8BB0Zdsu1A',
            type: "GET",
            cache: false,
            success: function(data){
                data = JSON.parse(data);
                var addr = data.results[0].formatted_address;
                $$('#project_address_create').val(addr);
                myApp.hideIndicator();
            },
            error: function (e) {
                alert('There was a problem connecting to the server.Please try again.');
                myApp.hideIndicator();
            }
        });
    }, function(err) {
        myApp.hideIndicator();
        $$('#project_latitude').val('');
        $$('#project_longitude').val('');
        alert('code: ' + err.code + '\n message: ' + err.message);
    }, { maximumAge: 3000, timeout: 15000, enableHighAccuracy: true} );
    navigator.geolocation.getCurrentPosition(onSuccessProject, onError,{ maximumAge: 3000, timeout: 15000, enableHighAccuracy: true });
}
var onSuccessProject = function(position) {
    var pLat =position.coords.latitude;
    var pLong=position.coords.longitude;
    $$('#project_latitude').val(pLat);
    $$('#project_longitude').val(pLong);
    var myLatLng = {lat: pLat, lng: pLong};
    var pMap = document.getElementById('proMap');
    pMap.style.height = "100px";
    var map = new google.maps.Map(document.getElementById('proMap'), {
        zoom: 15,
        center: myLatLng,
        disableDefaultUI: true
    });
    var marker = new google.maps.Marker({
        position: myLatLng,
        map: map
    });
    myApp.hideIndicator();
};
function getProjectLocationforEdit(){
    if(!checkConnection())
    {
        alert('No internet connection!');
        return;
    }
    //navigator.permissions.query({name:'geolocation'}).then(function(result) {Will return ['granted', 'prompt', 'denied']});
    myApp.showIndicator();
    $$('#project_latitude_update').val('');
    $$('#project_longitude_update').val('');
    navigator.geolocation.getCurrentPosition(function(position) {
        $$('#project_latitude_update').val(position.coords.latitude);
        $$('#project_longitude_update').val(position.coords.longitude);
        $$.ajax({
            url: 'https://maps.googleapis.com/maps/api/geocode/json?latlng='+position.coords.latitude+','+position.coords.longitude+'&sensor=true&key=AIzaSyCkPFxxjI1aUggl_3XLOJsPi8BB0Zdsu1A',
            type: "GET",
            cache: false,
            success: function(data){
                data = JSON.parse(data);
                var addr = data.results[0].formatted_address;
                $$('#project_address_update').val(addr);
                myApp.hideIndicator();
            },
            error: function (e) {
                alert('There was a problem connecting to the server.Please try again.');
                myApp.hideIndicator();
            }
        });
    }, function(err) {
        myApp.hideIndicator();
        $$('#project_latitude_update').val('');
        $$('#project_longitude_update').val('');
        alert('code: ' + err.code + '\n message: ' + err.message);
    }, { maximumAge: 3000, timeout: 15000, enableHighAccuracy: true} );
    navigator.geolocation.getCurrentPosition(onSuccessProjectUpdate, onError,{ maximumAge: 3000, timeout: 15000, enableHighAccuracy: true });
}
var onSuccessProjectUpdate = function(position) {
    var pLat =position.coords.latitude;
    var pLong=position.coords.longitude;
    $$('#project_latitude_update').val(pLat);
    $$('#project_longitude_update').val(pLong);
    var myLatLng = {lat: pLat, lng: pLong};
    var pMap = document.getElementById('proMap_update');
    pMap.style.height = "100px";
    var map = new google.maps.Map(document.getElementById('proMap_update'), {
        zoom: 15,
        center: myLatLng,
        disableDefaultUI: true
    });
    var marker = new google.maps.Marker({
        position: myLatLng,
        map: map
    });
    myApp.hideIndicator();
};

function getInvoiceLocation(){
    navigator.geolocation.getCurrentPosition(onSuccessInvoice, onError,{ maximumAge: 3000, timeout: 15000, enableHighAccuracy: true });
}
var onSuccessInvoice = function(position) {
    var iLat =position.coords.latitude;
    var iLong=position.coords.longitude;
    var myLatLng = {lat: iLat, lng: iLong};
    $$('#invoice_latitude').val(iLat);
    $$('#invoice_longitude').val(iLong);
    var iMap = document.getElementById('invoicemap');
    iMap.style.height = "100px";
    var map = new google.maps.Map(document.getElementById('invoicemap'), {
        zoom: 15,
        center: myLatLng,
        disableDefaultUI: true
    });
    var marker = new google.maps.Marker({
        position: myLatLng,
        map: map
    });
};

function getfinishProjectLocation(){
    navigator.geolocation.getCurrentPosition(onSuccessfinishProject, onError,{ maximumAge: 3000, timeout: 15000, enableHighAccuracy: true });
}
var onSuccessfinishProject = function(position) {
    var iLat =position.coords.latitude;
    var iLong=position.coords.longitude;
    var myLatLng = {lat: iLat, lng: iLong};
    $$('#finish_project_latitude').val(iLat);
    $$('#finish_project_longitude').val(iLong);
    var iMap = document.getElementById('finishprojectmap');
    iMap.style.height = "100px";
    var map = new google.maps.Map(document.getElementById('finishprojectmap'), {
        zoom: 15,
        center: myLatLng,
        disableDefaultUI: true
    });
    var marker = new google.maps.Marker({
        position: myLatLng,
        map: map
    });
};

function getfinishPainterLocation(){
    navigator.geolocation.getCurrentPosition(onSuccessfinishPainter, onError,{ maximumAge: 3000, timeout: 15000, enableHighAccuracy: true });
}
var onSuccessfinishPainter = function(position) {
    var iLat =position.coords.latitude;
    var iLong=position.coords.longitude;
    var myLatLng = {lat: iLat, lng: iLong};
    $$('#finish_painter_latitude').val(iLat);
    $$('#finish_painter_longitude').val(iLong);
    var iMap = document.getElementById('finishpaintermap');
    iMap.style.height = "100px";
    var map = new google.maps.Map(document.getElementById('finishpaintermap'), {
        zoom: 15,
        center: myLatLng,
        disableDefaultUI: true
    });
    var marker = new google.maps.Marker({
        position: myLatLng,
        map: map
    });
};

function getRatificationLocation(){
    navigator.geolocation.getCurrentPosition(onSuccessRatification, onError,{ maximumAge: 3000, timeout: 15000, enableHighAccuracy: true });
}
var onSuccessRatification = function(position) {
    var iLat =position.coords.latitude;
    var iLong=position.coords.longitude;
    var myLatLng = {lat: iLat, lng: iLong};
    $$('#ratification_latitude').val(iLat);
    $$('#ratification_longitude').val(iLong);
    var iMap = document.getElementById('ratificationmap');
    iMap.style.height = "100px";
    var map = new google.maps.Map(document.getElementById('ratificationmap'), {
        zoom: 15,
        center: myLatLng,
        disableDefaultUI: true
    });
    var marker = new google.maps.Marker({
        position: myLatLng,
        map: map
    });
};
function onError(error) {
    alert('code: '    + error.code    + '\n' +
        'message: ' + error.message + '\n');
}
function initMap(lat,lng,adrs,div_id,adr_obj) {
    //alert('Calling init map');
    $$(adr_obj).html(adrs);
    var myLatLng = {lat: lat, lng: lng};
    var map = new google.maps.Map(document.getElementById(div_id), {
        zoom: 15,
        center: myLatLng,
        disableDefaultUI: true
    });
    var marker = new google.maps.Marker({
        position: myLatLng,
        map: map,
        title: adrs
    });
}
$$('#sales_status_select_div').on('change',function () {
    var status = $$(this).val();
    var search = $$('#search_sales_order').val().toLowerCase();
    var sales_order_list_info=app_data.sales_order_list_info;
    $$('#sales_order_list_div').hide();
    $$('#sales_order_list_div').html('<div class="row separator"></div>');
    if(search=='')
    {
        if(status=='ALL')
        {
            $$.each(sales_order_list_info, function (index, value) {
                if(value.status=='Requested')
                {
                    $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                        '<div class="row call_list_div_pending sales_order_list_class" data-id="'+value.id+'">' +
                        '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                        '<p class="sale_order_project">'+value.project_name+'</p>' +
                        '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                        '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                        '</div>' +
                        '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                        '<p class="sale_order_date">'+value.requested_date+'</p>' +
                        '<p class="sale_order_status" style="color:#0077f9;">'+value.status+'</p>' +
                        '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                        '</div>' +
                        '</div>');
                }
                else if(value.status=='Approved')
                {
                    $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                        '<div class="row call_list_div_pending approve_sales sales_order_list_class" data-id="'+value.id+'">' +
                        '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                        '<p class="sale_order_project">'+value.project_name+'</p>' +
                        '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                        '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                        '</div>' +
                        '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                        '<p class="sale_order_date">'+value.requested_date+'</p>' +
                        '<p class="sale_order_status" style="color:#04a71f;">'+value.status+'</p>' +
                        '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                        '</div>' +
                        '</div>');
                }
                else
                {
                    $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                        '<div class="row call_list_div_pending rejected_sales sales_order_list_class" data-id="'+value.id+'">' +
                        '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                        '<p class="sale_order_project">'+value.project_name+'</p>' +
                        '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                        '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                        '</div>' +
                        '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                        '<p class="sale_order_date">'+value.requested_date+'</p>' +
                        '<p class="sale_order_status" style="color:#c10c2d;">'+value.status+'</p>' +
                        '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                        '</div>' +
                        '</div>');
                }
            });
        }
        else
        {
            if(status=='Requested')
            {
                $$.each(sales_order_list_info, function (index, value) {
                    if(value.status=='Requested')
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#0077f9;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                });
            }
            else if(status=='Approved')
            {
                $$.each(sales_order_list_info, function (index, value) {
                    if(value.status=='Approved')
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending approve_sales sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#04a71f;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                });
            }
            else
            {
                $$.each(sales_order_list_info, function (index, value) {
                    if(value.status=='Rejected')
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending rejected_sales sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#c10c2d;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                });
            }
        }
    }
    else
    {
        search = search.replace(/\s+/g, '');
        if(status=='ALL')
        {
            $$.each(sales_order_list_info, function (index, value) {
                var str = value.project_name.toLowerCase()+value.sales_order_no;
                str = str.replace(/\s+/g, '');
                if(str.includes(search))
                {
                    if(value.status=='Requested')
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#0077f9;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                    else if(value.status=='Approved')
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending approve_sales sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#04a71f;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                    else
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending rejected_sales sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#c10c2d;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                }
            });
        }
        else
        {
            if(status=='Requested')
            {
                $$.each(sales_order_list_info, function (index, value) {
                    var str = value.project_name.toLowerCase()+value.sales_order_no;
                    str = str.replace(/\s+/g, '');
                    if(value.status=='Requested' && str.includes(search))
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#0077f9;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                });
            }
            else if(status=='Approved')
            {
                $$.each(sales_order_list_info, function (index, value) {
                    var str = value.project_name.toLowerCase()+value.sales_order_no;
                    str = str.replace(/\s+/g, '');
                    if(value.status=='Approved' && str.includes(search))
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending approve_sales sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#04a71f;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                });
            }
            else
            {
                $$.each(sales_order_list_info, function (index, value) {
                    var str = value.project_name.toLowerCase()+value.sales_order_no;
                    str = str.replace(/\s+/g, '');
                    if(value.status=='Rejected' && str.includes(search))
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending rejected_sales sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#c10c2d;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                });
            }
        }
    }
    $$('#sales_order_list_div').show();
    $$('.sales_order_list_class').on('click',function () {
        var order_id=$$(this).attr('data-id');
        show_sale_order_details(order_id);
    });
});
$$('#search_sales_order').on('input',function () {
    var search=$$(this).val();
    var status=$$('#sales_status_select_div').val();
    var sales_order_list_info=app_data.sales_order_list_info;
    $$('#sales_order_list_div').hide();
    $$('#sales_order_list_div').html('<div class="row separator"></div>');
    if(search=='')
    {
        if(status=='ALL')
        {
            $$.each(sales_order_list_info, function (index, value) {
                if(value.status=='Requested')
                {
                    $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                        '<div class="row call_list_div_pending sales_order_list_class" data-id="'+value.id+'">' +
                        '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                        '<p class="sale_order_project">'+value.project_name+'</p>' +
                        '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                        '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                        '</div>' +
                        '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                        '<p class="sale_order_date">'+value.requested_date+'</p>' +
                        '<p class="sale_order_status" style="color:#0077f9;">'+value.status+'</p>' +
                        '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                        '</div>' +
                        '</div>');
                }
                else if(value.status=='Approved')
                {
                    $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                        '<div class="row call_list_div_pending approve_sales sales_order_list_class" data-id="'+value.id+'">' +
                        '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                        '<p class="sale_order_project">'+value.project_name+'</p>' +
                        '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                        '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                        '</div>' +
                        '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                        '<p class="sale_order_date">'+value.requested_date+'</p>' +
                        '<p class="sale_order_status" style="color:#04a71f;">'+value.status+'</p>' +
                        '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                        '</div>' +
                        '</div>');
                }
                else
                {
                    $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                        '<div class="row call_list_div_pending rejected_sales sales_order_list_class" data-id="'+value.id+'">' +
                        '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                        '<p class="sale_order_project">'+value.project_name+'</p>' +
                        '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                        '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                        '</div>' +
                        '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                        '<p class="sale_order_date">'+value.requested_date+'</p>' +
                        '<p class="sale_order_status" style="color:#c10c2d;">'+value.status+'</p>' +
                        '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                        '</div>' +
                        '</div>');
                }
            });
        }
        else
        {
            if(status=='Requested')
            {
                $$.each(sales_order_list_info, function (index, value) {
                    if(value.status=='Requested')
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#0077f9;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                });
            }
            else if(status=='Approved')
            {
                $$.each(sales_order_list_info, function (index, value) {
                    if(value.status=='Approved')
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending approve_sales sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#04a71f;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                });
            }
            else
            {
                $$.each(sales_order_list_info, function (index, value) {
                    if(value.status=='Rejected')
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending rejected_sales sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#c10c2d;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                });
            }
        }
    }
    else
    {
        search=$$(this).val().toLowerCase();
        search = search.replace(/\s+/g, '');
        if(status=='ALL')
        {
            $$.each(sales_order_list_info, function (index, value) {
                var str = value.project_name.toLowerCase()+value.sales_order_no;
                str = str.replace(/\s+/g, '');
                if(str.includes(search))
                {
                    if(value.status=='Requested')
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#0077f9;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                    else if(value.status=='Approved')
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending approve_sales sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#04a71f;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                    else
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending rejected_sales sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#c10c2d;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                }
            });
        }
        else
        {
            if(status=='Requested')
            {
                $$.each(sales_order_list_info, function (index, value) {
                    var str = value.project_name.toLowerCase()+value.sales_order_no;
                    str = str.replace(/\s+/g, '');
                    if(value.status=='Requested' && str.includes(search))
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#0077f9;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                });
            }
            else if(status=='Approved')
            {
                $$.each(sales_order_list_info, function (index, value) {
                    var str = value.project_name.toLowerCase()+value.sales_order_no;
                    str = str.replace(/\s+/g, '');
                    if(value.status=='Approved' && str.includes(search))
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending approve_sales sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#04a71f;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                });
            }
            else
            {
                $$.each(sales_order_list_info, function (index, value) {
                    var str = value.project_name.toLowerCase()+value.sales_order_no;
                    str = str.replace(/\s+/g, '');
                    if(value.status=='Rejected' && str.includes(search))
                    {
                        $$('#sales_order_list_div').prepend('<div class="row separator"></div>'+
                            '<div class="row call_list_div_pending rejected_sales sales_order_list_class" data-id="'+value.id+'">' +
                            '<div class="col-60" style="text-align: left;margin-top: 3%;">' +
                            '<p class="sale_order_project">'+value.project_name+'</p>' +
                            '<p class="sale_order_painter">'+value.medium_type+' : '+value.medium_name+'</p>' +
                            '<p class="sale_order_painter">Order No. : '+value.sales_order_no+'</p>' +
                            '</div>' +
                            '<div class="col-40" style="text-align: right;margin-top: 3%;">' +
                            '<p class="sale_order_date">'+value.requested_date+'</p>' +
                            '<p class="sale_order_status" style="color:#c10c2d;">'+value.status+'</p>' +
                            '<p class="sale_order_amount" style="">'+value.total_iprice_amount+' Tk.</p>' +
                            '</div>' +
                            '</div>');
                    }
                });
            }
        }
    }
    $$('#sales_order_list_div').show();
    $$('.sales_order_list_class').on('click',function () {
        var order_id=$$(this).attr('data-id');
        show_sale_order_details(order_id);
    });
});
$$('#sales_ratify_status_select_div').on('change',function () {
    var status = $$(this).val();
    var search = $$('#search_sales_ratification').val().toLowerCase();
    if(search=='')
    {
        if(status=='ALL')
        {
            $$(".sales_ratification_list_class").each(function( index ) {
                $$(this).css('display','flex');
                $$('#rat_separator_'+$$(this).attr('data-id')).show();
            });
        }
        else
        {
            $$(".sales_ratification_list_class").each(function( index ) {
                if($$(this).attr('data-ratify-status')!=status)
                {
                    $$(this).hide();
                    $$('#rat_separator_'+$$(this).attr('data-id')).hide();
                }
                else
                {
                    $$(this).css('display','flex');
                    $$('#rat_separator_'+$$(this).attr('data-id')).show();
                }
            });
        }
    }
    else
    {
        search = search.replace(/\s+/g, '');
        if(status=='ALL')
        {
            $$(".sales_ratification_list_class").each(function( index ) {
                var str = $$('#rat_sales_project_name_'+$$(this).attr('data-id')).html().toLowerCase()+$$('#rat_sales_order_'+$$(this).attr('data-id')).html();
                str = str.replace(/\s+/g, '');
                if(str.includes(search))
                {
                    $$(this).css('display','flex');
                    $$('#rat_separator_'+$$(this).attr('data-id')).show();
                }
                else
                {
                    $$(this).hide();
                    $$('#rat_separator_'+$$(this).attr('data-id')).hide();
                }
            });
        }
        else
        {
            $$(".sales_ratification_list_class").each(function( index ) {
                var str = $$('#rat_sales_project_name_'+$$(this).attr('data-id')).html().toLowerCase()+$$('#rat_sales_order_'+$$(this).attr('data-id')).html();
                str = str.replace(/\s+/g, '');
                if(str.includes(search) && status==$$(this).attr('data-ratify-status'))
                {
                    $$(this).css('display','flex');
                    $$('#rat_separator_'+$$(this).attr('data-id')).show();
                }
                else
                {
                    $$(this).hide();
                    $$('#rat_separator_'+$$(this).attr('data-id')).hide();
                }
            });
        }
    }
});
$$('#search_sales_ratification').on('input',function () {
    var search=$$(this).val();
    var status=$$('#sales_ratify_status_select_div').val();
    if(search=='')
    {
        if(status=='ALL')
        {
            $$(".sales_ratification_list_class").each(function( index ) {
                $$(this).css('display','flex');
                $$('#rat_separator_'+$$(this).attr('data-id')).show();
            });
        }
        else
        {
            $$(".sales_ratification_list_class").each(function( index ) {
                if($$(this).attr('data-ratify-status')!=status)
                {
                    $$(this).hide();
                    $$('#rat_separator_'+$$(this).attr('data-id')).hide();
                }
                else
                {
                    $$(this).css('display','flex');
                    $$('#rat_separator_'+$$(this).attr('data-id')).show();
                }
            });
        }
    }
    else
    {
        search=$$(this).val().toLowerCase();
        search = search.replace(/\s+/g, '');
        if(status=='ALL')
        {
            $$(".sales_ratification_list_class").each(function( index ) {
                var str = $$('#rat_sales_project_name_'+$$(this).attr('data-id')).html().toLowerCase()+$$('#rat_sales_order_'+$$(this).attr('data-id')).html();
                str = str.replace(/\s+/g, '');
                if(str.includes(search))
                {
                    $$(this).css('display','flex');
                    $$('#rat_separator_'+$$(this).attr('data-id')).show();
                }
                else
                {
                    $$(this).hide();
                    $$('#rat_separator_'+$$(this).attr('data-id')).hide();
                }
            });
        }
        else
        {
            $$(".sales_ratification_list_class").each(function( index ) {
                var str = $$('#rat_sales_project_name_'+$$(this).attr('data-id')).html().toLowerCase()+$$('#rat_sales_order_'+$$(this).attr('data-id')).html();
                str = str.replace(/\s+/g, '');
                if(str.includes(search) && status==$$(this).attr('data-ratify-status'))
                {
                    $$(this).css('display','flex');
                    $$('#rat_separator_'+$$(this).attr('data-id')).show();
                }
                else
                {
                    $$(this).hide();
                    $$('#rat_separator_'+$$(this).attr('data-id')).hide();
                }
            });
        }
    }
});